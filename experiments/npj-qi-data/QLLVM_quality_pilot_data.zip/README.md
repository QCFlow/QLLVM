# R1-4 exploratory compiler-quality comparison

Scope: named Catalyst 0.15.0 configurations, 55 frozen MQTBench cases at 4/6/8 qubits; not a general compiler ranking.

Read summary.json and normalization_summary.json first. Per-case results retain the QLLVM timeout. All outputs used in reported metrics have passed terminal-measurement-effect checks at 1e-9.

Reproduction environments: prepare/analyze/normalization scripts use Python3.10 + Qiskit1.2.4 + NumPy; run scripts use Python3.11 + Catalyst0.15.0/PennyLane0.45.1/lightning0.45.0. Scripts record original absolute paths; set R/P/compiler/archive paths for another machine. No network or API service is needed after dependencies are installed. Protocol JSONs, source/input/output QASM, optimized MLIR, compiler commands, hashes, and all failures are included. Original source QASM is copied beside each canonicalized input.

Common output normalization is a separate symmetric Qiskit pass applied to both workflows; do not attribute this postprocessing exclusively to QLLVM or Catalyst. There is no compilation-speed comparison.
