from pathlib import Path
import json,os,re,traceback
from functools import partial
import pennylane as qml
from catalyst import qjit
from catalyst.debug import get_compilation_stage
from catalyst.passes import cancel_inverses,merge_rotations
R=Path('/home/easyai/qllvm-r14-claims-20261101');P=R/'pilot'
# Reuse only the already-tested fail-closed MLIR extractor, extending Rot by exact ZYZ expansion.
source=(R/'scripts/run_pilot.py').read_text();helper=source[source.index('def extract'):source.index('for k,row')]
helper=helper.replace("name={'RX'", "isrot=name=='Rot'\n   name={'Rot':'rot','RX'")
helper=helper.replace('gates.append([name,ps,ws])',"gates.extend([['rz',[ps[0]],ws],['ry',[ps[1]],ws],['rz',[ps[2]],ws]]) if isrot else gates.append([name,ps,ws])")
helper=helper.replace("['device','alloc'","['gphase','device','alloc'")
exec(helper)
manifest=json.loads((P/'manifest.json').read_text());results=[]
protocol={'fixed_before_control_results':True,'input':'same 55-case manifest and canonical input.json','frontend':'PennyLane 0.45.1 compile transform, two rounds of commute_controlled, cancel_inverses, merge_rotations(atol=0), single_qubit_fusion(atol=0)','backend':'Catalyst 0.15.0 qjit default pipeline with MLIR merge_rotations then cancel_inverses','export':'Rot expanded as RZ(phi), RY(theta), RZ(omega) without optimization; other gates already in shared basis','interpretation':'Additional stronger configured workflow control; not exhaustive best Catalyst pipeline or universal compiler ranking'}
(P/'fusion_protocol.json').write_text(json.dumps(protocol,indent=2))
ops={'rx':qml.RX,'ry':qml.RY,'rz':qml.RZ,'h':qml.Hadamard,'cz':qml.CZ}
for k,r in enumerate(manifest):
 d=P/'cases'/r['case'];dat=json.loads((d/'input.json').read_text());sub=d/'fusion';sub.mkdir(exist_ok=True);os.chdir(sub);row={'case':r['case']}
 try:
  with qml.queuing.AnnotatedQueue() as queue:
   for name,ps,ws in dat['gates']:ops[name](*ps,wires=ws)
   qml.sample(wires=[q for q,c in dat['measurements']])
  tape=qml.tape.QuantumScript.from_queue(queue,shots=128)
  tapes,_=qml.transforms.compile(tape,pipeline=[qml.transforms.commute_controlled,qml.transforms.cancel_inverses,partial(qml.transforms.merge_rotations,atol=0),partial(qml.transforms.single_qubit_fusion,atol=0)],num_passes=2)
  assert len(tapes)==1
  optimized=tapes[0]
  @qml.set_shots(128)
  @qml.qnode(qml.device('lightning.qubit',wires=dat['n']))
  def circuit():
   for op in optimized.operations:qml.apply(op)
   return qml.sample(wires=[q for q,c in dat['measurements']])
  c=qjit(cancel_inverses(merge_rotations(circuit)),keep_intermediate=True);c()
  s=get_compilation_stage(c,'QuantumCompilationStage');(d/'catalyst_fusion.mlir').write_text(s)
  gout=extract(s,dat);(d/'catalyst_fusion.json').write_text(json.dumps(dict(dat,gates=gout)));row['status']='compiled_extracted'
 except Exception:row['status']='failed';row['error']=traceback.format_exc()
 results.append(row);(P/'fusion_compile_results.json').write_text(json.dumps(results,indent=2));print(k+1,len(manifest),r['case'],row['status'],flush=True)
 if k==0 and row['status']=='failed':break
