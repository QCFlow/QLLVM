from pathlib import Path
import json,runpy,numpy as np
from qiskit import qasm2
from qiskit.transpiler import PassManager
from qiskit.transpiler.passes import Optimize1qGatesDecomposition
R=Path(__file__).resolve().parents[1];P=R/'pilot'
s=(R/'scripts/analyze_pilot.py').read_text();ns={};exec(s[s.index('def mapping'):s.index('results=[]')],dict(Operator=__import__('qiskit.quantum_info',fromlist=['Operator']).Operator,np=np,protocol={'basis':['rx','ry','rz','h','cz']}),ns)
# Functions require shared namespace.
g={'np':np,'Operator':__import__('qiskit.quantum_info',fromlist=['Operator']).Operator,'protocol':{'basis':['rx','ry','rz','h','cz']}};exec(s[s.index('def mapping'):s.index('results=[]')],g)
rows=json.loads((P/'results.json').read_text());out=[]
for r in rows:
 if not r['catalyst_fusion_both_verified']:continue
 d=P/'cases'/r['case'];record={'case':r['case']};ref=g['effects'](qasm2.load(d/'input.qasm'))
 for n in ['qllvm','catalyst_fusion']:
  qc=PassManager([Optimize1qGatesDecomposition(basis=['rx','ry','rz','h','cz'])]).run(qasm2.load(d/(n+'.qasm')))
  qasm2.dump(qc,d/(n+'_normalized.qasm'));record[n+'_gates'],record[n+'_depth']=g['metrics'](qc)
  e=g['effects'](qc);record[n+'_error']=max(float(np.linalg.norm(e[k]-ref[k])) for k in ref);assert record[n+'_error']<1e-9
 for m in ['gates','depth']:record[m+'_reduction_pct']=100*(1-record['qllvm_'+m]/record['catalyst_fusion_'+m])
 out.append(record)
summary={m:{'mean_reduction_pct':float(np.mean([r[m+'_reduction_pct'] for r in out])),'lower':sum(r['qllvm_'+m]<r['catalyst_fusion_'+m] for r in out),'equal':sum(r['qllvm_'+m]==r['catalyst_fusion_'+m] for r in out),'higher':sum(r['qllvm_'+m]>r['catalyst_fusion_'+m] for r in out)} for m in ['gates','depth']}
summary['protocol']='Identical Qiskit 1.2.4 Optimize1qGatesDecomposition single-qubit basis normalization applied to both QLLVM and Catalyst fusion-control outputs; same basis; no two-qubit optimization or routing. Independently rechecked all terminal POVM effects at 1e-9. This is a representation-sensitivity control, not a standalone compiler result.';summary['verified_pairs']=len(out);summary['max_error']=max(r[n+'_error'] for r in out for n in ['qllvm','catalyst_fusion'])
(P/'normalization_results.json').write_text(json.dumps(out,indent=2));(P/'normalization_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
