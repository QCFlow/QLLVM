from pathlib import Path
import json,csv,hashlib,traceback
import numpy as np
from qiskit import QuantumCircuit,qasm2
from qiskit.quantum_info import Operator
R=Path(__file__).resolve().parents[1];P=R/'pilot';records=json.loads((P/'compile_results.json').read_text());manifest=json.loads((P/'manifest.json').read_text());assert len(records)==len(manifest)
protocol=json.loads((P/'protocol.json').read_text());protocol['semantics']='All terminal computational-basis measurement effects for arbitrary input states: maximum Frobenius norm of input/output POVM-effect differences, tolerance 1e-9. This upper-bounds each effect operator norm. Partial measurements and classical destinations retained. Canonicalized input also checked against archived source.';protocol['input_header']='Archived OpenQASM 2 syntax has OPENQASM 3 marker; normalized header to OPENQASM 2.0 for parsing without altering gates.';protocol['qllvm_compile_timeout_seconds']=90;(P/'protocol.json').write_text(json.dumps(protocol,indent=2))
def mapping(qc):
 out=[];terminal=False
 for i in qc.data:
  if i.operation.name=='measure':terminal=True;out.append((qc.find_bit(i.qubits[0]).index,qc.find_bit(i.clbits[0]).index))
  elif i.operation.name!='barrier':assert not terminal
 return sorted(out,key=lambda v:v[1])
def effects(qc):
 u=Operator(qc.remove_final_measurements(inplace=False)).data;mp=mapping(qc);groups={}
 for row in range(len(u)):
  outcome=sum(((row>>q)&1)<<c for q,c in mp);groups.setdefault(outcome,[]).append(row)
 return {outcome:u[indices,:].conj().T@u[indices,:] for outcome,indices in groups.items()}
def metrics(qc):
 q=qc.remove_final_measurements(inplace=False);q.data=[i for i in q.data if i.operation.name!='barrier'];assert set(q.count_ops())<=set(protocol['basis'])
 return q.size(),q.depth()
results=[]
for r in records:
 d=P/'cases'/r['case'];out=dict(r)
 source=QuantumCircuit.from_qasm_str(Path(r['source']).read_text().replace('OPENQASM 3;', 'OPENQASM 2.0;'));ref=effects(source);refmap=mapping(source)
 for name in ['input','qllvm','catalyst','catalyst_fusion']:
  try:
   if name.startswith('catalyst'):
    data=json.loads((d/(name+'.json')).read_text());qc=QuantumCircuit(data['n'],data['ncl'])
    for gate,ps,ws in data['gates']:getattr(qc,gate)(*ps,*ws)
    for q,c in data['measurements']:qc.measure(q,c)
    qasm2.dump(qc,d/(name+'.qasm'))
   else:qc=qasm2.load(d/(name+'.qasm'))
   g,depth=metrics(qc);out[name+'_gates']=g;out[name+'_depth']=depth;out[name+'_sha256']=hashlib.sha256((d/(name+'.qasm')).read_bytes()).hexdigest()
   assert mapping(qc)==refmap,(name,mapping(qc),refmap)
   e=effects(qc);assert set(e)==set(ref)
   err=max(float(np.linalg.norm(e[k]-ref[k])) for k in ref);out[name+'_max_povm_frobenius_error']=err;out[name+'_verified']=err<1e-9
  except Exception:out[name+'_analysis_error']=traceback.format_exc();out[name+'_verified']=False
 for baseline in ['catalyst','catalyst_fusion']:
  out[baseline+'_both_verified']=all(out[n+'_verified'] for n in ['input','qllvm',baseline])
  if out[baseline+'_both_verified']:
   out[baseline+'_gate_reduction_pct']=100*(1-out['qllvm_gates']/out[baseline+'_gates']);out[baseline+'_depth_reduction_pct']=100*(1-out['qllvm_depth']/out[baseline+'_depth'])
 results.append(out);print(r['case'],[out[n+'_verified'] for n in ['input','qllvm','catalyst','catalyst_fusion']],flush=True)
(P/'results.json').write_text(json.dumps(results,indent=2))
summary={'selected':len(records),'families':len(set(r['family'] for r in records)),'qubits':sorted(set(r['qubits'] for r in records)),'scope':protocol['limits'],'semantic_verified':{n:sum(r[n+'_verified'] for r in results) for n in ['input','qllvm','catalyst','catalyst_fusion']}}
for baseline in ['catalyst','catalyst_fusion']:
 valid=[r for r in results if r[baseline+'_both_verified']];s={'verified_pairs':len(valid),'unresolved':len(results)-len(valid)}
 for metric in ['gate','depth']:
  values=[r[baseline+'_'+metric+'_reduction_pct'] for r in valid];s[metric]={'mean_reduction_pct':float(np.mean(values)),'median_reduction_pct':float(np.median(values)),'lower':sum(v>1e-10 for v in values),'equal':sum(abs(v)<1e-10 for v in values),'higher':sum(v< -1e-10 for v in values)}
 summary[baseline]=s
summary['max_povm_error']={n:max(r[n+'_max_povm_frobenius_error'] for r in results if n+'_max_povm_frobenius_error' in r) for n in ['input','qllvm','catalyst','catalyst_fusion']}
summary['failures']=[{'case':r['case'],'qllvm_status':r['qllvm_status'],'qllvm_error':r.get('qllvm_error',''),'failed_checks':[n for n in ['input','qllvm','catalyst','catalyst_fusion'] if not r[n+'_verified']]} for r in results if not all(r[n+'_verified'] for n in ['input','qllvm','catalyst','catalyst_fusion'])]
(P/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
fields=['case','family','qubits']+[n+'_'+m for n in ['input','qllvm','catalyst','catalyst_fusion'] for m in ['verified','gates','depth','max_povm_frobenius_error']]+[n+'_'+m+'_reduction_pct' for n in ['catalyst','catalyst_fusion'] for m in ['gate','depth']]
with (P/'paired_results.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(results)
