from pathlib import Path
import csv,json,hashlib
from qiskit import QuantumCircuit,transpile,qasm2
R=Path('/home/easyai/qllvm-r14-claims-20261101'); A=Path('/home/easyai/论文/QLLVM/QLLVM-202610/返修/experiments/recovery_campaign')
rows=list(csv.DictReader((A/'C06_quality_statistics/paired_quality.csv').open()))
selected=sorted([r for r in rows if int(r['qubits']) in [4,6,8]],key=lambda r:r['case'])
protocol={'selection':'All archived 430-suite cases with widths in {4,6,8}, frozen before output comparison','n':len(selected),'basis':['rx','ry','rz','h','cz'],'qiskit_input_normalization':'Qiskit 1.2.4 transpile optimization_level=0, seed_transpiler=0; barriers removed; terminal measurements retained','catalyst':'0.15.0, default qjit pipeline plus explicit merge_rotations then cancel_inverses MLIR transforms; QuantumCompilationStage output extracted','qllvm':'frozen corrected qllvm-compile -O1 -exact-rotations, same basis','semantics':'Complete computational-basis terminal measurement effects for arbitrary input; row-phase-aligned operator residual gives an upper bound on each POVM effect residual, threshold 1e-9','metrics':'gate count and ASAP logical depth excluding measurements and barriers; equal-weight per-circuit percentage reductions','limits':'exploratory subset and named configured pipeline only; no exhaustive pipeline search, routing, timing or general LLVM/MLIR ranking'}
(R/'pilot/protocol.json').write_text(json.dumps(protocol,indent=2))
manifest=[]
for r in selected:
 case=r['case'];folder=R/'pilot/cases'/case;folder.mkdir(parents=True,exist_ok=True)
 src=A/'A16_exact_quality/native/work'/(case+'_O1')/'input.qasm'
 qc=QuantumCircuit.from_qasm_str(src.read_text().replace('OPENQASM 3;', 'OPENQASM 2.0;'));qc.data=[i for i in qc.data if i.operation.name!='barrier']
 qc=transpile(qc,basis_gates=protocol['basis'],optimization_level=0,seed_transpiler=0)
 gates=[];meas=[];terminal=False
 for i in qc.data:
  op=i.operation; wires=[qc.find_bit(q).index for q in i.qubits]
  if op.name=='measure':terminal=True;meas.append([wires[0],qc.find_bit(i.clbits[0]).index])
  else:
   assert not terminal and op.name in protocol['basis'],op.name
   gates.append([op.name,[float(x) for x in op.params],wires])
 assert len(set(q for q,c in meas))==len(meas) and len(meas)>0
 assert len(set(c for q,c in meas))==len(meas)
 qasm2.dump(qc,folder/'input.qasm')
 (folder/'input.json').write_text(json.dumps({'n':qc.num_qubits,'ncl':qc.num_clbits,'gates':gates,'measurements':meas}))
 manifest.append({'case':case,'family':r['family'],'qubits':qc.num_qubits,'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'input_sha256':hashlib.sha256((folder/'input.qasm').read_bytes()).hexdigest()})
(R/'pilot/manifest.json').write_text(json.dumps(manifest,indent=2))
print(protocol);print('families',len(set(r['family'] for r in manifest)))
