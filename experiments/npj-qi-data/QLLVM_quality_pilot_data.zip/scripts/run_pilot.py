from pathlib import Path
import json,subprocess,os,re,traceback,time,hashlib
import pennylane as qml
from catalyst import qjit
from catalyst.debug import get_compilation_stage
from catalyst.passes import cancel_inverses,merge_rotations
R=Path('/home/easyai/qllvm-r14-claims-20261101');P=R/'pilot'
compiler=Path('/home/easyai/论文/QLLVM/QLLVM-202610/返修/compiler_revision/foundation_corrected/bin/qllvm-compile')
manifest=json.loads((P/'manifest.json').read_text());results=[]
ops={'rx':qml.RX,'ry':qml.RY,'rz':qml.RZ,'h':qml.Hadamard,'cz':qml.CZ}
def extract(s,dat):
 const={};wire={};gates=[];seen_sample=False
 for line in s.splitlines():
  if m:=re.search(r'(%[\w]+) = arith.constant (\S+) : f64',line):const[m[1]]=float(m[2])
  if m:=re.search(r'(%[\w]+) = quantum.extract %[\w]+\[\s*(\d+)\]',line):wire[m[1]]=int(m[2])
  if 'quantum.custom ' in line:
   m=re.search(r'(%[\w]+)(?::(\d+))? = quantum.custom "([^"]+)"\(([^)]*)\) (.*?) : ',line);assert m,line
   out,num,name,args,ins=m.groups();ws=[wire[v.strip()] for v in ins.split(',')];ps=[const[v.strip()] for v in args.split(',') if v.strip()]
   name={'RX':'rx','RY':'ry','RZ':'rz','Hadamard':'h','CZ':'cz'}[name]
   assert len(ws)==(int(num) if num else 1)
   for i,w in enumerate(ws):wire[out+('#'+str(i) if num else '')]=w
   gates.append([name,ps,ws])
  if 'quantum.compbasis ' in line:
   m=re.search(r'quantum.compbasis qubits (.*?) :',line);assert m,line
   assert [wire[v.strip()] for v in m[1].split(',')]==[q for q,c in dat['measurements']]
  if 'quantum.sample ' in line:seen_sample=True
  if 'quantum.' in line:
   assert any('quantum.'+op in line for op in ['device','alloc','extract','custom','compbasis','sample','insert','dealloc','device_release','init','finalize']),line
 assert seen_sample
 return gates
for k,row in enumerate(manifest):
 d=P/'cases'/row['case'];dat=json.loads((d/'input.json').read_text());record=dict(row);os.chdir(d)
 try:
  @qml.set_shots(128)
  @qml.qnode(qml.device('lightning.qubit',wires=dat['n']))
  def circuit():
   for name,ps,ws in dat['gates']:ops[name](*ps,wires=ws)
   return qml.sample(wires=[q for q,c in dat['measurements']])
  compiled=qjit(cancel_inverses(merge_rotations(circuit)),keep_intermediate=True)
  compiled();mlir=get_compilation_stage(compiled,'QuantumCompilationStage');(d/'catalyst.mlir').write_text(mlir)
  gout=extract(mlir,dat);(d/'catalyst.json').write_text(json.dumps(dict(dat,gates=gout)))
  record['catalyst_status']='compiled_extracted'
 except Exception as e:record['catalyst_status']='failed';record['catalyst_error']=traceback.format_exc()
 cmd=[str(compiler),'input.qasm','-qrt','nisq','-qpu','qasm-backend','-O1','-emit-backend=qasm-backend','-output-path='+str(d/'qllvm.qasm'),'-basicgate=[rx,ry,rz,h,cz]','-approx-report='+str(d/'budget.json'),'-exact-rotations']
 env=dict(os.environ);env['LD_LIBRARY_PATH']=str(compiler.parent.parent/'lib')+':'+env.get('LD_LIBRARY_PATH','')
 try:
  p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90);(d/'qllvm.log').write_bytes(p.stdout)
  record['qllvm_status']='compiled' if p.returncode==0 and (d/'qllvm.qasm').exists() else 'failed';record['qllvm_returncode']=p.returncode
 except Exception:record['qllvm_status']='failed';record['qllvm_error']=traceback.format_exc()
 record['qllvm_command']=cmd;results.append(record);(P/'compile_results.json').write_text(json.dumps(results,indent=2))
 print(k+1,len(manifest),row['case'],record['catalyst_status'],record['qllvm_status'],flush=True)
 if k==0 and (record['qllvm_status']=='failed' or record['catalyst_status']=='failed'):break
