module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -1.5707911073828997 : f64
    %cst_0 = arith.constant -0.17610354992151755 : f64
    %cst_1 = arith.constant -0.73550702104138121 : f64
    %cst_2 = arith.constant -4.0277004956568163E-5 : f64
    %cst_3 = arith.constant 2.7039013891175525 : f64
    %cst_4 = arith.constant -2.9067698463776908 : f64
    %cst_5 = arith.constant -0.1567241720089223 : f64
    %cst_6 = arith.constant -2.4519337502360017E-4 : f64
    %cst_7 = arith.constant 2.0087396210066659 : f64
    %cst_8 = arith.constant 6.8778739174879533E-4 : f64
    %cst_9 = arith.constant 0.72173469529952383 : f64
    %cst_10 = arith.constant 7.8539816339744828 : f64
    %cst_11 = arith.constant -3.1414779034331315 : f64
    %cst_12 = arith.constant -1.5707963267948966 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst_12) %1 : !quantum.bit
    %out_qubits_13 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_14 = quantum.custom "RZ"(%cst_11) %out_qubits_13 : !quantum.bit
    %out_qubits_15 = quantum.custom "Hadamard"() %out_qubits_14 : !quantum.bit
    %out_qubits_16 = quantum.custom "RZ"(%cst_10) %out_qubits_15 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_17 = quantum.custom "RZ"(%cst_12) %2 : !quantum.bit
    %out_qubits_18 = quantum.custom "Hadamard"() %out_qubits_17 : !quantum.bit
    %out_qubits_19 = quantum.custom "RZ"(%cst_9) %out_qubits_18 : !quantum.bit
    %out_qubits_20 = quantum.custom "Hadamard"() %out_qubits_19 : !quantum.bit
    %out_qubits_21 = quantum.custom "RZ"(%cst_10) %out_qubits_20 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_22 = quantum.custom "RZ"(%cst_12) %3 : !quantum.bit
    %out_qubits_23 = quantum.custom "Hadamard"() %out_qubits_22 : !quantum.bit
    %out_qubits_24 = quantum.custom "RZ"(%cst_8) %out_qubits_23 : !quantum.bit
    %out_qubits_25 = quantum.custom "Hadamard"() %out_qubits_24 : !quantum.bit
    %out_qubits_26 = quantum.custom "RZ"(%cst_10) %out_qubits_25 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_27 = quantum.custom "RZ"(%cst_12) %4 : !quantum.bit
    %out_qubits_28 = quantum.custom "Hadamard"() %out_qubits_27 : !quantum.bit
    %out_qubits_29 = quantum.custom "RZ"(%cst_7) %out_qubits_28 : !quantum.bit
    %out_qubits_30 = quantum.custom "Hadamard"() %out_qubits_29 : !quantum.bit
    %out_qubits_31 = quantum.custom "RZ"(%cst_10) %out_qubits_30 : !quantum.bit
    %out_qubits_32 = quantum.custom "Hadamard"() %out_qubits_31 : !quantum.bit
    %out_qubits_33:2 = quantum.custom "CZ"() %out_qubits_26, %out_qubits_32 : !quantum.bit, !quantum.bit
    %out_qubits_34 = quantum.custom "Hadamard"() %out_qubits_33#0 : !quantum.bit
    %out_qubits_35:2 = quantum.custom "CZ"() %out_qubits_21, %out_qubits_34 : !quantum.bit, !quantum.bit
    %out_qubits_36 = quantum.custom "Hadamard"() %out_qubits_35#0 : !quantum.bit
    %out_qubits_37:2 = quantum.custom "CZ"() %out_qubits_16, %out_qubits_36 : !quantum.bit, !quantum.bit
    %out_qubits_38 = quantum.custom "RZ"(%cst_12) %out_qubits_37#0 : !quantum.bit
    %out_qubits_39 = quantum.custom "Hadamard"() %out_qubits_38 : !quantum.bit
    %out_qubits_40 = quantum.custom "RZ"(%cst_6) %out_qubits_39 : !quantum.bit
    %out_qubits_41 = quantum.custom "Hadamard"() %out_qubits_40 : !quantum.bit
    %out_qubits_42 = quantum.custom "RZ"(%cst_10) %out_qubits_41 : !quantum.bit
    %out_qubits_43 = quantum.custom "Hadamard"() %out_qubits_37#1 : !quantum.bit
    %out_qubits_44 = quantum.custom "RZ"(%cst_12) %out_qubits_43 : !quantum.bit
    %out_qubits_45 = quantum.custom "Hadamard"() %out_qubits_44 : !quantum.bit
    %out_qubits_46 = quantum.custom "RZ"(%cst_5) %out_qubits_45 : !quantum.bit
    %out_qubits_47 = quantum.custom "Hadamard"() %out_qubits_46 : !quantum.bit
    %out_qubits_48 = quantum.custom "RZ"(%cst_10) %out_qubits_47 : !quantum.bit
    %out_qubits_49 = quantum.custom "Hadamard"() %out_qubits_35#1 : !quantum.bit
    %out_qubits_50 = quantum.custom "RZ"(%cst_12) %out_qubits_49 : !quantum.bit
    %out_qubits_51 = quantum.custom "Hadamard"() %out_qubits_50 : !quantum.bit
    %out_qubits_52 = quantum.custom "RZ"(%cst_4) %out_qubits_51 : !quantum.bit
    %out_qubits_53 = quantum.custom "Hadamard"() %out_qubits_52 : !quantum.bit
    %out_qubits_54 = quantum.custom "RZ"(%cst_10) %out_qubits_53 : !quantum.bit
    %out_qubits_55 = quantum.custom "Hadamard"() %out_qubits_33#1 : !quantum.bit
    %out_qubits_56 = quantum.custom "RZ"(%cst_12) %out_qubits_55 : !quantum.bit
    %out_qubits_57 = quantum.custom "Hadamard"() %out_qubits_56 : !quantum.bit
    %out_qubits_58 = quantum.custom "RZ"(%cst_3) %out_qubits_57 : !quantum.bit
    %out_qubits_59 = quantum.custom "Hadamard"() %out_qubits_58 : !quantum.bit
    %out_qubits_60 = quantum.custom "RZ"(%cst_10) %out_qubits_59 : !quantum.bit
    %out_qubits_61 = quantum.custom "Hadamard"() %out_qubits_60 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_54, %out_qubits_61 : !quantum.bit, !quantum.bit
    %out_qubits_63 = quantum.custom "Hadamard"() %out_qubits_62#0 : !quantum.bit
    %out_qubits_64:2 = quantum.custom "CZ"() %out_qubits_48, %out_qubits_63 : !quantum.bit, !quantum.bit
    %out_qubits_65 = quantum.custom "Hadamard"() %out_qubits_64#0 : !quantum.bit
    %out_qubits_66:2 = quantum.custom "CZ"() %out_qubits_42, %out_qubits_65 : !quantum.bit, !quantum.bit
    %out_qubits_67 = quantum.custom "RZ"(%cst_12) %out_qubits_66#0 : !quantum.bit
    %out_qubits_68 = quantum.custom "Hadamard"() %out_qubits_67 : !quantum.bit
    %out_qubits_69 = quantum.custom "RZ"(%cst_2) %out_qubits_68 : !quantum.bit
    %out_qubits_70 = quantum.custom "Hadamard"() %out_qubits_69 : !quantum.bit
    %out_qubits_71 = quantum.custom "RZ"(%cst_10) %out_qubits_70 : !quantum.bit
    %out_qubits_72 = quantum.custom "Hadamard"() %out_qubits_66#1 : !quantum.bit
    %out_qubits_73 = quantum.custom "RZ"(%cst_12) %out_qubits_72 : !quantum.bit
    %out_qubits_74 = quantum.custom "Hadamard"() %out_qubits_73 : !quantum.bit
    %out_qubits_75 = quantum.custom "RZ"(%cst_1) %out_qubits_74 : !quantum.bit
    %out_qubits_76 = quantum.custom "Hadamard"() %out_qubits_75 : !quantum.bit
    %out_qubits_77 = quantum.custom "RZ"(%cst_10) %out_qubits_76 : !quantum.bit
    %out_qubits_78 = quantum.custom "Hadamard"() %out_qubits_64#1 : !quantum.bit
    %out_qubits_79 = quantum.custom "RZ"(%cst_12) %out_qubits_78 : !quantum.bit
    %out_qubits_80 = quantum.custom "Hadamard"() %out_qubits_79 : !quantum.bit
    %out_qubits_81 = quantum.custom "RZ"(%cst_0) %out_qubits_80 : !quantum.bit
    %out_qubits_82 = quantum.custom "Hadamard"() %out_qubits_81 : !quantum.bit
    %out_qubits_83 = quantum.custom "RZ"(%cst_10) %out_qubits_82 : !quantum.bit
    %out_qubits_84 = quantum.custom "Hadamard"() %out_qubits_62#1 : !quantum.bit
    %out_qubits_85 = quantum.custom "RZ"(%cst_12) %out_qubits_84 : !quantum.bit
    %out_qubits_86 = quantum.custom "Hadamard"() %out_qubits_85 : !quantum.bit
    %out_qubits_87 = quantum.custom "RZ"(%cst) %out_qubits_86 : !quantum.bit
    %out_qubits_88 = quantum.custom "Hadamard"() %out_qubits_87 : !quantum.bit
    %out_qubits_89 = quantum.custom "RZ"(%cst_10) %out_qubits_88 : !quantum.bit
    %5 = quantum.compbasis qubits %out_qubits_71, %out_qubits_77, %out_qubits_83, %out_qubits_89 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_71 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_77 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_83 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_89 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}