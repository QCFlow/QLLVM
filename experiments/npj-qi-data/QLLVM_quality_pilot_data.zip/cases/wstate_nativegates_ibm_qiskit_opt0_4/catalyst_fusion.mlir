module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -4.7123889803846897 : f64
    %cst_0 = arith.constant -47.123889803846929 : f64
    %cst_1 = arith.constant 7.8539816339744828 : f64
    %cst_2 = arith.constant 10.995574287564276 : f64
    %cst_3 = arith.constant 0.000000e+00 : f64
    %cst_4 = arith.constant 0.78539816339744783 : f64
    %cst_5 = arith.constant -6.6613381477509392E-16 : f64
    %cst_6 = arith.constant -1.5707963267948963 : f64
    %cst_7 = arith.constant 0.9553166181245093 : f64
    %cst_8 = arith.constant -2.2204460492503131E-16 : f64
    %cst_9 = arith.constant 1.047197551196597 : f64
    %cst_10 = arith.constant 3.3306690738754696E-16 : f64
    %cst_11 = arith.constant -1.5707963267948966 : f64
    %cst_12 = arith.constant 3.1415926535897931 : f64
    %cst_13 = arith.constant 1.5707963267948966 : f64
    %cst_14 = arith.constant 1.0471975511965979 : f64
    %cst_15 = arith.constant 3.1415926535897927 : f64
    %cst_16 = arith.constant 0.95531661812450885 : f64
    %cst_17 = arith.constant 3.1415926535897936 : f64
    %cst_18 = arith.constant 3.1415926535897922 : f64
    %cst_19 = arith.constant 0.78539816339744839 : f64
    %cst_20 = arith.constant 3.141592653589794 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_21 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %2 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_22 = quantum.custom "Rot"(%cst_17, %cst_14, %cst_15) %3 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_23 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %4 : !quantum.bit
    %out_qubits_24:2 = quantum.custom "CZ"() %out_qubits_23, %out_qubits_22 : !quantum.bit, !quantum.bit
    %out_qubits_25 = quantum.custom "Rot"(%cst_10, %cst_9, %cst_11) %out_qubits_24#1 : !quantum.bit
    %out_qubits_26:2 = quantum.custom "CZ"() %out_qubits_25, %out_qubits_21 : !quantum.bit, !quantum.bit
    %out_qubits_27 = quantum.custom "Rot"(%cst_8, %cst_7, %cst_6) %out_qubits_26#1 : !quantum.bit
    %out_qubits_28:2 = quantum.custom "CZ"() %out_qubits_27, %out_qubits : !quantum.bit, !quantum.bit
    %out_qubits_29 = quantum.custom "Rot"(%cst_5, %cst_4, %cst_11) %out_qubits_28#1 : !quantum.bit
    %out_qubits_30 = quantum.custom "Rot"(%cst_12, %cst_13, %cst_3) %out_qubits_24#0 : !quantum.bit
    %out_qubits_31:2 = quantum.custom "CZ"() %out_qubits_26#0, %out_qubits_30 : !quantum.bit, !quantum.bit
    %out_qubits_32 = quantum.custom "Rot"(%cst_2, %cst_13, %cst_3) %out_qubits_31#0 : !quantum.bit
    %out_qubits_33:2 = quantum.custom "CZ"() %out_qubits_28#0, %out_qubits_32 : !quantum.bit, !quantum.bit
    %out_qubits_34 = quantum.custom "Rot"(%cst_2, %cst_13, %cst_3) %out_qubits_33#0 : !quantum.bit
    %out_qubits_35:2 = quantum.custom "CZ"() %out_qubits_29, %out_qubits_34 : !quantum.bit, !quantum.bit
    %out_qubits_36 = quantum.custom "RZ"(%cst_1) %out_qubits_35#0 : !quantum.bit
    %out_qubits_37 = quantum.custom "Hadamard"() %out_qubits_35#1 : !quantum.bit
    %out_qubits_38 = quantum.custom "Hadamard"() %out_qubits_33#1 : !quantum.bit
    %out_qubits_39 = quantum.custom "Hadamard"() %out_qubits_31#1 : !quantum.bit
    quantum.gphase(%cst_0)
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_36, %out_qubits_37, %out_qubits_38, %out_qubits_39 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_36 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_37 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_38 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_39 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}