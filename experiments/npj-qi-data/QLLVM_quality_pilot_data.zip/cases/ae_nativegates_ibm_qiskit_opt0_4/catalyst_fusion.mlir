module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -69.115038378975484 : f64
    %cst_0 = arith.constant 9.4247779607693793 : f64
    %cst_1 = arith.constant 1.0032081083782409 : f64
    %cst_2 = arith.constant -6.6613381477509392E-16 : f64
    %cst_3 = arith.constant -0.39269908169872414 : f64
    %cst_4 = arith.constant -0.78539816339744828 : f64
    %cst_5 = arith.constant 1.9634954084936207 : f64
    %cst_6 = arith.constant -1.5707963267948966 : f64
    %cst_7 = arith.constant 0.3926990816987232 : f64
    %cst_8 = arith.constant 0.78539816339744839 : f64
    %cst_9 = arith.constant 1.1780972450961724 : f64
    %cst_10 = arith.constant 4.3196898986859651 : f64
    %cst_11 = arith.constant -1.5707963267948963 : f64
    %cst_12 = arith.constant 0.78539816339744783 : f64
    %cst_13 = arith.constant -4.7123889803846897 : f64
    %cst_14 = arith.constant 4.7123889803846897 : f64
    %cst_15 = arith.constant 3.1415926535897936 : f64
    %cst_16 = arith.constant 2.5740044351731379 : f64
    %cst_17 = arith.constant 1.854590436003225 : f64
    %cst_18 = arith.constant -3.1415926535897931 : f64
    %cst_19 = arith.constant 1.8545904360032237 : f64
    %cst_20 = arith.constant -3.1415926535897936 : f64
    %cst_21 = arith.constant -3.1415926535897927 : f64
    %cst_22 = arith.constant -6.2831853071795862 : f64
    %cst_23 = arith.constant 0.92729521800161285 : f64
    %cst_24 = arith.constant -4.4408920985006262E-16 : f64
    %cst_25 = arith.constant 8.8817841970012523E-16 : f64
    %cst_26 = arith.constant 0.64350110879328382 : f64
    %cst_27 = arith.constant 3.1415926535897922 : f64
    %cst_28 = arith.constant 0.000000e+00 : f64
    %cst_29 = arith.constant 1.5707963267948966 : f64
    %cst_30 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_31 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %2 : !quantum.bit
    %3 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits_32 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %3 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_33 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %4 : !quantum.bit
    %out_qubits_34:2 = quantum.custom "CZ"() %out_qubits_32, %out_qubits_33 : !quantum.bit, !quantum.bit
    %out_qubits_35 = quantum.custom "Rot"(%cst_24, %cst_23, %cst_22) %out_qubits_34#1 : !quantum.bit
    %out_qubits_36:2 = quantum.custom "CZ"() %out_qubits_34#0, %out_qubits_35 : !quantum.bit, !quantum.bit
    %out_qubits_37 = quantum.custom "Rot"(%cst_21, %cst_23, %cst_20) %out_qubits_36#1 : !quantum.bit
    %out_qubits_38:2 = quantum.custom "CZ"() %out_qubits_31, %out_qubits_37 : !quantum.bit, !quantum.bit
    %out_qubits_39 = quantum.custom "Rot"(%cst_28, %cst_19, %cst_22) %out_qubits_38#1 : !quantum.bit
    %out_qubits_40:2 = quantum.custom "CZ"() %out_qubits_38#0, %out_qubits_39 : !quantum.bit, !quantum.bit
    %out_qubits_41 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_18) %out_qubits_40#1 : !quantum.bit
    %out_qubits_42:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_41 : !quantum.bit, !quantum.bit
    %out_qubits_43 = quantum.custom "Rot"(%cst_21, %cst_16, %cst_15) %out_qubits_42#1 : !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_42#0, %out_qubits_43 : !quantum.bit, !quantum.bit
    %out_qubits_45 = quantum.custom "Rot"(%cst_14, %cst_28, %cst_29) %out_qubits_44#0 : !quantum.bit
    %out_qubits_46:2 = quantum.custom "CZ"() %out_qubits_40#0, %out_qubits_45 : !quantum.bit, !quantum.bit
    %out_qubits_47 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_46#1 : !quantum.bit
    %out_qubits_48:2 = quantum.custom "CZ"() %out_qubits_46#0, %out_qubits_47 : !quantum.bit, !quantum.bit
    %out_qubits_49 = quantum.custom "Rot"(%cst_10, %cst_28, %cst_9) %out_qubits_48#0 : !quantum.bit
    %out_qubits_50 = quantum.custom "Rot"(%cst_14, %cst_8, %cst_29) %out_qubits_48#1 : !quantum.bit
    %out_qubits_51:2 = quantum.custom "CZ"() %out_qubits_36#0, %out_qubits_50 : !quantum.bit, !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_13, %cst_7, %cst_6) %out_qubits_51#1 : !quantum.bit
    %out_qubits_53:2 = quantum.custom "CZ"() %out_qubits_51#0, %out_qubits_52 : !quantum.bit, !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_53#0, %out_qubits_49 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_54#1 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_54#0, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_5, %cst_29, %cst_28) %out_qubits_56#0 : !quantum.bit
    %out_qubits_58 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_4) %out_qubits_56#1 : !quantum.bit
    %out_qubits_59 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_3) %out_qubits_53#1 : !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_2, %cst_1, %cst_0) %out_qubits_44#1 : !quantum.bit
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_57, %out_qubits_58, %out_qubits_59, %out_qubits_60 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_57 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_58 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_59 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_60 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}