module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 0.000000e+00 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst) %1 : !quantum.bit
    %out_qubits_0 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_1 = quantum.custom "RZ"(%cst) %out_qubits_0 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_2 = quantum.custom "RZ"(%cst) %2 : !quantum.bit
    %out_qubits_3 = quantum.custom "Hadamard"() %out_qubits_2 : !quantum.bit
    %out_qubits_4 = quantum.custom "RZ"(%cst) %out_qubits_3 : !quantum.bit
    %out_qubits_5 = quantum.custom "Hadamard"() %out_qubits_4 : !quantum.bit
    %out_qubits_6 = quantum.custom "RZ"(%cst) %out_qubits_5 : !quantum.bit
    %out_qubits_7 = quantum.custom "Hadamard"() %out_qubits_6 : !quantum.bit
    %out_qubits_8:2 = quantum.custom "CZ"() %out_qubits_1, %out_qubits_7 : !quantum.bit, !quantum.bit
    %out_qubits_9 = quantum.custom "Hadamard"() %out_qubits_8#1 : !quantum.bit
    %out_qubits_10 = quantum.custom "RZ"(%cst) %out_qubits_9 : !quantum.bit
    %out_qubits_11 = quantum.custom "Hadamard"() %out_qubits_10 : !quantum.bit
    %out_qubits_12 = quantum.custom "RZ"(%cst) %out_qubits_11 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_13 = quantum.custom "RZ"(%cst) %3 : !quantum.bit
    %out_qubits_14 = quantum.custom "Hadamard"() %out_qubits_13 : !quantum.bit
    %out_qubits_15 = quantum.custom "RZ"(%cst) %out_qubits_14 : !quantum.bit
    %out_qubits_16 = quantum.custom "Hadamard"() %out_qubits_15 : !quantum.bit
    %out_qubits_17 = quantum.custom "RZ"(%cst) %out_qubits_16 : !quantum.bit
    %out_qubits_18 = quantum.custom "Hadamard"() %out_qubits_17 : !quantum.bit
    %out_qubits_19:2 = quantum.custom "CZ"() %out_qubits_12, %out_qubits_18 : !quantum.bit, !quantum.bit
    %out_qubits_20 = quantum.custom "Hadamard"() %out_qubits_19#1 : !quantum.bit
    %out_qubits_21 = quantum.custom "RZ"(%cst) %out_qubits_20 : !quantum.bit
    %out_qubits_22 = quantum.custom "Hadamard"() %out_qubits_21 : !quantum.bit
    %out_qubits_23 = quantum.custom "RZ"(%cst) %out_qubits_22 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_24 = quantum.custom "RZ"(%cst) %4 : !quantum.bit
    %out_qubits_25 = quantum.custom "Hadamard"() %out_qubits_24 : !quantum.bit
    %out_qubits_26 = quantum.custom "RZ"(%cst) %out_qubits_25 : !quantum.bit
    %out_qubits_27 = quantum.custom "Hadamard"() %out_qubits_26 : !quantum.bit
    %out_qubits_28 = quantum.custom "RZ"(%cst) %out_qubits_27 : !quantum.bit
    %out_qubits_29 = quantum.custom "Hadamard"() %out_qubits_28 : !quantum.bit
    %out_qubits_30:2 = quantum.custom "CZ"() %out_qubits_8#0, %out_qubits_29 : !quantum.bit, !quantum.bit
    %out_qubits_31 = quantum.custom "Hadamard"() %out_qubits_30#1 : !quantum.bit
    %out_qubits_32 = quantum.custom "RZ"(%cst) %out_qubits_31 : !quantum.bit
    %out_qubits_33 = quantum.custom "Hadamard"() %out_qubits_32 : !quantum.bit
    %out_qubits_34 = quantum.custom "RZ"(%cst) %out_qubits_33 : !quantum.bit
    %out_qubits_35 = quantum.custom "Hadamard"() %out_qubits_34 : !quantum.bit
    %out_qubits_36 = quantum.custom "RZ"(%cst) %out_qubits_35 : !quantum.bit
    %out_qubits_37 = quantum.custom "Hadamard"() %out_qubits_36 : !quantum.bit
    %out_qubits_38:2 = quantum.custom "CZ"() %out_qubits_23, %out_qubits_37 : !quantum.bit, !quantum.bit
    %out_qubits_39 = quantum.custom "Hadamard"() %out_qubits_38#1 : !quantum.bit
    %out_qubits_40 = quantum.custom "RZ"(%cst) %out_qubits_39 : !quantum.bit
    %out_qubits_41 = quantum.custom "Hadamard"() %out_qubits_40 : !quantum.bit
    %out_qubits_42 = quantum.custom "RZ"(%cst) %out_qubits_41 : !quantum.bit
    %5 = quantum.compbasis qubits %out_qubits_30#0, %out_qubits_19#0, %out_qubits_38#0, %out_qubits_42 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_30#0 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_19#0 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_38#0 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_42 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}