module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -169.64600329384854 : f64
    %cst_0 = arith.constant 1.6710555259169391 : f64
    %cst_1 = arith.constant 9.4247779607693793 : f64
    %cst_2 = arith.constant 2.709332149091332 : f64
    %cst_3 = arith.constant 3.1415926535897922 : f64
    %cst_4 = arith.constant 0.17765087020501297 : f64
    %cst_5 = arith.constant 6.2831853071795871 : f64
    %cst_6 = arith.constant 2.4746056121253206 : f64
    %cst_7 = arith.constant 6.6613381477509392E-16 : f64
    %cst_8 = arith.constant 3.1227147462145619 : f64
    %cst_9 = arith.constant 4.4408920985006262E-16 : f64
    %cst_10 = arith.constant 0.29177204019726333 : f64
    %cst_11 = arith.constant 6.2831853071795862 : f64
    %cst_12 = arith.constant 0.46080300094621218 : f64
    %cst_13 = arith.constant 0.90092704918009425 : f64
    %cst_14 = arith.constant 2.4594805172854706 : f64
    %cst_15 = arith.constant 0.47705683624546064 : f64
    %cst_16 = arith.constant 3.1415926535897905 : f64
    %cst_17 = arith.constant 2.6467295877062336 : f64
    %cst_18 = arith.constant -3.141592653589794 : f64
    %cst_19 = arith.constant 2.4462375208697802 : f64
    %cst_20 = arith.constant 3.1415926535897913 : f64
    %cst_21 = arith.constant 3.1415926535897927 : f64
    %cst_22 = arith.constant 1.7225808710927764 : f64
    %cst_23 = arith.constant -3.1415926535897927 : f64
    %cst_24 = arith.constant 3.1415926535897931 : f64
    %cst_25 = arith.constant 1.9599706708457578 : f64
    %cst_26 = arith.constant -3.1415926535897931 : f64
    %cst_27 = arith.constant -1.5707963267948959 : f64
    %cst_28 = arith.constant 2.4125893649182828 : f64
    %cst_29 = arith.constant -4.7123889803846897 : f64
    %cst_30 = arith.constant 3.1415926535897936 : f64
    %cst_31 = arith.constant 2.6834097120775624 : f64
    %cst_32 = arith.constant -3.1415926535897918 : f64
    %cst_33 = arith.constant 6.2831853071795827 : f64
    %cst_34 = arith.constant 3.0761801615674145 : f64
    %cst_35 = arith.constant -2.6645352591003757E-15 : f64
    %cst_36 = arith.constant 3.9968028886505635E-15 : f64
    %cst_37 = arith.constant 2.9808572300959053 : f64
    %cst_38 = arith.constant -6.2831853071795809 : f64
    %cst_39 = arith.constant -1.5707963267948963 : f64
    %cst_40 = arith.constant 0.88110552521121299 : f64
    %cst_41 = arith.constant 1.5707963267948963 : f64
    %cst_42 = arith.constant 3.1415926535897847 : f64
    %cst_43 = arith.constant 0.040169293116261197 : f64
    %cst_44 = arith.constant -3.1415926535897847 : f64
    %cst_45 = arith.constant -3.1415926535897962 : f64
    %cst_46 = arith.constant 2.9209172271090029 : f64
    %cst_47 = arith.constant 3.1415926535897891 : f64
    %cst_48 = arith.constant 1.5707963267948966 : f64
    %cst_49 = arith.constant 1.002813228816168 : f64
    %cst_50 = arith.constant -1.570796326794897 : f64
    %cst_51 = arith.constant 0.000000e+00 : f64
    %cst_52 = arith.constant 2.6471950457471496 : f64
    %cst_53 = arith.constant 2.2204460492503131E-16 : f64
    %cst_54 = arith.constant 4.7123889803846897 : f64
    %cst_55 = arith.constant 0.36395151082109051 : f64
    %cst_56 = arith.constant -4.4408920985006262E-16 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_56, %cst_55, %cst_54) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_53, %cst_52, %cst_51) %2 : !quantum.bit
    %out_qubits_58:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_57 : !quantum.bit, !quantum.bit
    %out_qubits_59 = quantum.custom "Rot"(%cst_50, %cst_49, %cst_48) %out_qubits_58#0 : !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_54, %cst_51, %cst_48) %out_qubits_58#1 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_61 = quantum.custom "Rot"(%cst_47, %cst_46, %cst_45) %3 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_60, %out_qubits_61 : !quantum.bit, !quantum.bit
    %out_qubits_63 = quantum.custom "Rot"(%cst_44, %cst_43, %cst_42) %out_qubits_62#0 : !quantum.bit
    %out_qubits_64:2 = quantum.custom "CZ"() %out_qubits_59, %out_qubits_63 : !quantum.bit, !quantum.bit
    %out_qubits_65 = quantum.custom "Rot"(%cst_41, %cst_40, %cst_39) %out_qubits_64#0 : !quantum.bit
    %out_qubits_66 = quantum.custom "Rot"(%cst_54, %cst_51, %cst_48) %out_qubits_64#1 : !quantum.bit
    %out_qubits_67 = quantum.custom "Rot"(%cst_54, %cst_51, %cst_48) %out_qubits_62#1 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_68 = quantum.custom "Rot"(%cst_38, %cst_37, %cst_36) %4 : !quantum.bit
    %out_qubits_69:2 = quantum.custom "CZ"() %out_qubits_67, %out_qubits_68 : !quantum.bit, !quantum.bit
    %out_qubits_70 = quantum.custom "Rot"(%cst_35, %cst_34, %cst_33) %out_qubits_69#0 : !quantum.bit
    %out_qubits_71:2 = quantum.custom "CZ"() %out_qubits_66, %out_qubits_70 : !quantum.bit, !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_32, %cst_31, %cst_30) %out_qubits_71#0 : !quantum.bit
    %out_qubits_73:2 = quantum.custom "CZ"() %out_qubits_65, %out_qubits_72 : !quantum.bit, !quantum.bit
    %out_qubits_74 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_27) %out_qubits_73#0 : !quantum.bit
    %out_qubits_75 = quantum.custom "Rot"(%cst_54, %cst_51, %cst_48) %out_qubits_73#1 : !quantum.bit
    %out_qubits_76 = quantum.custom "Rot"(%cst_54, %cst_51, %cst_48) %out_qubits_71#1 : !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_26, %cst_25, %cst_24) %out_qubits_69#1 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_76, %out_qubits_77 : !quantum.bit, !quantum.bit
    %out_qubits_79 = quantum.custom "Rot"(%cst_23, %cst_22, %cst_21) %out_qubits_78#0 : !quantum.bit
    %out_qubits_80:2 = quantum.custom "CZ"() %out_qubits_75, %out_qubits_79 : !quantum.bit, !quantum.bit
    %out_qubits_81 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_80#0 : !quantum.bit
    %out_qubits_82:2 = quantum.custom "CZ"() %out_qubits_74, %out_qubits_81 : !quantum.bit, !quantum.bit
    %out_qubits_83 = quantum.custom "Rot"(%cst_29, %cst_17, %cst_27) %out_qubits_82#0 : !quantum.bit
    %out_qubits_84 = quantum.custom "Rot"(%cst_54, %cst_51, %cst_48) %out_qubits_82#1 : !quantum.bit
    %out_qubits_85 = quantum.custom "Rot"(%cst_54, %cst_51, %cst_48) %out_qubits_80#1 : !quantum.bit
    %out_qubits_86 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_24) %out_qubits_78#1 : !quantum.bit
    %out_qubits_87:2 = quantum.custom "CZ"() %out_qubits_85, %out_qubits_86 : !quantum.bit, !quantum.bit
    %out_qubits_88 = quantum.custom "Rot"(%cst_53, %cst_14, %cst_51) %out_qubits_87#0 : !quantum.bit
    %out_qubits_89:2 = quantum.custom "CZ"() %out_qubits_84, %out_qubits_88 : !quantum.bit, !quantum.bit
    %out_qubits_90 = quantum.custom "Rot"(%cst_23, %cst_13, %cst_21) %out_qubits_89#0 : !quantum.bit
    %out_qubits_91:2 = quantum.custom "CZ"() %out_qubits_83, %out_qubits_90 : !quantum.bit, !quantum.bit
    %out_qubits_92 = quantum.custom "Rot"(%cst_41, %cst_12, %cst_11) %out_qubits_91#0 : !quantum.bit
    %out_qubits_93 = quantum.custom "Rot"(%cst_54, %cst_51, %cst_48) %out_qubits_91#1 : !quantum.bit
    %out_qubits_94 = quantum.custom "Rot"(%cst_54, %cst_51, %cst_48) %out_qubits_89#1 : !quantum.bit
    %out_qubits_95 = quantum.custom "Rot"(%cst_21, %cst_10, %cst_30) %out_qubits_87#1 : !quantum.bit
    %out_qubits_96:2 = quantum.custom "CZ"() %out_qubits_94, %out_qubits_95 : !quantum.bit, !quantum.bit
    %out_qubits_97 = quantum.custom "Rot"(%cst_9, %cst_8, %cst_51) %out_qubits_96#0 : !quantum.bit
    %out_qubits_98:2 = quantum.custom "CZ"() %out_qubits_93, %out_qubits_97 : !quantum.bit, !quantum.bit
    %out_qubits_99 = quantum.custom "Rot"(%cst_7, %cst_6, %cst_5) %out_qubits_98#0 : !quantum.bit
    %out_qubits_100 = quantum.custom "Rot"(%cst_54, %cst_51, %cst_48) %out_qubits_98#1 : !quantum.bit
    %out_qubits_101 = quantum.custom "Rot"(%cst_9, %cst_4, %cst_11) %out_qubits_96#1 : !quantum.bit
    %out_qubits_102:2 = quantum.custom "CZ"() %out_qubits_100, %out_qubits_101 : !quantum.bit, !quantum.bit
    %out_qubits_103 = quantum.custom "Rot"(%cst_3, %cst_2, %cst_1) %out_qubits_102#0 : !quantum.bit
    %out_qubits_104 = quantum.custom "Rot"(%cst_51, %cst_0, %cst_11) %out_qubits_102#1 : !quantum.bit
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_92, %out_qubits_99, %out_qubits_103, %out_qubits_104 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_92 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_99 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_103 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_104 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}