module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -199.49113350295147 : f64
    %cst_0 = arith.constant 0.39269908169872414 : f64
    %cst_1 = arith.constant -3.410670816452944 : f64
    %cst_2 = arith.constant 0.26907816286315067 : f64
    %cst_3 = arith.constant -3.1415926535897936 : f64
    %cst_4 = arith.constant 1.5707963267948972 : f64
    %cst_5 = arith.constant 0.78539816339744717 : f64
    %cst_6 = arith.constant 1.5707963267948959 : f64
    %cst_7 = arith.constant -2.3561944901923453 : f64
    %cst_8 = arith.constant 3.9269908169872414 : f64
    %cst_9 = arith.constant -1.5707963267948963 : f64
    %cst_10 = arith.constant 0.78539816339744783 : f64
    %cst_11 = arith.constant 0.78539816339744839 : f64
    %cst_12 = arith.constant 1.767145867644258 : f64
    %cst_13 = arith.constant -5.8904862254808625 : f64
    %cst_14 = arith.constant 3.5342917352885173 : f64
    %cst_15 = arith.constant 2.748893571891069 : f64
    %cst_16 = arith.constant -1.5707963267948966 : f64
    %cst_17 = arith.constant 0.3926990816987232 : f64
    %cst_18 = arith.constant -4.7123889803846897 : f64
    %cst_19 = arith.constant 0.39269908169872436 : f64
    %cst_20 = arith.constant 1.5707963267948968 : f64
    %cst_21 = arith.constant 3.1415926535897931 : f64
    %cst_22 = arith.constant 1.5707963267948966 : f64
    %cst_23 = arith.constant 0.000000e+00 : f64
    %cst_24 = arith.constant 4.7123889803846897 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_24, %cst_23, %cst_22) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_25 = quantum.custom "Rot"(%cst_24, %cst_23, %cst_22) %2 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_26 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %3 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_27 = quantum.custom "Rot"(%cst_21, %cst_20, %cst_21) %4 : !quantum.bit
    %out_qubits_28:2 = quantum.custom "CZ"() %out_qubits_26, %out_qubits_27 : !quantum.bit, !quantum.bit
    %out_qubits_29 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_28#1 : !quantum.bit
    %out_qubits_30:2 = quantum.custom "CZ"() %out_qubits_28#0, %out_qubits_29 : !quantum.bit, !quantum.bit
    %out_qubits_31:2 = quantum.custom "CZ"() %out_qubits_30#0, %out_qubits_25 : !quantum.bit, !quantum.bit
    %out_qubits_32 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_31#1 : !quantum.bit
    %out_qubits_33 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_30#1 : !quantum.bit
    %out_qubits_34:2 = quantum.custom "CZ"() %out_qubits_32, %out_qubits_33 : !quantum.bit, !quantum.bit
    %out_qubits_35 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_34#1 : !quantum.bit
    %out_qubits_36:2 = quantum.custom "CZ"() %out_qubits_34#0, %out_qubits_35 : !quantum.bit, !quantum.bit
    %out_qubits_37 = quantum.custom "Rot"(%cst_15, %cst_22, %cst_23) %out_qubits_36#0 : !quantum.bit
    %out_qubits_38:2 = quantum.custom "CZ"() %out_qubits_31#0, %out_qubits_37 : !quantum.bit, !quantum.bit
    %out_qubits_39 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_38#1 : !quantum.bit
    %out_qubits_40 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_36#1 : !quantum.bit
    %out_qubits_41:2 = quantum.custom "CZ"() %out_qubits_39, %out_qubits_40 : !quantum.bit, !quantum.bit
    %out_qubits_42 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_41#1 : !quantum.bit
    %out_qubits_43:2 = quantum.custom "CZ"() %out_qubits_41#0, %out_qubits_42 : !quantum.bit, !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_43#0, %out_qubits : !quantum.bit, !quantum.bit
    %out_qubits_45 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_44#1 : !quantum.bit
    %out_qubits_46 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_43#1 : !quantum.bit
    %out_qubits_47:2 = quantum.custom "CZ"() %out_qubits_45, %out_qubits_46 : !quantum.bit, !quantum.bit
    %out_qubits_48 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_47#1 : !quantum.bit
    %out_qubits_49:2 = quantum.custom "CZ"() %out_qubits_47#0, %out_qubits_48 : !quantum.bit, !quantum.bit
    %out_qubits_50 = quantum.custom "Rot"(%cst_15, %cst_22, %cst_23) %out_qubits_49#0 : !quantum.bit
    %out_qubits_51:2 = quantum.custom "CZ"() %out_qubits_38#0, %out_qubits_50 : !quantum.bit, !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_51#1 : !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_49#1 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_52, %out_qubits_53 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_54#1 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_54#0, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_14, %cst_22, %cst_23) %out_qubits_56#0 : !quantum.bit
    %out_qubits_58:2 = quantum.custom "CZ"() %out_qubits_44#0, %out_qubits_57 : !quantum.bit, !quantum.bit
    %out_qubits_59 = quantum.custom "Rot"(%cst_13, %cst_20, %cst_23) %out_qubits_58#0 : !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_58#1 : !quantum.bit
    %out_qubits_61 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_56#1 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_60, %out_qubits_61 : !quantum.bit, !quantum.bit
    %out_qubits_63 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_62#1 : !quantum.bit
    %out_qubits_64:2 = quantum.custom "CZ"() %out_qubits_62#0, %out_qubits_63 : !quantum.bit, !quantum.bit
    %out_qubits_65 = quantum.custom "Rot"(%cst_15, %cst_22, %cst_23) %out_qubits_64#0 : !quantum.bit
    %out_qubits_66:2 = quantum.custom "CZ"() %out_qubits_51#0, %out_qubits_65 : !quantum.bit, !quantum.bit
    %out_qubits_67 = quantum.custom "Rot"(%cst_12, %cst_23, %cst_12) %out_qubits_66#0 : !quantum.bit
    %out_qubits_68:2 = quantum.custom "CZ"() %out_qubits_59, %out_qubits_67 : !quantum.bit, !quantum.bit
    %out_qubits_69 = quantum.custom "Rot"(%cst_24, %cst_11, %cst_22) %out_qubits_68#1 : !quantum.bit
    %out_qubits_70 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_66#1 : !quantum.bit
    %out_qubits_71 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_64#1 : !quantum.bit
    %out_qubits_72:2 = quantum.custom "CZ"() %out_qubits_70, %out_qubits_71 : !quantum.bit, !quantum.bit
    %out_qubits_73 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_72#1 : !quantum.bit
    %out_qubits_74:2 = quantum.custom "CZ"() %out_qubits_72#0, %out_qubits_73 : !quantum.bit, !quantum.bit
    %out_qubits_75 = quantum.custom "Rot"(%cst_13, %cst_20, %cst_23) %out_qubits_74#0 : !quantum.bit
    %out_qubits_76:2 = quantum.custom "CZ"() %out_qubits_75, %out_qubits_69 : !quantum.bit, !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_18, %cst_10, %cst_9) %out_qubits_76#1 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_68#0, %out_qubits_77 : !quantum.bit, !quantum.bit
    %out_qubits_79 = quantum.custom "Rot"(%cst_8, %cst_22, %cst_23) %out_qubits_78#0 : !quantum.bit
    %out_qubits_80 = quantum.custom "Rot"(%cst_24, %cst_11, %cst_22) %out_qubits_78#1 : !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_76#0, %out_qubits_80 : !quantum.bit, !quantum.bit
    %out_qubits_82:2 = quantum.custom "CZ"() %out_qubits_81#0, %out_qubits_79 : !quantum.bit, !quantum.bit
    %out_qubits_83 = quantum.custom "Rot"(%cst_24, %cst_11, %cst_22) %out_qubits_82#1 : !quantum.bit
    %out_qubits_84:2 = quantum.custom "CZ"() %out_qubits_82#0, %out_qubits_83 : !quantum.bit, !quantum.bit
    %out_qubits_85 = quantum.custom "Rot"(%cst_7, %cst_21, %cst_23) %out_qubits_84#0 : !quantum.bit
    %out_qubits_86 = quantum.custom "Rot"(%cst_23, %cst_22, %cst_23) %out_qubits_84#1 : !quantum.bit
    %out_qubits_87 = quantum.custom "Rot"(%cst_6, %cst_5, %cst_4) %out_qubits_81#1 : !quantum.bit
    %out_qubits_88 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_74#1 : !quantum.bit
    %out_qubits_89:2 = quantum.custom "CZ"() %out_qubits_87, %out_qubits_88 : !quantum.bit, !quantum.bit
    %out_qubits_90 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_89#1 : !quantum.bit
    %out_qubits_91:2 = quantum.custom "CZ"() %out_qubits_89#0, %out_qubits_90 : !quantum.bit, !quantum.bit
    %out_qubits_92:2 = quantum.custom "CZ"() %out_qubits_91#0, %out_qubits_86 : !quantum.bit, !quantum.bit
    %out_qubits_93 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_92#1 : !quantum.bit
    %out_qubits_94 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_91#1 : !quantum.bit
    %out_qubits_95:2 = quantum.custom "CZ"() %out_qubits_93, %out_qubits_94 : !quantum.bit, !quantum.bit
    %out_qubits_96 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_95#1 : !quantum.bit
    %out_qubits_97:2 = quantum.custom "CZ"() %out_qubits_95#0, %out_qubits_96 : !quantum.bit, !quantum.bit
    %out_qubits_98 = quantum.custom "Rot"(%cst_15, %cst_22, %cst_23) %out_qubits_97#0 : !quantum.bit
    %out_qubits_99:2 = quantum.custom "CZ"() %out_qubits_92#0, %out_qubits_98 : !quantum.bit, !quantum.bit
    %out_qubits_100 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_99#1 : !quantum.bit
    %out_qubits_101 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_97#1 : !quantum.bit
    %out_qubits_102:2 = quantum.custom "CZ"() %out_qubits_100, %out_qubits_101 : !quantum.bit, !quantum.bit
    %out_qubits_103 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_102#1 : !quantum.bit
    %out_qubits_104:2 = quantum.custom "CZ"() %out_qubits_102#0, %out_qubits_103 : !quantum.bit, !quantum.bit
    %out_qubits_105:2 = quantum.custom "CZ"() %out_qubits_104#0, %out_qubits_85 : !quantum.bit, !quantum.bit
    %out_qubits_106 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_105#1 : !quantum.bit
    %out_qubits_107 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_104#1 : !quantum.bit
    %out_qubits_108:2 = quantum.custom "CZ"() %out_qubits_106, %out_qubits_107 : !quantum.bit, !quantum.bit
    %out_qubits_109 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_108#1 : !quantum.bit
    %out_qubits_110:2 = quantum.custom "CZ"() %out_qubits_108#0, %out_qubits_109 : !quantum.bit, !quantum.bit
    %out_qubits_111 = quantum.custom "Rot"(%cst_15, %cst_22, %cst_23) %out_qubits_110#0 : !quantum.bit
    %out_qubits_112:2 = quantum.custom "CZ"() %out_qubits_99#0, %out_qubits_111 : !quantum.bit, !quantum.bit
    %out_qubits_113 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_112#1 : !quantum.bit
    %out_qubits_114 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_110#1 : !quantum.bit
    %out_qubits_115:2 = quantum.custom "CZ"() %out_qubits_113, %out_qubits_114 : !quantum.bit, !quantum.bit
    %out_qubits_116 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_115#1 : !quantum.bit
    %out_qubits_117:2 = quantum.custom "CZ"() %out_qubits_115#0, %out_qubits_116 : !quantum.bit, !quantum.bit
    %out_qubits_118 = quantum.custom "Rot"(%cst_14, %cst_22, %cst_23) %out_qubits_117#0 : !quantum.bit
    %out_qubits_119:2 = quantum.custom "CZ"() %out_qubits_105#0, %out_qubits_118 : !quantum.bit, !quantum.bit
    %out_qubits_120 = quantum.custom "Rot"(%cst_13, %cst_20, %cst_23) %out_qubits_119#0 : !quantum.bit
    %out_qubits_121 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_119#1 : !quantum.bit
    %out_qubits_122 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_117#1 : !quantum.bit
    %out_qubits_123:2 = quantum.custom "CZ"() %out_qubits_121, %out_qubits_122 : !quantum.bit, !quantum.bit
    %out_qubits_124 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_123#1 : !quantum.bit
    %out_qubits_125:2 = quantum.custom "CZ"() %out_qubits_123#0, %out_qubits_124 : !quantum.bit, !quantum.bit
    %out_qubits_126 = quantum.custom "Rot"(%cst_15, %cst_22, %cst_23) %out_qubits_125#0 : !quantum.bit
    %out_qubits_127:2 = quantum.custom "CZ"() %out_qubits_112#0, %out_qubits_126 : !quantum.bit, !quantum.bit
    %out_qubits_128 = quantum.custom "Rot"(%cst_12, %cst_23, %cst_12) %out_qubits_127#0 : !quantum.bit
    %out_qubits_129:2 = quantum.custom "CZ"() %out_qubits_120, %out_qubits_128 : !quantum.bit, !quantum.bit
    %out_qubits_130 = quantum.custom "Rot"(%cst_24, %cst_11, %cst_22) %out_qubits_129#1 : !quantum.bit
    %out_qubits_131 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_23) %out_qubits_127#1 : !quantum.bit
    %out_qubits_132 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_125#1 : !quantum.bit
    %out_qubits_133:2 = quantum.custom "CZ"() %out_qubits_131, %out_qubits_132 : !quantum.bit, !quantum.bit
    %out_qubits_134 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_22) %out_qubits_133#1 : !quantum.bit
    %out_qubits_135:2 = quantum.custom "CZ"() %out_qubits_133#0, %out_qubits_134 : !quantum.bit, !quantum.bit
    %out_qubits_136 = quantum.custom "Rot"(%cst_13, %cst_20, %cst_23) %out_qubits_135#0 : !quantum.bit
    %out_qubits_137:2 = quantum.custom "CZ"() %out_qubits_136, %out_qubits_130 : !quantum.bit, !quantum.bit
    %out_qubits_138 = quantum.custom "Rot"(%cst_18, %cst_10, %cst_9) %out_qubits_137#1 : !quantum.bit
    %out_qubits_139:2 = quantum.custom "CZ"() %out_qubits_129#0, %out_qubits_138 : !quantum.bit, !quantum.bit
    %out_qubits_140 = quantum.custom "Rot"(%cst_8, %cst_22, %cst_23) %out_qubits_139#0 : !quantum.bit
    %out_qubits_141 = quantum.custom "Rot"(%cst_24, %cst_11, %cst_22) %out_qubits_139#1 : !quantum.bit
    %out_qubits_142:2 = quantum.custom "CZ"() %out_qubits_137#0, %out_qubits_141 : !quantum.bit, !quantum.bit
    %out_qubits_143:2 = quantum.custom "CZ"() %out_qubits_142#0, %out_qubits_140 : !quantum.bit, !quantum.bit
    %out_qubits_144 = quantum.custom "Rot"(%cst_24, %cst_11, %cst_22) %out_qubits_143#1 : !quantum.bit
    %out_qubits_145:2 = quantum.custom "CZ"() %out_qubits_143#0, %out_qubits_144 : !quantum.bit, !quantum.bit
    %out_qubits_146 = quantum.custom "Rot"(%cst_7, %cst_20, %cst_3) %out_qubits_145#0 : !quantum.bit
    %out_qubits_147 = quantum.custom "Rot"(%cst_2, %cst_23, %cst_1) %out_qubits_145#1 : !quantum.bit
    %out_qubits_148 = quantum.custom "Rot"(%cst_6, %cst_5, %cst_4) %out_qubits_142#1 : !quantum.bit
    %out_qubits_149 = quantum.custom "Rot"(%cst_21, %cst_22, %cst_0) %out_qubits_135#1 : !quantum.bit
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_146, %out_qubits_147, %out_qubits_148, %out_qubits_149 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_146 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_147 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_148 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_149 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}