module @circuit {
  func.func public @jit_circuit() -> tensor<128x5xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x5xi64>
    return %0 : tensor<128x5xi64>
  }
  func.func public @circuit_0() -> tensor<128x5xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -128.80529879718136 : f64
    %cst_0 = arith.constant -0.78539816339744828 : f64
    %cst_1 = arith.constant 1.6689710972195777 : f64
    %cst_2 = arith.constant 2.454369260617026 : f64
    %cst_3 = arith.constant -0.39269908169872414 : f64
    %cst_4 = arith.constant 1.2762720155208536 : f64
    %cst_5 = arith.constant 2.8470683423157501 : f64
    %cst_6 = arith.constant -0.19634954084936207 : f64
    %cst_7 = arith.constant 4.3196898986859651 : f64
    %cst_8 = arith.constant -0.098174770424681035 : f64
    %cst_9 = arith.constant 0.098174770424680535 : f64
    %cst_10 = arith.constant 1.570796326794897 : f64
    %cst_11 = arith.constant 0.19634954084936121 : f64
    %cst_12 = arith.constant 0.39269908169872436 : f64
    %cst_13 = arith.constant 0.3926990816987232 : f64
    %cst_14 = arith.constant 4.466952054322987 : f64
    %cst_15 = arith.constant 0.78539816339744839 : f64
    %cst_16 = arith.constant 2.6507188014663878 : f64
    %cst_17 = arith.constant 1.178097245096172 : f64
    %cst_18 = arith.constant 0.24543692606170264 : f64
    %cst_19 = arith.constant 0.78539816339744783 : f64
    %cst_20 = arith.constant 1.1780972450961724 : f64
    %cst_21 = arith.constant -1.5707963267948963 : f64
    %cst_22 = arith.constant 0.98174770424681035 : f64
    %cst_23 = arith.constant 0.49087385212340534 : f64
    %cst_24 = arith.constant -4.7123889803846897 : f64
    %cst_25 = arith.constant 1.3253594007331941 : f64
    %cst_26 = arith.constant -1.5707963267948966 : f64
    %cst_27 = arith.constant 3.1415926535897931 : f64
    %cst_28 = arith.constant 1.5707963267948966 : f64
    %cst_29 = arith.constant 0.000000e+00 : f64
    %cst_30 = arith.constant 4.7123889803846897 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %1 : !quantum.bit
    %2 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_31 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %2 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_32 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %3 : !quantum.bit
    %4 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_33 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %4 : !quantum.bit
    %5 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits_34 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %5 : !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_35 = quantum.custom "Rot"(%cst_28, %cst_27, %cst_26) %6 : !quantum.bit
    %out_qubits_36:2 = quantum.custom "CZ"() %out_qubits_35, %out_qubits_34 : !quantum.bit, !quantum.bit
    %out_qubits_37 = quantum.custom "Rot"(%cst_30, %cst_25, %cst_28) %out_qubits_36#1 : !quantum.bit
    %out_qubits_38:2 = quantum.custom "CZ"() %out_qubits_36#0, %out_qubits_37 : !quantum.bit, !quantum.bit
    %out_qubits_39:2 = quantum.custom "CZ"() %out_qubits_38#0, %out_qubits_33 : !quantum.bit, !quantum.bit
    %out_qubits_40 = quantum.custom "Rot"(%cst_24, %cst_23, %cst_26) %out_qubits_39#1 : !quantum.bit
    %out_qubits_41:2 = quantum.custom "CZ"() %out_qubits_39#0, %out_qubits_40 : !quantum.bit, !quantum.bit
    %out_qubits_42:2 = quantum.custom "CZ"() %out_qubits_41#0, %out_qubits_32 : !quantum.bit, !quantum.bit
    %out_qubits_43 = quantum.custom "Rot"(%cst_24, %cst_22, %cst_21) %out_qubits_42#1 : !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_42#0, %out_qubits_43 : !quantum.bit, !quantum.bit
    %out_qubits_45:2 = quantum.custom "CZ"() %out_qubits_44#0, %out_qubits_31 : !quantum.bit, !quantum.bit
    %out_qubits_46 = quantum.custom "Rot"(%cst_30, %cst_20, %cst_28) %out_qubits_45#1 : !quantum.bit
    %out_qubits_47:2 = quantum.custom "CZ"() %out_qubits_45#0, %out_qubits_46 : !quantum.bit, !quantum.bit
    %out_qubits_48:2 = quantum.custom "CZ"() %out_qubits_47#0, %out_qubits : !quantum.bit, !quantum.bit
    %out_qubits_49 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_21) %out_qubits_48#1 : !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits_48#0, %out_qubits_49 : !quantum.bit, !quantum.bit
    %out_qubits_51 = quantum.custom "RZ"(%cst_18) %out_qubits_50#0 : !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_29) %out_qubits_41#1 : !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_24, %cst_17, %cst_21) %out_qubits_47#1 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_52, %out_qubits_53 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_16, %cst_28, %cst_29) %out_qubits_54#0 : !quantum.bit
    %out_qubits_56 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_29) %out_qubits_54#1 : !quantum.bit
    %out_qubits_57:2 = quantum.custom "CZ"() %out_qubits_56, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_58 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_29) %out_qubits_57#1 : !quantum.bit
    %out_qubits_59 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_29) %out_qubits_57#0 : !quantum.bit
    %out_qubits_60:2 = quantum.custom "CZ"() %out_qubits_58, %out_qubits_59 : !quantum.bit, !quantum.bit
    %out_qubits_61 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_29) %out_qubits_60#1 : !quantum.bit
    %out_qubits_62 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_29) %out_qubits_44#1 : !quantum.bit
    %out_qubits_63 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_29) %out_qubits_38#1 : !quantum.bit
    %out_qubits_64 = quantum.custom "Rot"(%cst_30, %cst_15, %cst_28) %out_qubits_50#1 : !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_63, %out_qubits_64 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "Rot"(%cst_14, %cst_28, %cst_29) %out_qubits_65#0 : !quantum.bit
    %out_qubits_67 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_29) %out_qubits_65#1 : !quantum.bit
    %out_qubits_68:2 = quantum.custom "CZ"() %out_qubits_67, %out_qubits_66 : !quantum.bit, !quantum.bit
    %out_qubits_69 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_29) %out_qubits_68#1 : !quantum.bit
    %out_qubits_70 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_29) %out_qubits_68#0 : !quantum.bit
    %out_qubits_71:2 = quantum.custom "CZ"() %out_qubits_69, %out_qubits_70 : !quantum.bit, !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %out_qubits_71#0 : !quantum.bit
    %out_qubits_73:2 = quantum.custom "CZ"() %out_qubits_60#0, %out_qubits_72 : !quantum.bit, !quantum.bit
    %out_qubits_74 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_21) %out_qubits_73#1 : !quantum.bit
    %out_qubits_75:2 = quantum.custom "CZ"() %out_qubits_73#0, %out_qubits_74 : !quantum.bit, !quantum.bit
    %out_qubits_76 = quantum.custom "Rot"(%cst_30, %cst_15, %cst_28) %out_qubits_75#1 : !quantum.bit
    %out_qubits_77:2 = quantum.custom "CZ"() %out_qubits_62, %out_qubits_76 : !quantum.bit, !quantum.bit
    %out_qubits_78 = quantum.custom "Rot"(%cst_24, %cst_13, %cst_26) %out_qubits_77#1 : !quantum.bit
    %out_qubits_79:2 = quantum.custom "CZ"() %out_qubits_77#0, %out_qubits_78 : !quantum.bit, !quantum.bit
    %out_qubits_80 = quantum.custom "Rot"(%cst_30, %cst_12, %cst_28) %out_qubits_79#1 : !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_61, %out_qubits_80 : !quantum.bit, !quantum.bit
    %out_qubits_82 = quantum.custom "Rot"(%cst_28, %cst_11, %cst_30) %out_qubits_81#1 : !quantum.bit
    %out_qubits_83:2 = quantum.custom "CZ"() %out_qubits_81#0, %out_qubits_82 : !quantum.bit, !quantum.bit
    %out_qubits_84 = quantum.custom "Rot"(%cst_30, %cst_11, %cst_10) %out_qubits_83#1 : !quantum.bit
    %out_qubits_85 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_29) %out_qubits_71#1 : !quantum.bit
    %out_qubits_86:2 = quantum.custom "CZ"() %out_qubits_85, %out_qubits_84 : !quantum.bit, !quantum.bit
    %out_qubits_87 = quantum.custom "Rot"(%cst_28, %cst_9, %cst_30) %out_qubits_86#1 : !quantum.bit
    %out_qubits_88:2 = quantum.custom "CZ"() %out_qubits_86#0, %out_qubits_87 : !quantum.bit, !quantum.bit
    %out_qubits_89 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_8) %out_qubits_88#1 : !quantum.bit
    %out_qubits_90 = quantum.custom "Rot"(%cst_7, %cst_29, %cst_20) %out_qubits_75#0 : !quantum.bit
    %out_qubits_91:2 = quantum.custom "CZ"() %out_qubits_79#0, %out_qubits_90 : !quantum.bit, !quantum.bit
    %out_qubits_92 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_21) %out_qubits_91#1 : !quantum.bit
    %out_qubits_93:2 = quantum.custom "CZ"() %out_qubits_91#0, %out_qubits_92 : !quantum.bit, !quantum.bit
    %out_qubits_94 = quantum.custom "Rot"(%cst_30, %cst_15, %cst_28) %out_qubits_93#1 : !quantum.bit
    %out_qubits_95:2 = quantum.custom "CZ"() %out_qubits_83#0, %out_qubits_94 : !quantum.bit, !quantum.bit
    %out_qubits_96 = quantum.custom "Rot"(%cst_24, %cst_13, %cst_26) %out_qubits_95#1 : !quantum.bit
    %out_qubits_97:2 = quantum.custom "CZ"() %out_qubits_95#0, %out_qubits_96 : !quantum.bit, !quantum.bit
    %out_qubits_98 = quantum.custom "Rot"(%cst_30, %cst_12, %cst_28) %out_qubits_97#1 : !quantum.bit
    %out_qubits_99:2 = quantum.custom "CZ"() %out_qubits_88#0, %out_qubits_98 : !quantum.bit, !quantum.bit
    %out_qubits_100 = quantum.custom "Rot"(%cst_28, %cst_11, %cst_30) %out_qubits_99#1 : !quantum.bit
    %out_qubits_101:2 = quantum.custom "CZ"() %out_qubits_99#0, %out_qubits_100 : !quantum.bit, !quantum.bit
    %out_qubits_102 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_6) %out_qubits_101#1 : !quantum.bit
    %out_qubits_103 = quantum.custom "Rot"(%cst_5, %cst_29, %cst_4) %out_qubits_93#0 : !quantum.bit
    %out_qubits_104:2 = quantum.custom "CZ"() %out_qubits_97#0, %out_qubits_103 : !quantum.bit, !quantum.bit
    %out_qubits_105 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_21) %out_qubits_104#1 : !quantum.bit
    %out_qubits_106:2 = quantum.custom "CZ"() %out_qubits_104#0, %out_qubits_105 : !quantum.bit, !quantum.bit
    %out_qubits_107 = quantum.custom "Rot"(%cst_30, %cst_15, %cst_28) %out_qubits_106#1 : !quantum.bit
    %out_qubits_108:2 = quantum.custom "CZ"() %out_qubits_101#0, %out_qubits_107 : !quantum.bit, !quantum.bit
    %out_qubits_109 = quantum.custom "Rot"(%cst_24, %cst_13, %cst_26) %out_qubits_108#1 : !quantum.bit
    %out_qubits_110:2 = quantum.custom "CZ"() %out_qubits_108#0, %out_qubits_109 : !quantum.bit, !quantum.bit
    %out_qubits_111 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_3) %out_qubits_110#1 : !quantum.bit
    %out_qubits_112 = quantum.custom "Rot"(%cst_2, %cst_29, %cst_2) %out_qubits_106#0 : !quantum.bit
    %out_qubits_113:2 = quantum.custom "CZ"() %out_qubits_110#0, %out_qubits_112 : !quantum.bit, !quantum.bit
    %out_qubits_114 = quantum.custom "Rot"(%cst_24, %cst_19, %cst_21) %out_qubits_113#1 : !quantum.bit
    %out_qubits_115:2 = quantum.custom "CZ"() %out_qubits_113#0, %out_qubits_114 : !quantum.bit, !quantum.bit
    %out_qubits_116 = quantum.custom "Rot"(%cst_1, %cst_28, %cst_29) %out_qubits_115#0 : !quantum.bit
    %out_qubits_117 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_0) %out_qubits_115#1 : !quantum.bit
    quantum.gphase(%cst)
    %7 = quantum.compbasis qubits %out_qubits_89, %out_qubits_102, %out_qubits_111, %out_qubits_117, %out_qubits_116 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x5xf64>
    %9 = stablehlo.convert %8 : (tensor<128x5xf64>) -> tensor<128x5xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_89 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_102 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_111 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_117 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_116 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_51 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x5xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}