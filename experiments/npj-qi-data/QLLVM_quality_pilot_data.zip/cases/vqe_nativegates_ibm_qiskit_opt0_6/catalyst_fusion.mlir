module @circuit {
  func.func public @jit_circuit() -> tensor<128x6xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x6xi64>
    return %0 : tensor<128x6xi64>
  }
  func.func public @circuit_0() -> tensor<128x6xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -87.964594300514178 : f64
    %cst_0 = arith.constant 9.4247779607693793 : f64
    %cst_1 = arith.constant 3.1365869526172379 : f64
    %cst_2 = arith.constant -1.1102230246251565E-16 : f64
    %cst_3 = arith.constant 6.2831853071722978 : f64
    %cst_4 = arith.constant 3.1415818827814452 : f64
    %cst_5 = arith.constant -3.1415926535970824 : f64
    %cst_6 = arith.constant 6.2831853071756427 : f64
    %cst_7 = arith.constant 7.9628726982077433E-5 : f64
    %cst_8 = arith.constant -3.1415926535858496 : f64
    %cst_9 = arith.constant 3.1415926535954704 : f64
    %cst_10 = arith.constant 5.5306116963275317E-5 : f64
    %cst_11 = arith.constant -5.6776805479330505E-12 : f64
    %cst_12 = arith.constant 3.1415863732850822 : f64
    %cst_13 = arith.constant 6.2831853071795862 : f64
    %cst_14 = arith.constant 1.5709436065295852 : f64
    %cst_15 = arith.constant -6.2831853071795862 : f64
    %cst_16 = arith.constant 1.1880425310715019 : f64
    %cst_17 = arith.constant -4.7123889803846897 : f64
    %cst_18 = arith.constant 0.82945716297280403 : f64
    %cst_19 = arith.constant -4.4408920985006262E-16 : f64
    %cst_20 = arith.constant 3.1415740051571568 : f64
    %cst_21 = arith.constant -1.5707963267962091 : f64
    %cst_22 = arith.constant 3.1415328401505622 : f64
    %cst_23 = arith.constant -3.1415926535911058 : f64
    %cst_24 = arith.constant -1.5707963267948966 : f64
    %cst_25 = arith.constant 3.1415483545953493 : f64
    %cst_26 = arith.constant -3.1415926535897931 : f64
    %cst_27 = arith.constant 1.5709447087028612 : f64
    %cst_28 = arith.constant -1.570796326794897 : f64
    %cst_29 = arith.constant 10.995574287564276 : f64
    %cst_30 = arith.constant -3.1415926535897203 : f64
    %cst_31 = arith.constant 3.1348608821617825 : f64
    %cst_32 = arith.constant 7.2608585810485238E-14 : f64
    %cst_33 = arith.constant 4.7123889803846897 : f64
    %cst_34 = arith.constant 0.82961368064130314 : f64
    %cst_35 = arith.constant 1.5707963267931886 : f64
    %cst_36 = arith.constant 3.1413628696553593 : f64
    %cst_37 = arith.constant 3.1415926535880851 : f64
    %cst_38 = arith.constant 0.000000e+00 : f64
    %cst_39 = arith.constant 1.5707963267948966 : f64
    %cst_40 = arith.constant 3.2447968804733447E-5 : f64
    %cst_41 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_41, %cst_40, %cst_39) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_42 = quantum.custom "Rot"(%cst_39, %cst_41, %cst_38) %2 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_43 = quantum.custom "Rot"(%cst_37, %cst_36, %cst_35) %3 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_44 = quantum.custom "Rot"(%cst_39, %cst_41, %cst_38) %4 : !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_45 = quantum.custom "Rot"(%cst_38, %cst_34, %cst_33) %5 : !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_46 = quantum.custom "Rot"(%cst_32, %cst_31, %cst_30) %6 : !quantum.bit
    %out_qubits_47:2 = quantum.custom "CZ"() %out_qubits_45, %out_qubits_46 : !quantum.bit, !quantum.bit
    %out_qubits_48 = quantum.custom "Rot"(%cst_29, %cst_39, %cst_38) %out_qubits_47#0 : !quantum.bit
    %out_qubits_49:2 = quantum.custom "CZ"() %out_qubits_44, %out_qubits_48 : !quantum.bit, !quantum.bit
    %out_qubits_50 = quantum.custom "Rot"(%cst_29, %cst_39, %cst_38) %out_qubits_49#0 : !quantum.bit
    %out_qubits_51:2 = quantum.custom "CZ"() %out_qubits_43, %out_qubits_50 : !quantum.bit, !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_29, %cst_39, %cst_38) %out_qubits_51#0 : !quantum.bit
    %out_qubits_53:2 = quantum.custom "CZ"() %out_qubits_42, %out_qubits_52 : !quantum.bit, !quantum.bit
    %out_qubits_54 = quantum.custom "Rot"(%cst_29, %cst_39, %cst_38) %out_qubits_53#0 : !quantum.bit
    %out_qubits_55:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_54 : !quantum.bit, !quantum.bit
    %out_qubits_56 = quantum.custom "Rot"(%cst_28, %cst_27, %cst_39) %out_qubits_55#0 : !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_26, %cst_25, %cst_24) %out_qubits_55#1 : !quantum.bit
    %out_qubits_58 = quantum.custom "Rot"(%cst_23, %cst_22, %cst_21) %out_qubits_53#1 : !quantum.bit
    %out_qubits_59 = quantum.custom "Rot"(%cst_26, %cst_20, %cst_24) %out_qubits_51#1 : !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_19, %cst_18, %cst_17) %out_qubits_49#1 : !quantum.bit
    %out_qubits_61 = quantum.custom "Rot"(%cst_19, %cst_16, %cst_15) %out_qubits_47#1 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_60, %out_qubits_61 : !quantum.bit, !quantum.bit
    %out_qubits_63 = quantum.custom "Rot"(%cst_29, %cst_39, %cst_38) %out_qubits_62#0 : !quantum.bit
    %out_qubits_64:2 = quantum.custom "CZ"() %out_qubits_59, %out_qubits_63 : !quantum.bit, !quantum.bit
    %out_qubits_65 = quantum.custom "Rot"(%cst_29, %cst_39, %cst_38) %out_qubits_64#0 : !quantum.bit
    %out_qubits_66:2 = quantum.custom "CZ"() %out_qubits_58, %out_qubits_65 : !quantum.bit, !quantum.bit
    %out_qubits_67 = quantum.custom "Rot"(%cst_29, %cst_39, %cst_38) %out_qubits_66#0 : !quantum.bit
    %out_qubits_68:2 = quantum.custom "CZ"() %out_qubits_57, %out_qubits_67 : !quantum.bit, !quantum.bit
    %out_qubits_69 = quantum.custom "Rot"(%cst_29, %cst_39, %cst_38) %out_qubits_68#0 : !quantum.bit
    %out_qubits_70:2 = quantum.custom "CZ"() %out_qubits_56, %out_qubits_69 : !quantum.bit, !quantum.bit
    %out_qubits_71 = quantum.custom "Rot"(%cst_39, %cst_14, %cst_13) %out_qubits_70#0 : !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_26, %cst_12, %cst_13) %out_qubits_70#1 : !quantum.bit
    %out_qubits_73 = quantum.custom "Rot"(%cst_11, %cst_10, %cst_9) %out_qubits_68#1 : !quantum.bit
    %out_qubits_74 = quantum.custom "Rot"(%cst_8, %cst_7, %cst_6) %out_qubits_66#1 : !quantum.bit
    %out_qubits_75 = quantum.custom "Rot"(%cst_5, %cst_4, %cst_3) %out_qubits_64#1 : !quantum.bit
    %out_qubits_76 = quantum.custom "Rot"(%cst_2, %cst_1, %cst_0) %out_qubits_62#1 : !quantum.bit
    quantum.gphase(%cst)
    %7 = quantum.compbasis qubits %out_qubits_71, %out_qubits_72, %out_qubits_73, %out_qubits_74, %out_qubits_75, %out_qubits_76 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x6xf64>
    %9 = stablehlo.convert %8 : (tensor<128x6xf64>) -> tensor<128x6xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_71 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_72 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_73 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_74 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_75 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_76 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x6xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}