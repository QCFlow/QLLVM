module @circuit {
  func.func public @jit_circuit() -> tensor<128x6xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x6xi64>
    return %0 : tensor<128x6xi64>
  }
  func.func public @circuit_0() -> tensor<128x6xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 1.5758020277674589 : f64
    %cst_0 = arith.constant 1.5707855559909785 : f64
    %cst_1 = arith.constant -1.570716698070467 : f64
    %cst_2 = arith.constant -1.5708516329121942 : f64
    %cst_3 = arith.constant 1.5707900464855147 : f64
    %cst_4 = arith.constant 1.5709436065295854 : f64
    %cst_5 = arith.constant -1.1880425310715026 : f64
    %cst_6 = arith.constant -2.4002534897677008 : f64
    %cst_7 = arith.constant 1.570777678364589 : f64
    %cst_8 = arith.constant 1.5707365133560955 : f64
    %cst_9 = arith.constant 1.5707520277993066 : f64
    %cst_10 = arith.constant -1.5709447087028612 : f64
    %cst_11 = arith.constant -1.5775280982229045 : f64
    %cst_12 = arith.constant 0.82961368064130347 : f64
    %cst_13 = arith.constant -3.1413628696551861 : f64
    %cst_14 = arith.constant -3.1415926535897931 : f64
    %cst_15 = arith.constant 7.8539816339744828 : f64
    %cst_16 = arith.constant -3.2447965131243706E-5 : f64
    %cst_17 = arith.constant -1.5707963267948966 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst_17) %1 : !quantum.bit
    %out_qubits_18 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_19 = quantum.custom "RZ"(%cst_16) %out_qubits_18 : !quantum.bit
    %out_qubits_20 = quantum.custom "Hadamard"() %out_qubits_19 : !quantum.bit
    %out_qubits_21 = quantum.custom "RZ"(%cst_15) %out_qubits_20 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_22 = quantum.custom "RZ"(%cst_17) %2 : !quantum.bit
    %out_qubits_23 = quantum.custom "Hadamard"() %out_qubits_22 : !quantum.bit
    %out_qubits_24 = quantum.custom "RZ"(%cst_14) %out_qubits_23 : !quantum.bit
    %out_qubits_25 = quantum.custom "Hadamard"() %out_qubits_24 : !quantum.bit
    %out_qubits_26 = quantum.custom "RZ"(%cst_15) %out_qubits_25 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_27 = quantum.custom "RZ"(%cst_17) %3 : !quantum.bit
    %out_qubits_28 = quantum.custom "Hadamard"() %out_qubits_27 : !quantum.bit
    %out_qubits_29 = quantum.custom "RZ"(%cst_13) %out_qubits_28 : !quantum.bit
    %out_qubits_30 = quantum.custom "Hadamard"() %out_qubits_29 : !quantum.bit
    %out_qubits_31 = quantum.custom "RZ"(%cst_15) %out_qubits_30 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_32 = quantum.custom "RZ"(%cst_17) %4 : !quantum.bit
    %out_qubits_33 = quantum.custom "Hadamard"() %out_qubits_32 : !quantum.bit
    %out_qubits_34 = quantum.custom "RZ"(%cst_14) %out_qubits_33 : !quantum.bit
    %out_qubits_35 = quantum.custom "Hadamard"() %out_qubits_34 : !quantum.bit
    %out_qubits_36 = quantum.custom "RZ"(%cst_15) %out_qubits_35 : !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_37 = quantum.custom "RZ"(%cst_17) %5 : !quantum.bit
    %out_qubits_38 = quantum.custom "Hadamard"() %out_qubits_37 : !quantum.bit
    %out_qubits_39 = quantum.custom "RZ"(%cst_12) %out_qubits_38 : !quantum.bit
    %out_qubits_40 = quantum.custom "Hadamard"() %out_qubits_39 : !quantum.bit
    %out_qubits_41 = quantum.custom "RZ"(%cst_15) %out_qubits_40 : !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_42 = quantum.custom "RZ"(%cst_17) %6 : !quantum.bit
    %out_qubits_43 = quantum.custom "Hadamard"() %out_qubits_42 : !quantum.bit
    %out_qubits_44 = quantum.custom "RZ"(%cst_11) %out_qubits_43 : !quantum.bit
    %out_qubits_45 = quantum.custom "Hadamard"() %out_qubits_44 : !quantum.bit
    %out_qubits_46 = quantum.custom "RZ"(%cst_15) %out_qubits_45 : !quantum.bit
    %out_qubits_47 = quantum.custom "Hadamard"() %out_qubits_46 : !quantum.bit
    %out_qubits_48:2 = quantum.custom "CZ"() %out_qubits_41, %out_qubits_47 : !quantum.bit, !quantum.bit
    %out_qubits_49 = quantum.custom "Hadamard"() %out_qubits_48#0 : !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits_36, %out_qubits_49 : !quantum.bit, !quantum.bit
    %out_qubits_51 = quantum.custom "Hadamard"() %out_qubits_50#0 : !quantum.bit
    %out_qubits_52:2 = quantum.custom "CZ"() %out_qubits_31, %out_qubits_51 : !quantum.bit, !quantum.bit
    %out_qubits_53 = quantum.custom "Hadamard"() %out_qubits_52#0 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_26, %out_qubits_53 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "Hadamard"() %out_qubits_54#0 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_21, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "RZ"(%cst_17) %out_qubits_56#0 : !quantum.bit
    %out_qubits_58 = quantum.custom "Hadamard"() %out_qubits_57 : !quantum.bit
    %out_qubits_59 = quantum.custom "RZ"(%cst_10) %out_qubits_58 : !quantum.bit
    %out_qubits_60 = quantum.custom "Hadamard"() %out_qubits_59 : !quantum.bit
    %out_qubits_61 = quantum.custom "RZ"(%cst_15) %out_qubits_60 : !quantum.bit
    %out_qubits_62 = quantum.custom "Hadamard"() %out_qubits_56#1 : !quantum.bit
    %out_qubits_63 = quantum.custom "RZ"(%cst_17) %out_qubits_62 : !quantum.bit
    %out_qubits_64 = quantum.custom "Hadamard"() %out_qubits_63 : !quantum.bit
    %out_qubits_65 = quantum.custom "RZ"(%cst_9) %out_qubits_64 : !quantum.bit
    %out_qubits_66 = quantum.custom "Hadamard"() %out_qubits_65 : !quantum.bit
    %out_qubits_67 = quantum.custom "RZ"(%cst_15) %out_qubits_66 : !quantum.bit
    %out_qubits_68 = quantum.custom "Hadamard"() %out_qubits_54#1 : !quantum.bit
    %out_qubits_69 = quantum.custom "RZ"(%cst_17) %out_qubits_68 : !quantum.bit
    %out_qubits_70 = quantum.custom "Hadamard"() %out_qubits_69 : !quantum.bit
    %out_qubits_71 = quantum.custom "RZ"(%cst_8) %out_qubits_70 : !quantum.bit
    %out_qubits_72 = quantum.custom "Hadamard"() %out_qubits_71 : !quantum.bit
    %out_qubits_73 = quantum.custom "RZ"(%cst_15) %out_qubits_72 : !quantum.bit
    %out_qubits_74 = quantum.custom "Hadamard"() %out_qubits_52#1 : !quantum.bit
    %out_qubits_75 = quantum.custom "RZ"(%cst_17) %out_qubits_74 : !quantum.bit
    %out_qubits_76 = quantum.custom "Hadamard"() %out_qubits_75 : !quantum.bit
    %out_qubits_77 = quantum.custom "RZ"(%cst_7) %out_qubits_76 : !quantum.bit
    %out_qubits_78 = quantum.custom "Hadamard"() %out_qubits_77 : !quantum.bit
    %out_qubits_79 = quantum.custom "RZ"(%cst_15) %out_qubits_78 : !quantum.bit
    %out_qubits_80 = quantum.custom "Hadamard"() %out_qubits_50#1 : !quantum.bit
    %out_qubits_81 = quantum.custom "RZ"(%cst_17) %out_qubits_80 : !quantum.bit
    %out_qubits_82 = quantum.custom "Hadamard"() %out_qubits_81 : !quantum.bit
    %out_qubits_83 = quantum.custom "RZ"(%cst_6) %out_qubits_82 : !quantum.bit
    %out_qubits_84 = quantum.custom "Hadamard"() %out_qubits_83 : !quantum.bit
    %out_qubits_85 = quantum.custom "RZ"(%cst_15) %out_qubits_84 : !quantum.bit
    %out_qubits_86 = quantum.custom "Hadamard"() %out_qubits_48#1 : !quantum.bit
    %out_qubits_87 = quantum.custom "RZ"(%cst_17) %out_qubits_86 : !quantum.bit
    %out_qubits_88 = quantum.custom "Hadamard"() %out_qubits_87 : !quantum.bit
    %out_qubits_89 = quantum.custom "RZ"(%cst_5) %out_qubits_88 : !quantum.bit
    %out_qubits_90 = quantum.custom "Hadamard"() %out_qubits_89 : !quantum.bit
    %out_qubits_91 = quantum.custom "RZ"(%cst_15) %out_qubits_90 : !quantum.bit
    %out_qubits_92 = quantum.custom "Hadamard"() %out_qubits_91 : !quantum.bit
    %out_qubits_93:2 = quantum.custom "CZ"() %out_qubits_85, %out_qubits_92 : !quantum.bit, !quantum.bit
    %out_qubits_94 = quantum.custom "Hadamard"() %out_qubits_93#0 : !quantum.bit
    %out_qubits_95:2 = quantum.custom "CZ"() %out_qubits_79, %out_qubits_94 : !quantum.bit, !quantum.bit
    %out_qubits_96 = quantum.custom "Hadamard"() %out_qubits_95#0 : !quantum.bit
    %out_qubits_97:2 = quantum.custom "CZ"() %out_qubits_73, %out_qubits_96 : !quantum.bit, !quantum.bit
    %out_qubits_98 = quantum.custom "Hadamard"() %out_qubits_97#0 : !quantum.bit
    %out_qubits_99:2 = quantum.custom "CZ"() %out_qubits_67, %out_qubits_98 : !quantum.bit, !quantum.bit
    %out_qubits_100 = quantum.custom "Hadamard"() %out_qubits_99#0 : !quantum.bit
    %out_qubits_101:2 = quantum.custom "CZ"() %out_qubits_61, %out_qubits_100 : !quantum.bit, !quantum.bit
    %out_qubits_102 = quantum.custom "RZ"(%cst_17) %out_qubits_101#0 : !quantum.bit
    %out_qubits_103 = quantum.custom "Hadamard"() %out_qubits_102 : !quantum.bit
    %out_qubits_104 = quantum.custom "RZ"(%cst_4) %out_qubits_103 : !quantum.bit
    %out_qubits_105 = quantum.custom "Hadamard"() %out_qubits_104 : !quantum.bit
    %out_qubits_106 = quantum.custom "RZ"(%cst_15) %out_qubits_105 : !quantum.bit
    %out_qubits_107 = quantum.custom "Hadamard"() %out_qubits_101#1 : !quantum.bit
    %out_qubits_108 = quantum.custom "RZ"(%cst_17) %out_qubits_107 : !quantum.bit
    %out_qubits_109 = quantum.custom "Hadamard"() %out_qubits_108 : !quantum.bit
    %out_qubits_110 = quantum.custom "RZ"(%cst_3) %out_qubits_109 : !quantum.bit
    %out_qubits_111 = quantum.custom "Hadamard"() %out_qubits_110 : !quantum.bit
    %out_qubits_112 = quantum.custom "RZ"(%cst_15) %out_qubits_111 : !quantum.bit
    %out_qubits_113 = quantum.custom "Hadamard"() %out_qubits_99#1 : !quantum.bit
    %out_qubits_114 = quantum.custom "RZ"(%cst_17) %out_qubits_113 : !quantum.bit
    %out_qubits_115 = quantum.custom "Hadamard"() %out_qubits_114 : !quantum.bit
    %out_qubits_116 = quantum.custom "RZ"(%cst_2) %out_qubits_115 : !quantum.bit
    %out_qubits_117 = quantum.custom "Hadamard"() %out_qubits_116 : !quantum.bit
    %out_qubits_118 = quantum.custom "RZ"(%cst_15) %out_qubits_117 : !quantum.bit
    %out_qubits_119 = quantum.custom "Hadamard"() %out_qubits_97#1 : !quantum.bit
    %out_qubits_120 = quantum.custom "RZ"(%cst_17) %out_qubits_119 : !quantum.bit
    %out_qubits_121 = quantum.custom "Hadamard"() %out_qubits_120 : !quantum.bit
    %out_qubits_122 = quantum.custom "RZ"(%cst_1) %out_qubits_121 : !quantum.bit
    %out_qubits_123 = quantum.custom "Hadamard"() %out_qubits_122 : !quantum.bit
    %out_qubits_124 = quantum.custom "RZ"(%cst_15) %out_qubits_123 : !quantum.bit
    %out_qubits_125 = quantum.custom "Hadamard"() %out_qubits_95#1 : !quantum.bit
    %out_qubits_126 = quantum.custom "RZ"(%cst_17) %out_qubits_125 : !quantum.bit
    %out_qubits_127 = quantum.custom "Hadamard"() %out_qubits_126 : !quantum.bit
    %out_qubits_128 = quantum.custom "RZ"(%cst_0) %out_qubits_127 : !quantum.bit
    %out_qubits_129 = quantum.custom "Hadamard"() %out_qubits_128 : !quantum.bit
    %out_qubits_130 = quantum.custom "RZ"(%cst_15) %out_qubits_129 : !quantum.bit
    %out_qubits_131 = quantum.custom "Hadamard"() %out_qubits_93#1 : !quantum.bit
    %out_qubits_132 = quantum.custom "RZ"(%cst_17) %out_qubits_131 : !quantum.bit
    %out_qubits_133 = quantum.custom "Hadamard"() %out_qubits_132 : !quantum.bit
    %out_qubits_134 = quantum.custom "RZ"(%cst) %out_qubits_133 : !quantum.bit
    %out_qubits_135 = quantum.custom "Hadamard"() %out_qubits_134 : !quantum.bit
    %out_qubits_136 = quantum.custom "RZ"(%cst_15) %out_qubits_135 : !quantum.bit
    %7 = quantum.compbasis qubits %out_qubits_106, %out_qubits_112, %out_qubits_118, %out_qubits_124, %out_qubits_130, %out_qubits_136 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x6xf64>
    %9 = stablehlo.convert %8 : (tensor<128x6xf64>) -> tensor<128x6xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_106 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_112 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_118 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_124 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_130 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_136 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x6xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}