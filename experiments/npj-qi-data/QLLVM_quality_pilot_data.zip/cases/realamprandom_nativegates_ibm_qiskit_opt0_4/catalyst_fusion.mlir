module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -78.539816339744831 : f64
    %cst_0 = arith.constant 0.86377419701777602 : f64
    %cst_1 = arith.constant -1.1102230246251565E-15 : f64
    %cst_2 = arith.constant 9.4247779607693793 : f64
    %cst_3 = arith.constant 1.1773372206208816 : f64
    %cst_4 = arith.constant -3.1415926535897931 : f64
    %cst_5 = arith.constant 9.4247779607693758 : f64
    %cst_6 = arith.constant 3.0649864034230179 : f64
    %cst_7 = arith.constant -3.1415926535897971 : f64
    %cst_8 = arith.constant 6.2831853071795862 : f64
    %cst_9 = arith.constant 0.0248076889803788 : f64
    %cst_10 = arith.constant 1.2185281489032193E-15 : f64
    %cst_11 = arith.constant 0.29283824240478123 : f64
    %cst_12 = arith.constant -1.3951740851243746E-15 : f64
    %cst_13 = arith.constant 3.1415926535897944 : f64
    %cst_14 = arith.constant 2.7354464141049171 : f64
    %cst_15 = arith.constant 1.3322676295501878E-15 : f64
    %cst_16 = arith.constant 4.4408920985006262E-16 : f64
    %cst_17 = arith.constant 1.0157409043377801 : f64
    %cst_18 = arith.constant -1.5707963267948963 : f64
    %cst_19 = arith.constant 1.0625547235745714 : f64
    %cst_20 = arith.constant 1.5707963267948963 : f64
    %cst_21 = arith.constant 3.7746565297121476E-16 : f64
    %cst_22 = arith.constant 1.5046299106322616 : f64
    %cst_23 = arith.constant -5.0235105234610919E-16 : f64
    %cst_24 = arith.constant 1.7763568394002505E-15 : f64
    %cst_25 = arith.constant 0.32633064503932985 : f64
    %cst_26 = arith.constant 3.1415926535897913 : f64
    %cst_27 = arith.constant 3.7747582837255322E-15 : f64
    %cst_28 = arith.constant 0.15835734649221744 : f64
    %cst_29 = arith.constant 3.1415926535897896 : f64
    %cst_30 = arith.constant 3.1415926535897931 : f64
    %cst_31 = arith.constant -1.5707963267948493 : f64
    %cst_32 = arith.constant 3.1322119352256341 : f64
    %cst_33 = arith.constant 1.5707963267949439 : f64
    %cst_34 = arith.constant 3.1415926535898584 : f64
    %cst_35 = arith.constant 3.1340772259307204 : f64
    %cst_36 = arith.constant 6.5281113847959205E-14 : f64
    %cst_37 = arith.constant 3.141592653589794 : f64
    %cst_38 = arith.constant 2.4105329528141568 : f64
    %cst_39 = arith.constant 6.6613381477509392E-16 : f64
    %cst_40 = arith.constant 0.000000e+00 : f64
    %cst_41 = arith.constant 1.4404079834845696 : f64
    %cst_42 = arith.constant 3.1415926535897927 : f64
    %cst_43 = arith.constant 1.5707963267948966 : f64
    %cst_44 = arith.constant 1.4368347742816614 : f64
    %cst_45 = arith.constant -3.141592653589794 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_45, %cst_44, %cst_43) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_46 = quantum.custom "Rot"(%cst_42, %cst_41, %cst_40) %2 : !quantum.bit
    %out_qubits_47:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_46 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_48 = quantum.custom "Rot"(%cst_39, %cst_38, %cst_37) %3 : !quantum.bit
    %out_qubits_49:2 = quantum.custom "CZ"() %out_qubits_47#0, %out_qubits_48 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_50 = quantum.custom "Rot"(%cst_36, %cst_35, %cst_34) %4 : !quantum.bit
    %out_qubits_51:2 = quantum.custom "CZ"() %out_qubits_49#0, %out_qubits_50 : !quantum.bit, !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %out_qubits_51#0 : !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_30, %cst_43, %cst_40) %out_qubits_47#1 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_53, %out_qubits_49#1 : !quantum.bit, !quantum.bit
    %out_qubits_55:2 = quantum.custom "CZ"() %out_qubits_54#0, %out_qubits_51#1 : !quantum.bit, !quantum.bit
    %out_qubits_56 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_27) %out_qubits_55#0 : !quantum.bit
    %out_qubits_57:2 = quantum.custom "CZ"() %out_qubits_52, %out_qubits_56 : !quantum.bit, !quantum.bit
    %out_qubits_58 = quantum.custom "Rot"(%cst_30, %cst_43, %cst_40) %out_qubits_54#1 : !quantum.bit
    %out_qubits_59:2 = quantum.custom "CZ"() %out_qubits_58, %out_qubits_55#1 : !quantum.bit, !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_26, %cst_25, %cst_24) %out_qubits_59#0 : !quantum.bit
    %out_qubits_61:2 = quantum.custom "CZ"() %out_qubits_57#0, %out_qubits_60 : !quantum.bit, !quantum.bit
    %out_qubits_62 = quantum.custom "Rot"(%cst_23, %cst_22, %cst_21) %out_qubits_59#1 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_61#0, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_63#0 : !quantum.bit
    %out_qubits_65 = quantum.custom "Rot"(%cst_30, %cst_43, %cst_40) %out_qubits_57#1 : !quantum.bit
    %out_qubits_66:2 = quantum.custom "CZ"() %out_qubits_65, %out_qubits_61#1 : !quantum.bit, !quantum.bit
    %out_qubits_67:2 = quantum.custom "CZ"() %out_qubits_66#0, %out_qubits_63#1 : !quantum.bit, !quantum.bit
    %out_qubits_68 = quantum.custom "Rot"(%cst_42, %cst_17, %cst_16) %out_qubits_67#0 : !quantum.bit
    %out_qubits_69:2 = quantum.custom "CZ"() %out_qubits_64, %out_qubits_68 : !quantum.bit, !quantum.bit
    %out_qubits_70 = quantum.custom "Rot"(%cst_30, %cst_43, %cst_40) %out_qubits_66#1 : !quantum.bit
    %out_qubits_71:2 = quantum.custom "CZ"() %out_qubits_70, %out_qubits_67#1 : !quantum.bit, !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_15, %cst_14, %cst_13) %out_qubits_71#0 : !quantum.bit
    %out_qubits_73:2 = quantum.custom "CZ"() %out_qubits_69#0, %out_qubits_72 : !quantum.bit, !quantum.bit
    %out_qubits_74 = quantum.custom "Rot"(%cst_12, %cst_11, %cst_10) %out_qubits_71#1 : !quantum.bit
    %out_qubits_75:2 = quantum.custom "CZ"() %out_qubits_73#0, %out_qubits_74 : !quantum.bit, !quantum.bit
    %out_qubits_76 = quantum.custom "Rot"(%cst_20, %cst_9, %cst_8) %out_qubits_75#0 : !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_30, %cst_43, %cst_40) %out_qubits_69#1 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_77, %out_qubits_73#1 : !quantum.bit, !quantum.bit
    %out_qubits_79:2 = quantum.custom "CZ"() %out_qubits_78#0, %out_qubits_75#1 : !quantum.bit, !quantum.bit
    %out_qubits_80 = quantum.custom "Rot"(%cst_7, %cst_6, %cst_5) %out_qubits_79#0 : !quantum.bit
    %out_qubits_81 = quantum.custom "Rot"(%cst_30, %cst_43, %cst_40) %out_qubits_78#1 : !quantum.bit
    %out_qubits_82:2 = quantum.custom "CZ"() %out_qubits_81, %out_qubits_79#1 : !quantum.bit, !quantum.bit
    %out_qubits_83 = quantum.custom "Rot"(%cst_4, %cst_3, %cst_2) %out_qubits_82#0 : !quantum.bit
    %out_qubits_84 = quantum.custom "Rot"(%cst_1, %cst_0, %cst_2) %out_qubits_82#1 : !quantum.bit
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_76, %out_qubits_80, %out_qubits_83, %out_qubits_84 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_76 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_80 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_83 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_84 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}