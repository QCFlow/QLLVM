module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 3.8486147833669131 : f64
    %cst_0 = arith.constant 5.105848086558705 : f64
    %cst_1 = arith.constant 3.2181989037565684 : f64
    %cst_2 = arith.constant 0.02480768898038388 : f64
    %cst_3 = arith.constant 5.9903470647748058 : f64
    %cst_4 = arith.constant 4.3062427408998136 : f64
    %cst_5 = arith.constant 0.55505542245711625 : f64
    %cst_6 = arith.constant 1.0625547235745714 : f64
    %cst_7 = arith.constant 4.7785553965473238 : f64
    %cst_8 = arith.constant 1.2444656817555666 : f64
    %cst_9 = arith.constant 1.4124389803026798 : f64
    %cst_10 = arith.constant 3.1322119352256292 : f64
    %cst_11 = arith.constant 4.7048735527256351 : f64
    %cst_12 = arith.constant 3.9813292796090529 : f64
    %cst_13 = arith.constant 0.13038834331032634 : f64
    %cst_14 = arith.constant 7.8539816339744828 : f64
    %cst_15 = arith.constant 4.8463505328979251 : f64
    %cst_16 = arith.constant -1.5707963267948966 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst_16) %1 : !quantum.bit
    %out_qubits_17 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_18 = quantum.custom "RZ"(%cst_15) %out_qubits_17 : !quantum.bit
    %out_qubits_19 = quantum.custom "Hadamard"() %out_qubits_18 : !quantum.bit
    %out_qubits_20 = quantum.custom "RZ"(%cst_14) %out_qubits_19 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_21 = quantum.custom "RZ"(%cst_16) %2 : !quantum.bit
    %out_qubits_22 = quantum.custom "Hadamard"() %out_qubits_21 : !quantum.bit
    %out_qubits_23 = quantum.custom "RZ"(%cst_13) %out_qubits_22 : !quantum.bit
    %out_qubits_24 = quantum.custom "Hadamard"() %out_qubits_23 : !quantum.bit
    %out_qubits_25 = quantum.custom "RZ"(%cst_14) %out_qubits_24 : !quantum.bit
    %out_qubits_26 = quantum.custom "Hadamard"() %out_qubits_25 : !quantum.bit
    %out_qubits_27:2 = quantum.custom "CZ"() %out_qubits_20, %out_qubits_26 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_28 = quantum.custom "RZ"(%cst_16) %3 : !quantum.bit
    %out_qubits_29 = quantum.custom "Hadamard"() %out_qubits_28 : !quantum.bit
    %out_qubits_30 = quantum.custom "RZ"(%cst_12) %out_qubits_29 : !quantum.bit
    %out_qubits_31 = quantum.custom "Hadamard"() %out_qubits_30 : !quantum.bit
    %out_qubits_32 = quantum.custom "RZ"(%cst_14) %out_qubits_31 : !quantum.bit
    %out_qubits_33 = quantum.custom "Hadamard"() %out_qubits_32 : !quantum.bit
    %out_qubits_34:2 = quantum.custom "CZ"() %out_qubits_27#0, %out_qubits_33 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_35 = quantum.custom "RZ"(%cst_16) %4 : !quantum.bit
    %out_qubits_36 = quantum.custom "Hadamard"() %out_qubits_35 : !quantum.bit
    %out_qubits_37 = quantum.custom "RZ"(%cst_11) %out_qubits_36 : !quantum.bit
    %out_qubits_38 = quantum.custom "Hadamard"() %out_qubits_37 : !quantum.bit
    %out_qubits_39 = quantum.custom "RZ"(%cst_14) %out_qubits_38 : !quantum.bit
    %out_qubits_40 = quantum.custom "Hadamard"() %out_qubits_39 : !quantum.bit
    %out_qubits_41:2 = quantum.custom "CZ"() %out_qubits_34#0, %out_qubits_40 : !quantum.bit, !quantum.bit
    %out_qubits_42 = quantum.custom "RZ"(%cst_16) %out_qubits_41#0 : !quantum.bit
    %out_qubits_43 = quantum.custom "Hadamard"() %out_qubits_42 : !quantum.bit
    %out_qubits_44 = quantum.custom "RZ"(%cst_10) %out_qubits_43 : !quantum.bit
    %out_qubits_45 = quantum.custom "Hadamard"() %out_qubits_44 : !quantum.bit
    %out_qubits_46 = quantum.custom "RZ"(%cst_14) %out_qubits_45 : !quantum.bit
    %out_qubits_47 = quantum.custom "Hadamard"() %out_qubits_27#1 : !quantum.bit
    %out_qubits_48:2 = quantum.custom "CZ"() %out_qubits_47, %out_qubits_34#1 : !quantum.bit, !quantum.bit
    %out_qubits_49:2 = quantum.custom "CZ"() %out_qubits_48#0, %out_qubits_41#1 : !quantum.bit, !quantum.bit
    %out_qubits_50 = quantum.custom "RZ"(%cst_16) %out_qubits_49#0 : !quantum.bit
    %out_qubits_51 = quantum.custom "Hadamard"() %out_qubits_50 : !quantum.bit
    %out_qubits_52 = quantum.custom "RZ"(%cst_9) %out_qubits_51 : !quantum.bit
    %out_qubits_53 = quantum.custom "Hadamard"() %out_qubits_52 : !quantum.bit
    %out_qubits_54 = quantum.custom "RZ"(%cst_14) %out_qubits_53 : !quantum.bit
    %out_qubits_55 = quantum.custom "Hadamard"() %out_qubits_54 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_46, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "Hadamard"() %out_qubits_48#1 : !quantum.bit
    %out_qubits_58:2 = quantum.custom "CZ"() %out_qubits_57, %out_qubits_49#1 : !quantum.bit, !quantum.bit
    %out_qubits_59 = quantum.custom "RZ"(%cst_16) %out_qubits_58#0 : !quantum.bit
    %out_qubits_60 = quantum.custom "Hadamard"() %out_qubits_59 : !quantum.bit
    %out_qubits_61 = quantum.custom "RZ"(%cst_8) %out_qubits_60 : !quantum.bit
    %out_qubits_62 = quantum.custom "Hadamard"() %out_qubits_61 : !quantum.bit
    %out_qubits_63 = quantum.custom "RZ"(%cst_14) %out_qubits_62 : !quantum.bit
    %out_qubits_64 = quantum.custom "Hadamard"() %out_qubits_63 : !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_56#0, %out_qubits_64 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "Hadamard"() %out_qubits_58#1 : !quantum.bit
    %out_qubits_67 = quantum.custom "RZ"(%cst_16) %out_qubits_66 : !quantum.bit
    %out_qubits_68 = quantum.custom "Hadamard"() %out_qubits_67 : !quantum.bit
    %out_qubits_69 = quantum.custom "RZ"(%cst_7) %out_qubits_68 : !quantum.bit
    %out_qubits_70 = quantum.custom "Hadamard"() %out_qubits_69 : !quantum.bit
    %out_qubits_71 = quantum.custom "RZ"(%cst_14) %out_qubits_70 : !quantum.bit
    %out_qubits_72 = quantum.custom "Hadamard"() %out_qubits_71 : !quantum.bit
    %out_qubits_73:2 = quantum.custom "CZ"() %out_qubits_65#0, %out_qubits_72 : !quantum.bit, !quantum.bit
    %out_qubits_74 = quantum.custom "RZ"(%cst_16) %out_qubits_73#0 : !quantum.bit
    %out_qubits_75 = quantum.custom "Hadamard"() %out_qubits_74 : !quantum.bit
    %out_qubits_76 = quantum.custom "RZ"(%cst_6) %out_qubits_75 : !quantum.bit
    %out_qubits_77 = quantum.custom "Hadamard"() %out_qubits_76 : !quantum.bit
    %out_qubits_78 = quantum.custom "RZ"(%cst_14) %out_qubits_77 : !quantum.bit
    %out_qubits_79 = quantum.custom "Hadamard"() %out_qubits_56#1 : !quantum.bit
    %out_qubits_80:2 = quantum.custom "CZ"() %out_qubits_79, %out_qubits_65#1 : !quantum.bit, !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_80#0, %out_qubits_73#1 : !quantum.bit, !quantum.bit
    %out_qubits_82 = quantum.custom "RZ"(%cst_16) %out_qubits_81#0 : !quantum.bit
    %out_qubits_83 = quantum.custom "Hadamard"() %out_qubits_82 : !quantum.bit
    %out_qubits_84 = quantum.custom "RZ"(%cst_5) %out_qubits_83 : !quantum.bit
    %out_qubits_85 = quantum.custom "Hadamard"() %out_qubits_84 : !quantum.bit
    %out_qubits_86 = quantum.custom "RZ"(%cst_14) %out_qubits_85 : !quantum.bit
    %out_qubits_87 = quantum.custom "Hadamard"() %out_qubits_86 : !quantum.bit
    %out_qubits_88:2 = quantum.custom "CZ"() %out_qubits_78, %out_qubits_87 : !quantum.bit, !quantum.bit
    %out_qubits_89 = quantum.custom "Hadamard"() %out_qubits_80#1 : !quantum.bit
    %out_qubits_90:2 = quantum.custom "CZ"() %out_qubits_89, %out_qubits_81#1 : !quantum.bit, !quantum.bit
    %out_qubits_91 = quantum.custom "RZ"(%cst_16) %out_qubits_90#0 : !quantum.bit
    %out_qubits_92 = quantum.custom "Hadamard"() %out_qubits_91 : !quantum.bit
    %out_qubits_93 = quantum.custom "RZ"(%cst_4) %out_qubits_92 : !quantum.bit
    %out_qubits_94 = quantum.custom "Hadamard"() %out_qubits_93 : !quantum.bit
    %out_qubits_95 = quantum.custom "RZ"(%cst_14) %out_qubits_94 : !quantum.bit
    %out_qubits_96 = quantum.custom "Hadamard"() %out_qubits_95 : !quantum.bit
    %out_qubits_97:2 = quantum.custom "CZ"() %out_qubits_88#0, %out_qubits_96 : !quantum.bit, !quantum.bit
    %out_qubits_98 = quantum.custom "Hadamard"() %out_qubits_90#1 : !quantum.bit
    %out_qubits_99 = quantum.custom "RZ"(%cst_16) %out_qubits_98 : !quantum.bit
    %out_qubits_100 = quantum.custom "Hadamard"() %out_qubits_99 : !quantum.bit
    %out_qubits_101 = quantum.custom "RZ"(%cst_3) %out_qubits_100 : !quantum.bit
    %out_qubits_102 = quantum.custom "Hadamard"() %out_qubits_101 : !quantum.bit
    %out_qubits_103 = quantum.custom "RZ"(%cst_14) %out_qubits_102 : !quantum.bit
    %out_qubits_104 = quantum.custom "Hadamard"() %out_qubits_103 : !quantum.bit
    %out_qubits_105:2 = quantum.custom "CZ"() %out_qubits_97#0, %out_qubits_104 : !quantum.bit, !quantum.bit
    %out_qubits_106 = quantum.custom "RZ"(%cst_16) %out_qubits_105#0 : !quantum.bit
    %out_qubits_107 = quantum.custom "Hadamard"() %out_qubits_106 : !quantum.bit
    %out_qubits_108 = quantum.custom "RZ"(%cst_2) %out_qubits_107 : !quantum.bit
    %out_qubits_109 = quantum.custom "Hadamard"() %out_qubits_108 : !quantum.bit
    %out_qubits_110 = quantum.custom "RZ"(%cst_14) %out_qubits_109 : !quantum.bit
    %out_qubits_111 = quantum.custom "Hadamard"() %out_qubits_88#1 : !quantum.bit
    %out_qubits_112:2 = quantum.custom "CZ"() %out_qubits_111, %out_qubits_97#1 : !quantum.bit, !quantum.bit
    %out_qubits_113:2 = quantum.custom "CZ"() %out_qubits_112#0, %out_qubits_105#1 : !quantum.bit, !quantum.bit
    %out_qubits_114 = quantum.custom "RZ"(%cst_16) %out_qubits_113#0 : !quantum.bit
    %out_qubits_115 = quantum.custom "Hadamard"() %out_qubits_114 : !quantum.bit
    %out_qubits_116 = quantum.custom "RZ"(%cst_1) %out_qubits_115 : !quantum.bit
    %out_qubits_117 = quantum.custom "Hadamard"() %out_qubits_116 : !quantum.bit
    %out_qubits_118 = quantum.custom "RZ"(%cst_14) %out_qubits_117 : !quantum.bit
    %out_qubits_119 = quantum.custom "Hadamard"() %out_qubits_112#1 : !quantum.bit
    %out_qubits_120:2 = quantum.custom "CZ"() %out_qubits_119, %out_qubits_113#1 : !quantum.bit, !quantum.bit
    %out_qubits_121 = quantum.custom "RZ"(%cst_16) %out_qubits_120#0 : !quantum.bit
    %out_qubits_122 = quantum.custom "Hadamard"() %out_qubits_121 : !quantum.bit
    %out_qubits_123 = quantum.custom "RZ"(%cst_0) %out_qubits_122 : !quantum.bit
    %out_qubits_124 = quantum.custom "Hadamard"() %out_qubits_123 : !quantum.bit
    %out_qubits_125 = quantum.custom "RZ"(%cst_14) %out_qubits_124 : !quantum.bit
    %out_qubits_126 = quantum.custom "Hadamard"() %out_qubits_120#1 : !quantum.bit
    %out_qubits_127 = quantum.custom "RZ"(%cst_16) %out_qubits_126 : !quantum.bit
    %out_qubits_128 = quantum.custom "Hadamard"() %out_qubits_127 : !quantum.bit
    %out_qubits_129 = quantum.custom "RZ"(%cst) %out_qubits_128 : !quantum.bit
    %out_qubits_130 = quantum.custom "Hadamard"() %out_qubits_129 : !quantum.bit
    %out_qubits_131 = quantum.custom "RZ"(%cst_14) %out_qubits_130 : !quantum.bit
    %5 = quantum.compbasis qubits %out_qubits_110, %out_qubits_118, %out_qubits_125, %out_qubits_131 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_110 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_118 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_125 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_131 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}