module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -14.13772631524199 : f64
    %cst_0 = arith.constant 6.2831853071795862 : f64
    %cst_1 = arith.constant -3.9266503593396762 : f64
    %cst_2 = arith.constant 0.000000e+00 : f64
    %cst_3 = arith.constant 0.78545847544466685 : f64
    %cst_4 = arith.constant 4.7123152560394805 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst_2) %1 : !quantum.bit
    %out_qubits_5 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_6 = quantum.custom "RZ"(%cst_2) %out_qubits_5 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_7 = quantum.custom "RZ"(%cst_2) %2 : !quantum.bit
    %out_qubits_8 = quantum.custom "Hadamard"() %out_qubits_7 : !quantum.bit
    %out_qubits_9 = quantum.custom "RZ"(%cst_2) %out_qubits_8 : !quantum.bit
    %out_qubits_10 = quantum.custom "Hadamard"() %out_qubits_9 : !quantum.bit
    %out_qubits_11:2 = quantum.custom "CZ"() %out_qubits_6, %out_qubits_10 : !quantum.bit, !quantum.bit
    %out_qubits_12 = quantum.custom "Hadamard"() %out_qubits_11#1 : !quantum.bit
    %out_qubits_13 = quantum.custom "RZ"(%cst_4) %out_qubits_12 : !quantum.bit
    %out_qubits_14 = quantum.custom "Hadamard"() %out_qubits_13 : !quantum.bit
    %out_qubits_15:2 = quantum.custom "CZ"() %out_qubits_11#0, %out_qubits_14 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_16 = quantum.custom "RZ"(%cst_2) %3 : !quantum.bit
    %out_qubits_17 = quantum.custom "Hadamard"() %out_qubits_16 : !quantum.bit
    %out_qubits_18 = quantum.custom "RZ"(%cst_2) %out_qubits_17 : !quantum.bit
    %out_qubits_19 = quantum.custom "Hadamard"() %out_qubits_18 : !quantum.bit
    %out_qubits_20:2 = quantum.custom "CZ"() %out_qubits_15#0, %out_qubits_19 : !quantum.bit, !quantum.bit
    %out_qubits_21 = quantum.custom "Hadamard"() %out_qubits_20#1 : !quantum.bit
    %out_qubits_22 = quantum.custom "RZ"(%cst_4) %out_qubits_21 : !quantum.bit
    %out_qubits_23 = quantum.custom "Hadamard"() %out_qubits_22 : !quantum.bit
    %out_qubits_24:2 = quantum.custom "CZ"() %out_qubits_20#0, %out_qubits_23 : !quantum.bit, !quantum.bit
    %out_qubits_25 = quantum.custom "RZ"(%cst_2) %out_qubits_24#0 : !quantum.bit
    %out_qubits_26 = quantum.custom "Hadamard"() %out_qubits_25 : !quantum.bit
    %out_qubits_27 = quantum.custom "RZ"(%cst_1) %out_qubits_26 : !quantum.bit
    %out_qubits_28 = quantum.custom "Hadamard"() %out_qubits_27 : !quantum.bit
    %out_qubits_29 = quantum.custom "RZ"(%cst_0) %out_qubits_28 : !quantum.bit
    %out_qubits_30 = quantum.custom "Hadamard"() %out_qubits_15#1 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_31 = quantum.custom "RZ"(%cst_2) %4 : !quantum.bit
    %out_qubits_32 = quantum.custom "Hadamard"() %out_qubits_31 : !quantum.bit
    %out_qubits_33 = quantum.custom "RZ"(%cst_2) %out_qubits_32 : !quantum.bit
    %out_qubits_34 = quantum.custom "Hadamard"() %out_qubits_33 : !quantum.bit
    %out_qubits_35:2 = quantum.custom "CZ"() %out_qubits_30, %out_qubits_34 : !quantum.bit, !quantum.bit
    %out_qubits_36 = quantum.custom "Hadamard"() %out_qubits_35#1 : !quantum.bit
    %out_qubits_37 = quantum.custom "RZ"(%cst_4) %out_qubits_36 : !quantum.bit
    %out_qubits_38 = quantum.custom "Hadamard"() %out_qubits_37 : !quantum.bit
    %out_qubits_39:2 = quantum.custom "CZ"() %out_qubits_35#0, %out_qubits_38 : !quantum.bit, !quantum.bit
    %out_qubits_40 = quantum.custom "RZ"(%cst_2) %out_qubits_39#0 : !quantum.bit
    %out_qubits_41 = quantum.custom "Hadamard"() %out_qubits_40 : !quantum.bit
    %out_qubits_42 = quantum.custom "RZ"(%cst_1) %out_qubits_41 : !quantum.bit
    %out_qubits_43 = quantum.custom "Hadamard"() %out_qubits_42 : !quantum.bit
    %out_qubits_44 = quantum.custom "RZ"(%cst_0) %out_qubits_43 : !quantum.bit
    %out_qubits_45 = quantum.custom "Hadamard"() %out_qubits_44 : !quantum.bit
    %out_qubits_46:2 = quantum.custom "CZ"() %out_qubits_29, %out_qubits_45 : !quantum.bit, !quantum.bit
    %out_qubits_47 = quantum.custom "Hadamard"() %out_qubits_46#1 : !quantum.bit
    %out_qubits_48 = quantum.custom "RZ"(%cst_3) %out_qubits_47 : !quantum.bit
    %out_qubits_49 = quantum.custom "Hadamard"() %out_qubits_48 : !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits_46#0, %out_qubits_49 : !quantum.bit, !quantum.bit
    %out_qubits_51 = quantum.custom "Hadamard"() %out_qubits_24#1 : !quantum.bit
    %out_qubits_52:2 = quantum.custom "CZ"() %out_qubits_51, %out_qubits_39#1 : !quantum.bit, !quantum.bit
    %out_qubits_53 = quantum.custom "Hadamard"() %out_qubits_52#1 : !quantum.bit
    %out_qubits_54 = quantum.custom "RZ"(%cst_4) %out_qubits_53 : !quantum.bit
    %out_qubits_55 = quantum.custom "Hadamard"() %out_qubits_54 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_52#0, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "RZ"(%cst_2) %out_qubits_56#0 : !quantum.bit
    %out_qubits_58 = quantum.custom "Hadamard"() %out_qubits_57 : !quantum.bit
    %out_qubits_59 = quantum.custom "RZ"(%cst_1) %out_qubits_58 : !quantum.bit
    %out_qubits_60 = quantum.custom "Hadamard"() %out_qubits_59 : !quantum.bit
    %out_qubits_61 = quantum.custom "RZ"(%cst_0) %out_qubits_60 : !quantum.bit
    %out_qubits_62 = quantum.custom "Hadamard"() %out_qubits_61 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_50#0, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Hadamard"() %out_qubits_63#1 : !quantum.bit
    %out_qubits_65 = quantum.custom "RZ"(%cst_3) %out_qubits_64 : !quantum.bit
    %out_qubits_66 = quantum.custom "Hadamard"() %out_qubits_65 : !quantum.bit
    %out_qubits_67:2 = quantum.custom "CZ"() %out_qubits_63#0, %out_qubits_66 : !quantum.bit, !quantum.bit
    %out_qubits_68 = quantum.custom "RZ"(%cst_2) %out_qubits_67#0 : !quantum.bit
    %out_qubits_69 = quantum.custom "Hadamard"() %out_qubits_68 : !quantum.bit
    %out_qubits_70 = quantum.custom "RZ"(%cst) %out_qubits_69 : !quantum.bit
    %out_qubits_71 = quantum.custom "Hadamard"() %out_qubits_70 : !quantum.bit
    %out_qubits_72 = quantum.custom "RZ"(%cst_0) %out_qubits_71 : !quantum.bit
    %out_qubits_73 = quantum.custom "Hadamard"() %out_qubits_50#1 : !quantum.bit
    %out_qubits_74 = quantum.custom "Hadamard"() %out_qubits_56#1 : !quantum.bit
    %out_qubits_75 = quantum.custom "RZ"(%cst_2) %out_qubits_74 : !quantum.bit
    %out_qubits_76 = quantum.custom "Hadamard"() %out_qubits_75 : !quantum.bit
    %out_qubits_77 = quantum.custom "RZ"(%cst_1) %out_qubits_76 : !quantum.bit
    %out_qubits_78 = quantum.custom "Hadamard"() %out_qubits_77 : !quantum.bit
    %out_qubits_79 = quantum.custom "RZ"(%cst_0) %out_qubits_78 : !quantum.bit
    %out_qubits_80 = quantum.custom "Hadamard"() %out_qubits_79 : !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_73, %out_qubits_80 : !quantum.bit, !quantum.bit
    %out_qubits_82 = quantum.custom "Hadamard"() %out_qubits_81#1 : !quantum.bit
    %out_qubits_83 = quantum.custom "RZ"(%cst_3) %out_qubits_82 : !quantum.bit
    %out_qubits_84 = quantum.custom "Hadamard"() %out_qubits_83 : !quantum.bit
    %out_qubits_85:2 = quantum.custom "CZ"() %out_qubits_81#0, %out_qubits_84 : !quantum.bit, !quantum.bit
    %out_qubits_86 = quantum.custom "RZ"(%cst_2) %out_qubits_85#0 : !quantum.bit
    %out_qubits_87 = quantum.custom "Hadamard"() %out_qubits_86 : !quantum.bit
    %out_qubits_88 = quantum.custom "RZ"(%cst) %out_qubits_87 : !quantum.bit
    %out_qubits_89 = quantum.custom "Hadamard"() %out_qubits_88 : !quantum.bit
    %out_qubits_90 = quantum.custom "RZ"(%cst_0) %out_qubits_89 : !quantum.bit
    %out_qubits_91 = quantum.custom "Hadamard"() %out_qubits_67#1 : !quantum.bit
    %out_qubits_92:2 = quantum.custom "CZ"() %out_qubits_91, %out_qubits_85#1 : !quantum.bit, !quantum.bit
    %out_qubits_93 = quantum.custom "Hadamard"() %out_qubits_92#1 : !quantum.bit
    %out_qubits_94 = quantum.custom "RZ"(%cst_3) %out_qubits_93 : !quantum.bit
    %out_qubits_95 = quantum.custom "Hadamard"() %out_qubits_94 : !quantum.bit
    %out_qubits_96:2 = quantum.custom "CZ"() %out_qubits_92#0, %out_qubits_95 : !quantum.bit, !quantum.bit
    %out_qubits_97 = quantum.custom "RZ"(%cst_2) %out_qubits_96#0 : !quantum.bit
    %out_qubits_98 = quantum.custom "Hadamard"() %out_qubits_97 : !quantum.bit
    %out_qubits_99 = quantum.custom "RZ"(%cst) %out_qubits_98 : !quantum.bit
    %out_qubits_100 = quantum.custom "Hadamard"() %out_qubits_99 : !quantum.bit
    %out_qubits_101 = quantum.custom "RZ"(%cst_0) %out_qubits_100 : !quantum.bit
    %out_qubits_102 = quantum.custom "Hadamard"() %out_qubits_96#1 : !quantum.bit
    %out_qubits_103 = quantum.custom "RZ"(%cst_2) %out_qubits_102 : !quantum.bit
    %out_qubits_104 = quantum.custom "Hadamard"() %out_qubits_103 : !quantum.bit
    %out_qubits_105 = quantum.custom "RZ"(%cst) %out_qubits_104 : !quantum.bit
    %out_qubits_106 = quantum.custom "Hadamard"() %out_qubits_105 : !quantum.bit
    %out_qubits_107 = quantum.custom "RZ"(%cst_0) %out_qubits_106 : !quantum.bit
    %5 = quantum.compbasis qubits %out_qubits_72, %out_qubits_90, %out_qubits_101, %out_qubits_107 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_72 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_90 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_101 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_107 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}