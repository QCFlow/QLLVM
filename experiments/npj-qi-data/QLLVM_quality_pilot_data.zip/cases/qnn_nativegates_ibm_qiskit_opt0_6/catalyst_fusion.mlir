module @circuit {
  func.func public @jit_circuit() -> tensor<128x6xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x6xi64>
    return %0 : tensor<128x6xi64>
  }
  func.func public @circuit_0() -> tensor<128x6xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -197.92033717615658 : f64
    %cst_0 = arith.constant 2.1659272233031643 : f64
    %cst_1 = arith.constant 1.5804306303795475 : f64
    %cst_2 = arith.constant 2.363345601893295 : f64
    %cst_3 = arith.constant -3.1415926535897936 : f64
    %cst_4 = arith.constant 1.735985421741036 : f64
    %cst_5 = arith.constant 2.4830447293575704 : f64
    %cst_6 = arith.constant -3.1415926535897931 : f64
    %cst_7 = arith.constant 6.2831853071795862 : f64
    %cst_8 = arith.constant 0.34739322764684682 : f64
    %cst_9 = arith.constant 1.5707963267948961 : f64
    %cst_10 = arith.constant 10.995574287564276 : f64
    %cst_11 = arith.constant -3.141592653589794 : f64
    %cst_12 = arith.constant 0.36142198736798448 : f64
    %cst_13 = arith.constant -3.1415926535897922 : f64
    %cst_14 = arith.constant 0.093197256608064465 : f64
    %cst_15 = arith.constant 0.33150752026520403 : f64
    %cst_16 = arith.constant -4.4408920985006262E-16 : f64
    %cst_17 = arith.constant 0.067357199732931805 : f64
    %cst_18 = arith.constant 4.7123889803846897 : f64
    %cst_19 = arith.constant 0.50240063387503175 : f64
    %cst_20 = arith.constant -1.5707963267948963 : f64
    %cst_21 = arith.constant 0.97982631372051465 : f64
    %cst_22 = arith.constant -4.2831853071795862 : f64
    %cst_23 = arith.constant 11.424777960769379 : f64
    %cst_24 = arith.constant 5.1415926535897931 : f64
    %cst_25 = arith.constant -1.5707963267948952 : f64
    %cst_26 = arith.constant 2.8896528806399568 : f64
    %cst_27 = arith.constant 1.5707963267948979 : f64
    %cst_28 = arith.constant -1.5707963267948966 : f64
    %cst_29 = arith.constant 1.9999999999999998 : f64
    %cst_30 = arith.constant -4.7123889803846897 : f64
    %cst_31 = arith.constant 0.000000e+00 : f64
    %cst_32 = arith.constant 1.5707963267948966 : f64
    %cst_33 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_34 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %2 : !quantum.bit
    %out_qubits_35:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_34 : !quantum.bit, !quantum.bit
    %out_qubits_36 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_35#1 : !quantum.bit
    %out_qubits_37:2 = quantum.custom "CZ"() %out_qubits_35#0, %out_qubits_36 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_38 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %3 : !quantum.bit
    %out_qubits_39:2 = quantum.custom "CZ"() %out_qubits_37#0, %out_qubits_38 : !quantum.bit, !quantum.bit
    %out_qubits_40 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_39#1 : !quantum.bit
    %out_qubits_41:2 = quantum.custom "CZ"() %out_qubits_39#0, %out_qubits_40 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_42 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %4 : !quantum.bit
    %out_qubits_43:2 = quantum.custom "CZ"() %out_qubits_41#0, %out_qubits_42 : !quantum.bit, !quantum.bit
    %out_qubits_44 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_43#1 : !quantum.bit
    %out_qubits_45:2 = quantum.custom "CZ"() %out_qubits_43#0, %out_qubits_44 : !quantum.bit, !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_46 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %5 : !quantum.bit
    %out_qubits_47:2 = quantum.custom "CZ"() %out_qubits_45#0, %out_qubits_46 : !quantum.bit, !quantum.bit
    %out_qubits_48 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_47#1 : !quantum.bit
    %out_qubits_49:2 = quantum.custom "CZ"() %out_qubits_47#0, %out_qubits_48 : !quantum.bit, !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_50 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %6 : !quantum.bit
    %out_qubits_51:2 = quantum.custom "CZ"() %out_qubits_49#0, %out_qubits_50 : !quantum.bit, !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_51#1 : !quantum.bit
    %out_qubits_53:2 = quantum.custom "CZ"() %out_qubits_51#0, %out_qubits_52 : !quantum.bit, !quantum.bit
    %out_qubits_54 = quantum.custom "Rot"(%cst_24, %cst_32, %cst_31) %out_qubits_53#0 : !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %out_qubits_37#1 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_55, %out_qubits_41#1 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_56#1 : !quantum.bit
    %out_qubits_58:2 = quantum.custom "CZ"() %out_qubits_56#0, %out_qubits_57 : !quantum.bit, !quantum.bit
    %out_qubits_59:2 = quantum.custom "CZ"() %out_qubits_58#0, %out_qubits_45#1 : !quantum.bit, !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_59#1 : !quantum.bit
    %out_qubits_61:2 = quantum.custom "CZ"() %out_qubits_59#0, %out_qubits_60 : !quantum.bit, !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_61#0, %out_qubits_49#1 : !quantum.bit, !quantum.bit
    %out_qubits_63 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_62#1 : !quantum.bit
    %out_qubits_64:2 = quantum.custom "CZ"() %out_qubits_62#0, %out_qubits_63 : !quantum.bit, !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_64#0, %out_qubits_53#1 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_65#1 : !quantum.bit
    %out_qubits_67:2 = quantum.custom "CZ"() %out_qubits_65#0, %out_qubits_66 : !quantum.bit, !quantum.bit
    %out_qubits_68 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %out_qubits_67#0 : !quantum.bit
    %out_qubits_69:2 = quantum.custom "CZ"() %out_qubits_54, %out_qubits_68 : !quantum.bit, !quantum.bit
    %out_qubits_70 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_69#1 : !quantum.bit
    %out_qubits_71:2 = quantum.custom "CZ"() %out_qubits_69#0, %out_qubits_70 : !quantum.bit, !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %out_qubits_58#1 : !quantum.bit
    %out_qubits_73:2 = quantum.custom "CZ"() %out_qubits_72, %out_qubits_61#1 : !quantum.bit, !quantum.bit
    %out_qubits_74 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_73#1 : !quantum.bit
    %out_qubits_75:2 = quantum.custom "CZ"() %out_qubits_73#0, %out_qubits_74 : !quantum.bit, !quantum.bit
    %out_qubits_76:2 = quantum.custom "CZ"() %out_qubits_75#0, %out_qubits_64#1 : !quantum.bit, !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_76#1 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_76#0, %out_qubits_77 : !quantum.bit, !quantum.bit
    %out_qubits_79:2 = quantum.custom "CZ"() %out_qubits_78#0, %out_qubits_67#1 : !quantum.bit, !quantum.bit
    %out_qubits_80 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_79#1 : !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_79#0, %out_qubits_80 : !quantum.bit, !quantum.bit
    %out_qubits_82 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %out_qubits_81#0 : !quantum.bit
    %out_qubits_83:2 = quantum.custom "CZ"() %out_qubits_71#0, %out_qubits_82 : !quantum.bit, !quantum.bit
    %out_qubits_84 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_83#1 : !quantum.bit
    %out_qubits_85:2 = quantum.custom "CZ"() %out_qubits_83#0, %out_qubits_84 : !quantum.bit, !quantum.bit
    %out_qubits_86 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %out_qubits_75#1 : !quantum.bit
    %out_qubits_87:2 = quantum.custom "CZ"() %out_qubits_86, %out_qubits_78#1 : !quantum.bit, !quantum.bit
    %out_qubits_88 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_87#1 : !quantum.bit
    %out_qubits_89:2 = quantum.custom "CZ"() %out_qubits_87#0, %out_qubits_88 : !quantum.bit, !quantum.bit
    %out_qubits_90:2 = quantum.custom "CZ"() %out_qubits_89#0, %out_qubits_81#1 : !quantum.bit, !quantum.bit
    %out_qubits_91 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_90#1 : !quantum.bit
    %out_qubits_92:2 = quantum.custom "CZ"() %out_qubits_90#0, %out_qubits_91 : !quantum.bit, !quantum.bit
    %out_qubits_93 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %out_qubits_92#0 : !quantum.bit
    %out_qubits_94:2 = quantum.custom "CZ"() %out_qubits_85#0, %out_qubits_93 : !quantum.bit, !quantum.bit
    %out_qubits_95 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_94#1 : !quantum.bit
    %out_qubits_96:2 = quantum.custom "CZ"() %out_qubits_94#0, %out_qubits_95 : !quantum.bit, !quantum.bit
    %out_qubits_97 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %out_qubits_89#1 : !quantum.bit
    %out_qubits_98:2 = quantum.custom "CZ"() %out_qubits_97, %out_qubits_92#1 : !quantum.bit, !quantum.bit
    %out_qubits_99 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_98#1 : !quantum.bit
    %out_qubits_100:2 = quantum.custom "CZ"() %out_qubits_98#0, %out_qubits_99 : !quantum.bit, !quantum.bit
    %out_qubits_101 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %out_qubits_100#0 : !quantum.bit
    %out_qubits_102:2 = quantum.custom "CZ"() %out_qubits_96#0, %out_qubits_101 : !quantum.bit, !quantum.bit
    %out_qubits_103 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_102#1 : !quantum.bit
    %out_qubits_104:2 = quantum.custom "CZ"() %out_qubits_102#0, %out_qubits_103 : !quantum.bit, !quantum.bit
    %out_qubits_105 = quantum.custom "Rot"(%cst_23, %cst_32, %cst_31) %out_qubits_100#1 : !quantum.bit
    %out_qubits_106:2 = quantum.custom "CZ"() %out_qubits_104#0, %out_qubits_105 : !quantum.bit, !quantum.bit
    %out_qubits_107 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_106#1 : !quantum.bit
    %out_qubits_108:2 = quantum.custom "CZ"() %out_qubits_106#0, %out_qubits_107 : !quantum.bit, !quantum.bit
    %out_qubits_109 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_108#0 : !quantum.bit
    %out_qubits_110 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %out_qubits_71#1 : !quantum.bit
    %out_qubits_111:2 = quantum.custom "CZ"() %out_qubits_110, %out_qubits_85#1 : !quantum.bit, !quantum.bit
    %out_qubits_112 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_111#1 : !quantum.bit
    %out_qubits_113:2 = quantum.custom "CZ"() %out_qubits_111#0, %out_qubits_112 : !quantum.bit, !quantum.bit
    %out_qubits_114:2 = quantum.custom "CZ"() %out_qubits_113#0, %out_qubits_96#1 : !quantum.bit, !quantum.bit
    %out_qubits_115 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_114#1 : !quantum.bit
    %out_qubits_116:2 = quantum.custom "CZ"() %out_qubits_114#0, %out_qubits_115 : !quantum.bit, !quantum.bit
    %out_qubits_117:2 = quantum.custom "CZ"() %out_qubits_116#0, %out_qubits_104#1 : !quantum.bit, !quantum.bit
    %out_qubits_118 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_117#1 : !quantum.bit
    %out_qubits_119:2 = quantum.custom "CZ"() %out_qubits_117#0, %out_qubits_118 : !quantum.bit, !quantum.bit
    %out_qubits_120:2 = quantum.custom "CZ"() %out_qubits_119#0, %out_qubits_108#1 : !quantum.bit, !quantum.bit
    %out_qubits_121 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_120#1 : !quantum.bit
    %out_qubits_122:2 = quantum.custom "CZ"() %out_qubits_120#0, %out_qubits_121 : !quantum.bit, !quantum.bit
    %out_qubits_123 = quantum.custom "Rot"(%cst_31, %cst_19, %cst_18) %out_qubits_122#0 : !quantum.bit
    %out_qubits_124 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %out_qubits_113#1 : !quantum.bit
    %out_qubits_125:2 = quantum.custom "CZ"() %out_qubits_124, %out_qubits_116#1 : !quantum.bit, !quantum.bit
    %out_qubits_126 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_125#1 : !quantum.bit
    %out_qubits_127:2 = quantum.custom "CZ"() %out_qubits_125#0, %out_qubits_126 : !quantum.bit, !quantum.bit
    %out_qubits_128:2 = quantum.custom "CZ"() %out_qubits_127#0, %out_qubits_119#1 : !quantum.bit, !quantum.bit
    %out_qubits_129 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_128#1 : !quantum.bit
    %out_qubits_130:2 = quantum.custom "CZ"() %out_qubits_128#0, %out_qubits_129 : !quantum.bit, !quantum.bit
    %out_qubits_131:2 = quantum.custom "CZ"() %out_qubits_130#0, %out_qubits_122#1 : !quantum.bit, !quantum.bit
    %out_qubits_132 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_131#1 : !quantum.bit
    %out_qubits_133:2 = quantum.custom "CZ"() %out_qubits_131#0, %out_qubits_132 : !quantum.bit, !quantum.bit
    %out_qubits_134 = quantum.custom "Rot"(%cst_31, %cst_17, %cst_18) %out_qubits_133#0 : !quantum.bit
    %out_qubits_135 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %out_qubits_127#1 : !quantum.bit
    %out_qubits_136:2 = quantum.custom "CZ"() %out_qubits_135, %out_qubits_130#1 : !quantum.bit, !quantum.bit
    %out_qubits_137 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_136#1 : !quantum.bit
    %out_qubits_138:2 = quantum.custom "CZ"() %out_qubits_136#0, %out_qubits_137 : !quantum.bit, !quantum.bit
    %out_qubits_139:2 = quantum.custom "CZ"() %out_qubits_138#0, %out_qubits_133#1 : !quantum.bit, !quantum.bit
    %out_qubits_140 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_139#1 : !quantum.bit
    %out_qubits_141:2 = quantum.custom "CZ"() %out_qubits_139#0, %out_qubits_140 : !quantum.bit, !quantum.bit
    %out_qubits_142 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_18) %out_qubits_141#0 : !quantum.bit
    %out_qubits_143 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %out_qubits_138#1 : !quantum.bit
    %out_qubits_144:2 = quantum.custom "CZ"() %out_qubits_143, %out_qubits_141#1 : !quantum.bit, !quantum.bit
    %out_qubits_145 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %out_qubits_144#1 : !quantum.bit
    %out_qubits_146:2 = quantum.custom "CZ"() %out_qubits_144#0, %out_qubits_145 : !quantum.bit, !quantum.bit
    %out_qubits_147 = quantum.custom "Rot"(%cst_31, %cst_14, %cst_18) %out_qubits_146#0 : !quantum.bit
    %out_qubits_148 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_146#1 : !quantum.bit
    %out_qubits_149:2 = quantum.custom "CZ"() %out_qubits_147, %out_qubits_148 : !quantum.bit, !quantum.bit
    %out_qubits_150 = quantum.custom "Rot"(%cst_10, %cst_32, %cst_31) %out_qubits_149#0 : !quantum.bit
    %out_qubits_151:2 = quantum.custom "CZ"() %out_qubits_142, %out_qubits_150 : !quantum.bit, !quantum.bit
    %out_qubits_152 = quantum.custom "Rot"(%cst_10, %cst_32, %cst_31) %out_qubits_151#0 : !quantum.bit
    %out_qubits_153:2 = quantum.custom "CZ"() %out_qubits_134, %out_qubits_152 : !quantum.bit, !quantum.bit
    %out_qubits_154 = quantum.custom "Rot"(%cst_10, %cst_32, %cst_31) %out_qubits_153#0 : !quantum.bit
    %out_qubits_155:2 = quantum.custom "CZ"() %out_qubits_123, %out_qubits_154 : !quantum.bit, !quantum.bit
    %out_qubits_156 = quantum.custom "Rot"(%cst_10, %cst_32, %cst_31) %out_qubits_155#0 : !quantum.bit
    %out_qubits_157:2 = quantum.custom "CZ"() %out_qubits_109, %out_qubits_156 : !quantum.bit, !quantum.bit
    %out_qubits_158 = quantum.custom "Rot"(%cst_9, %cst_8, %cst_7) %out_qubits_157#0 : !quantum.bit
    %out_qubits_159 = quantum.custom "Rot"(%cst_6, %cst_5, %cst_7) %out_qubits_157#1 : !quantum.bit
    %out_qubits_160 = quantum.custom "Rot"(%cst_6, %cst_4, %cst_7) %out_qubits_155#1 : !quantum.bit
    %out_qubits_161 = quantum.custom "Rot"(%cst_3, %cst_2, %cst_7) %out_qubits_153#1 : !quantum.bit
    %out_qubits_162 = quantum.custom "Rot"(%cst_6, %cst_1, %cst_7) %out_qubits_151#1 : !quantum.bit
    %out_qubits_163 = quantum.custom "Rot"(%cst_6, %cst_0, %cst_7) %out_qubits_149#1 : !quantum.bit
    quantum.gphase(%cst)
    %7 = quantum.compbasis qubits %out_qubits_158, %out_qubits_159, %out_qubits_160, %out_qubits_161, %out_qubits_162, %out_qubits_163 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x6xf64>
    %9 = stablehlo.convert %8 : (tensor<128x6xf64>) -> tensor<128x6xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_158 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_159 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_160 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_161 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_162 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_163 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x6xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}