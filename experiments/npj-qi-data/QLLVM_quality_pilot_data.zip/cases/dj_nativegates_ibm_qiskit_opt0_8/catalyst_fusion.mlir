module @circuit {
  func.func public @jit_circuit() -> tensor<128x7xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x7xi64>
    return %0 : tensor<128x7xi64>
  }
  func.func public @circuit_0() -> tensor<128x7xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -26.70353755551325 : f64
    %cst_0 = arith.constant 1.5707963267948966 : f64
    %cst_1 = arith.constant -1.5707963267948963 : f64
    %cst_2 = arith.constant 3.1415926535897931 : f64
    %cst_3 = arith.constant -4.7123889803846897 : f64
    %cst_4 = arith.constant 0.000000e+00 : f64
    %cst_5 = arith.constant 1.5707963267948968 : f64
    %cst_6 = arith.constant 6.2831853071795862 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 8) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_6, %cst_5, %cst_4) %1 : !quantum.bit
    %2 = quantum.extract %0[ 7] : !quantum.reg -> !quantum.bit
    %out_qubits_7 = quantum.custom "Rot"(%cst_3, %cst_2, %cst_1) %2 : !quantum.bit
    %out_qubits_8:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_7 : !quantum.bit, !quantum.bit
    %out_qubits_9 = quantum.custom "Rot"(%cst_2, %cst_5, %cst_2) %out_qubits_8#0 : !quantum.bit
    %3 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_10 = quantum.custom "Rot"(%cst_6, %cst_5, %cst_4) %3 : !quantum.bit
    %out_qubits_11:2 = quantum.custom "CZ"() %out_qubits_10, %out_qubits_8#1 : !quantum.bit, !quantum.bit
    %out_qubits_12 = quantum.custom "Rot"(%cst_2, %cst_5, %cst_2) %out_qubits_11#0 : !quantum.bit
    %4 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_13 = quantum.custom "Rot"(%cst_2, %cst_0, %cst_4) %4 : !quantum.bit
    %out_qubits_14:2 = quantum.custom "CZ"() %out_qubits_13, %out_qubits_11#1 : !quantum.bit, !quantum.bit
    %out_qubits_15 = quantum.custom "Hadamard"() %out_qubits_14#0 : !quantum.bit
    %5 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_16 = quantum.custom "Rot"(%cst_6, %cst_5, %cst_4) %5 : !quantum.bit
    %out_qubits_17:2 = quantum.custom "CZ"() %out_qubits_16, %out_qubits_14#1 : !quantum.bit, !quantum.bit
    %out_qubits_18 = quantum.custom "Rot"(%cst_2, %cst_5, %cst_2) %out_qubits_17#0 : !quantum.bit
    %6 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_19 = quantum.custom "Rot"(%cst_2, %cst_0, %cst_4) %6 : !quantum.bit
    %out_qubits_20:2 = quantum.custom "CZ"() %out_qubits_19, %out_qubits_17#1 : !quantum.bit, !quantum.bit
    %out_qubits_21 = quantum.custom "Hadamard"() %out_qubits_20#0 : !quantum.bit
    %7 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_22 = quantum.custom "Rot"(%cst_6, %cst_5, %cst_4) %7 : !quantum.bit
    %out_qubits_23:2 = quantum.custom "CZ"() %out_qubits_22, %out_qubits_20#1 : !quantum.bit, !quantum.bit
    %out_qubits_24 = quantum.custom "Rot"(%cst_2, %cst_5, %cst_2) %out_qubits_23#0 : !quantum.bit
    %8 = quantum.extract %0[ 6] : !quantum.reg -> !quantum.bit
    %out_qubits_25 = quantum.custom "Rot"(%cst_6, %cst_5, %cst_4) %8 : !quantum.bit
    %out_qubits_26:2 = quantum.custom "CZ"() %out_qubits_25, %out_qubits_23#1 : !quantum.bit, !quantum.bit
    %out_qubits_27 = quantum.custom "Rot"(%cst_2, %cst_5, %cst_2) %out_qubits_26#0 : !quantum.bit
    %out_qubits_28 = quantum.custom "Hadamard"() %out_qubits_26#1 : !quantum.bit
    quantum.gphase(%cst)
    quantum.gphase(%cst_3)
    %9 = quantum.compbasis qubits %out_qubits_9, %out_qubits_12, %out_qubits_15, %out_qubits_18, %out_qubits_21, %out_qubits_24, %out_qubits_27 : !quantum.obs
    %10 = quantum.sample %9 : tensor<128x7xf64>
    %11 = stablehlo.convert %10 : (tensor<128x7xf64>) -> tensor<128x7xi64>
    %12 = quantum.insert %0[ 0], %out_qubits_9 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 1], %out_qubits_12 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 2], %out_qubits_15 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 3], %out_qubits_18 : !quantum.reg, !quantum.bit
    %16 = quantum.insert %15[ 4], %out_qubits_21 : !quantum.reg, !quantum.bit
    %17 = quantum.insert %16[ 5], %out_qubits_24 : !quantum.reg, !quantum.bit
    %18 = quantum.insert %17[ 6], %out_qubits_27 : !quantum.reg, !quantum.bit
    %19 = quantum.insert %18[ 7], %out_qubits_28 : !quantum.reg, !quantum.bit
    quantum.dealloc %19 : !quantum.reg
    quantum.device_release
    return %11 : tensor<128x7xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}