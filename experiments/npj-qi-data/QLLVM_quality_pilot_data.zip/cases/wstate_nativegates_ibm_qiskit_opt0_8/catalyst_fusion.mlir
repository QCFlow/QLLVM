module @circuit {
  func.func public @jit_circuit() -> tensor<128x8xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x8xi64>
    return %0 : tensor<128x8xi64>
  }
  func.func public @circuit_0() -> tensor<128x8xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -10.995574287564276 : f64
    %cst_0 = arith.constant -109.95574287564266 : f64
    %cst_1 = arith.constant 7.8539816339744828 : f64
    %cst_2 = arith.constant 10.995574287564276 : f64
    %cst_3 = arith.constant 0.000000e+00 : f64
    %cst_4 = arith.constant 0.78539816339744783 : f64
    %cst_5 = arith.constant -6.6613381477509392E-16 : f64
    %cst_6 = arith.constant 0.9553166181245093 : f64
    %cst_7 = arith.constant 1.047197551196597 : f64
    %cst_8 = arith.constant 3.3306690738754696E-16 : f64
    %cst_9 = arith.constant 1.1071487177940902 : f64
    %cst_10 = arith.constant 1.1102230246251565E-16 : f64
    %cst_11 = arith.constant 1.1502619915109316 : f64
    %cst_12 = arith.constant 1.1831996401397156 : f64
    %cst_13 = arith.constant -2.2204460492503131E-16 : f64
    %cst_14 = arith.constant -1.5707963267948963 : f64
    %cst_15 = arith.constant 1.2094292028881888 : f64
    %cst_16 = arith.constant 2.2204460492503131E-16 : f64
    %cst_17 = arith.constant -1.5707963267948966 : f64
    %cst_18 = arith.constant 3.1415926535897931 : f64
    %cst_19 = arith.constant 1.5707963267948966 : f64
    %cst_20 = arith.constant 1.2094292028881894 : f64
    %cst_21 = arith.constant 1.1831996401397167 : f64
    %cst_22 = arith.constant 1.1502619915109318 : f64
    %cst_23 = arith.constant 1.1071487177940911 : f64
    %cst_24 = arith.constant 1.0471975511965979 : f64
    %cst_25 = arith.constant 3.1415926535897927 : f64
    %cst_26 = arith.constant 0.95531661812450885 : f64
    %cst_27 = arith.constant 3.1415926535897936 : f64
    %cst_28 = arith.constant 3.1415926535897922 : f64
    %cst_29 = arith.constant 0.78539816339744839 : f64
    %cst_30 = arith.constant 3.141592653589794 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 8) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_31 = quantum.custom "Rot"(%cst_27, %cst_26, %cst_25) %2 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_32 = quantum.custom "Rot"(%cst_27, %cst_24, %cst_25) %3 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_33 = quantum.custom "Rot"(%cst_27, %cst_23, %cst_25) %4 : !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_34 = quantum.custom "Rot"(%cst_27, %cst_22, %cst_25) %5 : !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_35 = quantum.custom "Rot"(%cst_27, %cst_21, %cst_25) %6 : !quantum.bit
    %7 = quantum.extract %0[ 6] : !quantum.reg -> !quantum.bit
    %out_qubits_36 = quantum.custom "Rot"(%cst_27, %cst_20, %cst_25) %7 : !quantum.bit
    %8 = quantum.extract %0[ 7] : !quantum.reg -> !quantum.bit
    %out_qubits_37 = quantum.custom "Rot"(%cst_19, %cst_18, %cst_17) %8 : !quantum.bit
    %out_qubits_38:2 = quantum.custom "CZ"() %out_qubits_37, %out_qubits_36 : !quantum.bit, !quantum.bit
    %out_qubits_39 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_38#1 : !quantum.bit
    %out_qubits_40:2 = quantum.custom "CZ"() %out_qubits_39, %out_qubits_35 : !quantum.bit, !quantum.bit
    %out_qubits_41 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_14) %out_qubits_40#1 : !quantum.bit
    %out_qubits_42:2 = quantum.custom "CZ"() %out_qubits_41, %out_qubits_34 : !quantum.bit, !quantum.bit
    %out_qubits_43 = quantum.custom "Rot"(%cst_16, %cst_11, %cst_17) %out_qubits_42#1 : !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_43, %out_qubits_33 : !quantum.bit, !quantum.bit
    %out_qubits_45 = quantum.custom "Rot"(%cst_10, %cst_9, %cst_17) %out_qubits_44#1 : !quantum.bit
    %out_qubits_46:2 = quantum.custom "CZ"() %out_qubits_45, %out_qubits_32 : !quantum.bit, !quantum.bit
    %out_qubits_47 = quantum.custom "Rot"(%cst_8, %cst_7, %cst_17) %out_qubits_46#1 : !quantum.bit
    %out_qubits_48:2 = quantum.custom "CZ"() %out_qubits_47, %out_qubits_31 : !quantum.bit, !quantum.bit
    %out_qubits_49 = quantum.custom "Rot"(%cst_13, %cst_6, %cst_14) %out_qubits_48#1 : !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits_49, %out_qubits : !quantum.bit, !quantum.bit
    %out_qubits_51 = quantum.custom "Rot"(%cst_5, %cst_4, %cst_17) %out_qubits_50#1 : !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_18, %cst_19, %cst_3) %out_qubits_38#0 : !quantum.bit
    %out_qubits_53:2 = quantum.custom "CZ"() %out_qubits_40#0, %out_qubits_52 : !quantum.bit, !quantum.bit
    %out_qubits_54 = quantum.custom "Rot"(%cst_2, %cst_19, %cst_3) %out_qubits_53#0 : !quantum.bit
    %out_qubits_55:2 = quantum.custom "CZ"() %out_qubits_42#0, %out_qubits_54 : !quantum.bit, !quantum.bit
    %out_qubits_56 = quantum.custom "Rot"(%cst_2, %cst_19, %cst_3) %out_qubits_55#0 : !quantum.bit
    %out_qubits_57:2 = quantum.custom "CZ"() %out_qubits_44#0, %out_qubits_56 : !quantum.bit, !quantum.bit
    %out_qubits_58 = quantum.custom "Rot"(%cst_2, %cst_19, %cst_3) %out_qubits_57#0 : !quantum.bit
    %out_qubits_59:2 = quantum.custom "CZ"() %out_qubits_46#0, %out_qubits_58 : !quantum.bit, !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_2, %cst_19, %cst_3) %out_qubits_59#0 : !quantum.bit
    %out_qubits_61:2 = quantum.custom "CZ"() %out_qubits_48#0, %out_qubits_60 : !quantum.bit, !quantum.bit
    %out_qubits_62 = quantum.custom "Rot"(%cst_2, %cst_19, %cst_3) %out_qubits_61#0 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_50#0, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Rot"(%cst_2, %cst_19, %cst_3) %out_qubits_63#0 : !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_51, %out_qubits_64 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "RZ"(%cst_1) %out_qubits_65#0 : !quantum.bit
    %out_qubits_67 = quantum.custom "Hadamard"() %out_qubits_65#1 : !quantum.bit
    %out_qubits_68 = quantum.custom "Hadamard"() %out_qubits_63#1 : !quantum.bit
    %out_qubits_69 = quantum.custom "Hadamard"() %out_qubits_61#1 : !quantum.bit
    %out_qubits_70 = quantum.custom "Hadamard"() %out_qubits_59#1 : !quantum.bit
    %out_qubits_71 = quantum.custom "Hadamard"() %out_qubits_57#1 : !quantum.bit
    %out_qubits_72 = quantum.custom "Hadamard"() %out_qubits_55#1 : !quantum.bit
    %out_qubits_73 = quantum.custom "Hadamard"() %out_qubits_53#1 : !quantum.bit
    quantum.gphase(%cst_0)
    quantum.gphase(%cst)
    %9 = quantum.compbasis qubits %out_qubits_66, %out_qubits_67, %out_qubits_68, %out_qubits_69, %out_qubits_70, %out_qubits_71, %out_qubits_72, %out_qubits_73 : !quantum.obs
    %10 = quantum.sample %9 : tensor<128x8xf64>
    %11 = stablehlo.convert %10 : (tensor<128x8xf64>) -> tensor<128x8xi64>
    %12 = quantum.insert %0[ 0], %out_qubits_66 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 1], %out_qubits_67 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 2], %out_qubits_68 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 3], %out_qubits_69 : !quantum.reg, !quantum.bit
    %16 = quantum.insert %15[ 4], %out_qubits_70 : !quantum.reg, !quantum.bit
    %17 = quantum.insert %16[ 5], %out_qubits_71 : !quantum.reg, !quantum.bit
    %18 = quantum.insert %17[ 6], %out_qubits_72 : !quantum.reg, !quantum.bit
    %19 = quantum.insert %18[ 7], %out_qubits_73 : !quantum.reg, !quantum.bit
    quantum.dealloc %19 : !quantum.reg
    quantum.device_release
    return %11 : tensor<128x8xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}