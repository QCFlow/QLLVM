module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 11.131587357426236 : f64
    %cst_0 = arith.constant 3.224142666169703 : f64
    %cst_1 = arith.constant 12.913348193314171 : f64
    %cst_2 = arith.constant 3.8815444023791414 : f64
    %cst_3 = arith.constant 11.630420755048512 : f64
    %cst_4 = arith.constant 2.7269903460220899 : f64
    %cst_5 = arith.constant 11.940547651317287 : f64
    %cst_6 = arith.constant 2.7761197097590848 : f64
    %cst_7 = arith.constant 12.089688059235202 : f64
    %cst_8 = arith.constant 4.4898120631107119 : f64
    %cst_9 = arith.constant 10.199750812101135 : f64
    %cst_10 = arith.constant 5.7665448818829645 : f64
    %cst_11 = arith.constant 8.747262388185419 : f64
    %cst_12 = arith.constant 1.8339114230470699 : f64
    %cst_13 = arith.constant 11.262888435555874 : f64
    %cst_14 = arith.constant 4.5349224058662214 : f64
    %cst_15 = arith.constant 11.702596417341395 : f64
    %cst_16 = arith.constant 5.9903470647748058 : f64
    %cst_17 = arith.constant 12.959829720533188 : f64
    %cst_18 = arith.constant 4.3062427408998136 : f64
    %cst_19 = arith.constant 11.072180537731052 : f64
    %cst_20 = arith.constant 0.55505542245711625 : f64
    %cst_21 = arith.constant 7.8787893229548676 : f64
    %cst_22 = arith.constant 1.0625547235745714 : f64
    %cst_23 = arith.constant 12.632537030521807 : f64
    %cst_24 = arith.constant 4.7048735527256351 : f64
    %cst_25 = arith.constant 9.0984473157300503 : f64
    %cst_26 = arith.constant 3.9813292796090529 : f64
    %cst_27 = arith.constant 9.2664206142771626 : f64
    %cst_28 = arith.constant 0.13038834331032634 : f64
    %cst_29 = arith.constant 10.986193569200113 : f64
    %cst_30 = arith.constant 4.8463505328979251 : f64
    %cst_31 = arith.constant -1.5707963267948966 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst_31) %1 : !quantum.bit
    %out_qubits_32 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_33 = quantum.custom "RZ"(%cst_30) %out_qubits_32 : !quantum.bit
    %out_qubits_34 = quantum.custom "Hadamard"() %out_qubits_33 : !quantum.bit
    %out_qubits_35 = quantum.custom "RZ"(%cst_29) %out_qubits_34 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_36 = quantum.custom "RZ"(%cst_31) %2 : !quantum.bit
    %out_qubits_37 = quantum.custom "Hadamard"() %out_qubits_36 : !quantum.bit
    %out_qubits_38 = quantum.custom "RZ"(%cst_28) %out_qubits_37 : !quantum.bit
    %out_qubits_39 = quantum.custom "Hadamard"() %out_qubits_38 : !quantum.bit
    %out_qubits_40 = quantum.custom "RZ"(%cst_27) %out_qubits_39 : !quantum.bit
    %out_qubits_41 = quantum.custom "Hadamard"() %out_qubits_40 : !quantum.bit
    %out_qubits_42:2 = quantum.custom "CZ"() %out_qubits_35, %out_qubits_41 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_43 = quantum.custom "RZ"(%cst_31) %3 : !quantum.bit
    %out_qubits_44 = quantum.custom "Hadamard"() %out_qubits_43 : !quantum.bit
    %out_qubits_45 = quantum.custom "RZ"(%cst_26) %out_qubits_44 : !quantum.bit
    %out_qubits_46 = quantum.custom "Hadamard"() %out_qubits_45 : !quantum.bit
    %out_qubits_47 = quantum.custom "RZ"(%cst_25) %out_qubits_46 : !quantum.bit
    %out_qubits_48 = quantum.custom "Hadamard"() %out_qubits_47 : !quantum.bit
    %out_qubits_49:2 = quantum.custom "CZ"() %out_qubits_42#0, %out_qubits_48 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_50 = quantum.custom "RZ"(%cst_31) %4 : !quantum.bit
    %out_qubits_51 = quantum.custom "Hadamard"() %out_qubits_50 : !quantum.bit
    %out_qubits_52 = quantum.custom "RZ"(%cst_24) %out_qubits_51 : !quantum.bit
    %out_qubits_53 = quantum.custom "Hadamard"() %out_qubits_52 : !quantum.bit
    %out_qubits_54 = quantum.custom "RZ"(%cst_23) %out_qubits_53 : !quantum.bit
    %out_qubits_55 = quantum.custom "Hadamard"() %out_qubits_54 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_49#0, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "RZ"(%cst_31) %out_qubits_56#0 : !quantum.bit
    %out_qubits_58 = quantum.custom "Hadamard"() %out_qubits_57 : !quantum.bit
    %out_qubits_59 = quantum.custom "RZ"(%cst_22) %out_qubits_58 : !quantum.bit
    %out_qubits_60 = quantum.custom "Hadamard"() %out_qubits_59 : !quantum.bit
    %out_qubits_61 = quantum.custom "RZ"(%cst_21) %out_qubits_60 : !quantum.bit
    %out_qubits_62 = quantum.custom "Hadamard"() %out_qubits_42#1 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_62, %out_qubits_49#1 : !quantum.bit, !quantum.bit
    %out_qubits_64:2 = quantum.custom "CZ"() %out_qubits_63#0, %out_qubits_56#1 : !quantum.bit, !quantum.bit
    %out_qubits_65 = quantum.custom "RZ"(%cst_31) %out_qubits_64#0 : !quantum.bit
    %out_qubits_66 = quantum.custom "Hadamard"() %out_qubits_65 : !quantum.bit
    %out_qubits_67 = quantum.custom "RZ"(%cst_20) %out_qubits_66 : !quantum.bit
    %out_qubits_68 = quantum.custom "Hadamard"() %out_qubits_67 : !quantum.bit
    %out_qubits_69 = quantum.custom "RZ"(%cst_19) %out_qubits_68 : !quantum.bit
    %out_qubits_70 = quantum.custom "Hadamard"() %out_qubits_69 : !quantum.bit
    %out_qubits_71:2 = quantum.custom "CZ"() %out_qubits_61, %out_qubits_70 : !quantum.bit, !quantum.bit
    %out_qubits_72 = quantum.custom "Hadamard"() %out_qubits_63#1 : !quantum.bit
    %out_qubits_73:2 = quantum.custom "CZ"() %out_qubits_72, %out_qubits_64#1 : !quantum.bit, !quantum.bit
    %out_qubits_74 = quantum.custom "RZ"(%cst_31) %out_qubits_73#0 : !quantum.bit
    %out_qubits_75 = quantum.custom "Hadamard"() %out_qubits_74 : !quantum.bit
    %out_qubits_76 = quantum.custom "RZ"(%cst_18) %out_qubits_75 : !quantum.bit
    %out_qubits_77 = quantum.custom "Hadamard"() %out_qubits_76 : !quantum.bit
    %out_qubits_78 = quantum.custom "RZ"(%cst_17) %out_qubits_77 : !quantum.bit
    %out_qubits_79 = quantum.custom "Hadamard"() %out_qubits_78 : !quantum.bit
    %out_qubits_80:2 = quantum.custom "CZ"() %out_qubits_71#0, %out_qubits_79 : !quantum.bit, !quantum.bit
    %out_qubits_81 = quantum.custom "Hadamard"() %out_qubits_73#1 : !quantum.bit
    %out_qubits_82 = quantum.custom "RZ"(%cst_31) %out_qubits_81 : !quantum.bit
    %out_qubits_83 = quantum.custom "Hadamard"() %out_qubits_82 : !quantum.bit
    %out_qubits_84 = quantum.custom "RZ"(%cst_16) %out_qubits_83 : !quantum.bit
    %out_qubits_85 = quantum.custom "Hadamard"() %out_qubits_84 : !quantum.bit
    %out_qubits_86 = quantum.custom "RZ"(%cst_15) %out_qubits_85 : !quantum.bit
    %out_qubits_87 = quantum.custom "Hadamard"() %out_qubits_86 : !quantum.bit
    %out_qubits_88:2 = quantum.custom "CZ"() %out_qubits_80#0, %out_qubits_87 : !quantum.bit, !quantum.bit
    %out_qubits_89 = quantum.custom "RZ"(%cst_31) %out_qubits_88#0 : !quantum.bit
    %out_qubits_90 = quantum.custom "Hadamard"() %out_qubits_89 : !quantum.bit
    %out_qubits_91 = quantum.custom "RZ"(%cst_14) %out_qubits_90 : !quantum.bit
    %out_qubits_92 = quantum.custom "Hadamard"() %out_qubits_91 : !quantum.bit
    %out_qubits_93 = quantum.custom "RZ"(%cst_13) %out_qubits_92 : !quantum.bit
    %out_qubits_94 = quantum.custom "Hadamard"() %out_qubits_71#1 : !quantum.bit
    %out_qubits_95:2 = quantum.custom "CZ"() %out_qubits_94, %out_qubits_80#1 : !quantum.bit, !quantum.bit
    %out_qubits_96:2 = quantum.custom "CZ"() %out_qubits_95#0, %out_qubits_88#1 : !quantum.bit, !quantum.bit
    %out_qubits_97 = quantum.custom "RZ"(%cst_31) %out_qubits_96#0 : !quantum.bit
    %out_qubits_98 = quantum.custom "Hadamard"() %out_qubits_97 : !quantum.bit
    %out_qubits_99 = quantum.custom "RZ"(%cst_12) %out_qubits_98 : !quantum.bit
    %out_qubits_100 = quantum.custom "Hadamard"() %out_qubits_99 : !quantum.bit
    %out_qubits_101 = quantum.custom "RZ"(%cst_11) %out_qubits_100 : !quantum.bit
    %out_qubits_102 = quantum.custom "Hadamard"() %out_qubits_101 : !quantum.bit
    %out_qubits_103:2 = quantum.custom "CZ"() %out_qubits_93, %out_qubits_102 : !quantum.bit, !quantum.bit
    %out_qubits_104 = quantum.custom "Hadamard"() %out_qubits_95#1 : !quantum.bit
    %out_qubits_105:2 = quantum.custom "CZ"() %out_qubits_104, %out_qubits_96#1 : !quantum.bit, !quantum.bit
    %out_qubits_106 = quantum.custom "RZ"(%cst_31) %out_qubits_105#0 : !quantum.bit
    %out_qubits_107 = quantum.custom "Hadamard"() %out_qubits_106 : !quantum.bit
    %out_qubits_108 = quantum.custom "RZ"(%cst_10) %out_qubits_107 : !quantum.bit
    %out_qubits_109 = quantum.custom "Hadamard"() %out_qubits_108 : !quantum.bit
    %out_qubits_110 = quantum.custom "RZ"(%cst_9) %out_qubits_109 : !quantum.bit
    %out_qubits_111 = quantum.custom "Hadamard"() %out_qubits_110 : !quantum.bit
    %out_qubits_112:2 = quantum.custom "CZ"() %out_qubits_103#0, %out_qubits_111 : !quantum.bit, !quantum.bit
    %out_qubits_113 = quantum.custom "Hadamard"() %out_qubits_105#1 : !quantum.bit
    %out_qubits_114 = quantum.custom "RZ"(%cst_31) %out_qubits_113 : !quantum.bit
    %out_qubits_115 = quantum.custom "Hadamard"() %out_qubits_114 : !quantum.bit
    %out_qubits_116 = quantum.custom "RZ"(%cst_8) %out_qubits_115 : !quantum.bit
    %out_qubits_117 = quantum.custom "Hadamard"() %out_qubits_116 : !quantum.bit
    %out_qubits_118 = quantum.custom "RZ"(%cst_7) %out_qubits_117 : !quantum.bit
    %out_qubits_119 = quantum.custom "Hadamard"() %out_qubits_118 : !quantum.bit
    %out_qubits_120:2 = quantum.custom "CZ"() %out_qubits_112#0, %out_qubits_119 : !quantum.bit, !quantum.bit
    %out_qubits_121 = quantum.custom "RZ"(%cst_31) %out_qubits_120#0 : !quantum.bit
    %out_qubits_122 = quantum.custom "Hadamard"() %out_qubits_121 : !quantum.bit
    %out_qubits_123 = quantum.custom "RZ"(%cst_6) %out_qubits_122 : !quantum.bit
    %out_qubits_124 = quantum.custom "Hadamard"() %out_qubits_123 : !quantum.bit
    %out_qubits_125 = quantum.custom "RZ"(%cst_5) %out_qubits_124 : !quantum.bit
    %out_qubits_126 = quantum.custom "Hadamard"() %out_qubits_103#1 : !quantum.bit
    %out_qubits_127:2 = quantum.custom "CZ"() %out_qubits_126, %out_qubits_112#1 : !quantum.bit, !quantum.bit
    %out_qubits_128:2 = quantum.custom "CZ"() %out_qubits_127#0, %out_qubits_120#1 : !quantum.bit, !quantum.bit
    %out_qubits_129 = quantum.custom "RZ"(%cst_31) %out_qubits_128#0 : !quantum.bit
    %out_qubits_130 = quantum.custom "Hadamard"() %out_qubits_129 : !quantum.bit
    %out_qubits_131 = quantum.custom "RZ"(%cst_4) %out_qubits_130 : !quantum.bit
    %out_qubits_132 = quantum.custom "Hadamard"() %out_qubits_131 : !quantum.bit
    %out_qubits_133 = quantum.custom "RZ"(%cst_3) %out_qubits_132 : !quantum.bit
    %out_qubits_134 = quantum.custom "Hadamard"() %out_qubits_127#1 : !quantum.bit
    %out_qubits_135:2 = quantum.custom "CZ"() %out_qubits_134, %out_qubits_128#1 : !quantum.bit, !quantum.bit
    %out_qubits_136 = quantum.custom "RZ"(%cst_31) %out_qubits_135#0 : !quantum.bit
    %out_qubits_137 = quantum.custom "Hadamard"() %out_qubits_136 : !quantum.bit
    %out_qubits_138 = quantum.custom "RZ"(%cst_2) %out_qubits_137 : !quantum.bit
    %out_qubits_139 = quantum.custom "Hadamard"() %out_qubits_138 : !quantum.bit
    %out_qubits_140 = quantum.custom "RZ"(%cst_1) %out_qubits_139 : !quantum.bit
    %out_qubits_141 = quantum.custom "Hadamard"() %out_qubits_135#1 : !quantum.bit
    %out_qubits_142 = quantum.custom "RZ"(%cst_31) %out_qubits_141 : !quantum.bit
    %out_qubits_143 = quantum.custom "Hadamard"() %out_qubits_142 : !quantum.bit
    %out_qubits_144 = quantum.custom "RZ"(%cst_0) %out_qubits_143 : !quantum.bit
    %out_qubits_145 = quantum.custom "Hadamard"() %out_qubits_144 : !quantum.bit
    %out_qubits_146 = quantum.custom "RZ"(%cst) %out_qubits_145 : !quantum.bit
    %5 = quantum.compbasis qubits %out_qubits_125, %out_qubits_133, %out_qubits_140, %out_qubits_146 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_125 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_133 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_140 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_146 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}