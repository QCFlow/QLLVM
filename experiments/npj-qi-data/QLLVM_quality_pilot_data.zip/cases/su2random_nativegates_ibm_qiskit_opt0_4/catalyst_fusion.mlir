module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -78.539816339744831 : f64
    %cst_0 = arith.constant 12.702383684221132 : f64
    %cst_1 = arith.constant 1.4882463142149869 : f64
    %cst_2 = arith.constant -4.4408920985006262E-16 : f64
    %cst_3 = arith.constant 14.484144520109066 : f64
    %cst_4 = arith.constant 2.4016409048004452 : f64
    %cst_5 = arith.constant 16.342809735433203 : f64
    %cst_6 = arith.constant 2.7269903460220899 : f64
    %cst_7 = arith.constant 1.3322676295501878E-15 : f64
    %cst_8 = arith.constant 16.652936631701976 : f64
    %cst_9 = arith.constant 2.7761197097590848 : f64
    %cst_10 = arith.constant -1.3034821788032986 : f64
    %cst_11 = arith.constant -0.19844947426043857 : f64
    %cst_12 = arith.constant 1.469337614784102 : f64
    %cst_13 = arith.constant 4.2458153961831133 : f64
    %cst_14 = arith.constant 0.38556515253423118 : f64
    %cst_15 = arith.constant 1.2178932216832916 : f64
    %cst_16 = arith.constant -0.8654084752505975 : f64
    %cst_17 = arith.constant 4.3795342510229842 : f64
    %cst_18 = arith.constant 0.92067176535287698 : f64
    %cst_19 = arith.constant -1.3645149899443199 : f64
    %cst_20 = arith.constant -4.7123889803846897 : f64
    %cst_21 = arith.constant 1.748262901313365 : f64
    %cst_22 = arith.constant -1.5459886378145122 : f64
    %cst_23 = arith.constant 1.1362285313102694 : f64
    %cst_24 = arith.constant 2.3860979345585163 : f64
    %cst_25 = arith.constant 4.3865538120731671 : f64
    %cst_26 = arith.constant -2.0065777585276985 : f64
    %cst_27 = arith.constant 1.9307139563910078 : f64
    %cst_28 = arith.constant 1.408247179633169 : f64
    %cst_29 = arith.constant 0.047420182428843827 : f64
    %cst_30 = arith.constant 2.124034179176205 : f64
    %cst_31 = arith.constant -6.1931142791420459 : f64
    %cst_32 = arith.constant 0.000000e+00 : f64
    %cst_33 = arith.constant 3.1415926535897931 : f64
    %cst_34 = arith.constant -1.5707963267948966 : f64
    %cst_35 = arith.constant 1.0625547235745714 : f64
    %cst_36 = arith.constant 4.703008262020524 : f64
    %cst_37 = arith.constant -1.5783282351455903 : f64
    %cst_38 = arith.constant 1.636960871640498 : f64
    %cst_39 = arith.constant 1.5702983356565812 : f64
    %cst_40 = arith.constant 2.3288716671544507 : f64
    %cst_41 = arith.constant 1.8117753789782725 : f64
    %cst_42 = arith.constant -1.3485722292015896 : f64
    %cst_43 = arith.constant -0.12877496800404042 : f64
    %cst_44 = arith.constant 1.5502913406648151 : f64
    %cst_45 = arith.constant 4.5553537720167991 : f64
    %cst_46 = arith.constant 1.5707963267948966 : f64
    %cst_47 = arith.constant 1.4368347742816614 : f64
    %cst_48 = arith.constant -3.141592653589794 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_48, %cst_47, %cst_46) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_49 = quantum.custom "Rot"(%cst_45, %cst_44, %cst_43) %2 : !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_49 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_51 = quantum.custom "Rot"(%cst_42, %cst_41, %cst_40) %3 : !quantum.bit
    %out_qubits_52:2 = quantum.custom "CZ"() %out_qubits_50#0, %out_qubits_51 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_39, %cst_38, %cst_37) %4 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_52#0, %out_qubits_53 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_36, %cst_35, %cst_34) %out_qubits_54#0 : !quantum.bit
    %out_qubits_56 = quantum.custom "Rot"(%cst_33, %cst_46, %cst_32) %out_qubits_50#1 : !quantum.bit
    %out_qubits_57:2 = quantum.custom "CZ"() %out_qubits_56, %out_qubits_52#1 : !quantum.bit, !quantum.bit
    %out_qubits_58:2 = quantum.custom "CZ"() %out_qubits_57#0, %out_qubits_54#1 : !quantum.bit, !quantum.bit
    %out_qubits_59 = quantum.custom "Rot"(%cst_31, %cst_30, %cst_29) %out_qubits_58#0 : !quantum.bit
    %out_qubits_60:2 = quantum.custom "CZ"() %out_qubits_55, %out_qubits_59 : !quantum.bit, !quantum.bit
    %out_qubits_61 = quantum.custom "Rot"(%cst_33, %cst_46, %cst_32) %out_qubits_57#1 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_61, %out_qubits_58#1 : !quantum.bit, !quantum.bit
    %out_qubits_63 = quantum.custom "Rot"(%cst_28, %cst_27, %cst_26) %out_qubits_62#0 : !quantum.bit
    %out_qubits_64:2 = quantum.custom "CZ"() %out_qubits_60#0, %out_qubits_63 : !quantum.bit, !quantum.bit
    %out_qubits_65 = quantum.custom "Rot"(%cst_25, %cst_24, %cst_23) %out_qubits_62#1 : !quantum.bit
    %out_qubits_66:2 = quantum.custom "CZ"() %out_qubits_64#0, %out_qubits_65 : !quantum.bit, !quantum.bit
    %out_qubits_67 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_66#0 : !quantum.bit
    %out_qubits_68 = quantum.custom "Rot"(%cst_33, %cst_46, %cst_32) %out_qubits_60#1 : !quantum.bit
    %out_qubits_69:2 = quantum.custom "CZ"() %out_qubits_68, %out_qubits_64#1 : !quantum.bit, !quantum.bit
    %out_qubits_70:2 = quantum.custom "CZ"() %out_qubits_69#0, %out_qubits_66#1 : !quantum.bit, !quantum.bit
    %out_qubits_71 = quantum.custom "Rot"(%cst_19, %cst_18, %cst_17) %out_qubits_70#0 : !quantum.bit
    %out_qubits_72:2 = quantum.custom "CZ"() %out_qubits_67, %out_qubits_71 : !quantum.bit, !quantum.bit
    %out_qubits_73 = quantum.custom "Rot"(%cst_33, %cst_46, %cst_32) %out_qubits_69#1 : !quantum.bit
    %out_qubits_74:2 = quantum.custom "CZ"() %out_qubits_73, %out_qubits_70#1 : !quantum.bit, !quantum.bit
    %out_qubits_75 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_74#0 : !quantum.bit
    %out_qubits_76:2 = quantum.custom "CZ"() %out_qubits_72#0, %out_qubits_75 : !quantum.bit, !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_74#1 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_76#0, %out_qubits_77 : !quantum.bit, !quantum.bit
    %out_qubits_79 = quantum.custom "Rot"(%cst_10, %cst_9, %cst_8) %out_qubits_78#0 : !quantum.bit
    %out_qubits_80 = quantum.custom "Rot"(%cst_33, %cst_46, %cst_32) %out_qubits_72#1 : !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_80, %out_qubits_76#1 : !quantum.bit, !quantum.bit
    %out_qubits_82:2 = quantum.custom "CZ"() %out_qubits_81#0, %out_qubits_78#1 : !quantum.bit, !quantum.bit
    %out_qubits_83 = quantum.custom "Rot"(%cst_7, %cst_6, %cst_5) %out_qubits_82#0 : !quantum.bit
    %out_qubits_84 = quantum.custom "Rot"(%cst_33, %cst_46, %cst_32) %out_qubits_81#1 : !quantum.bit
    %out_qubits_85:2 = quantum.custom "CZ"() %out_qubits_84, %out_qubits_82#1 : !quantum.bit, !quantum.bit
    %out_qubits_86 = quantum.custom "Rot"(%cst_48, %cst_4, %cst_3) %out_qubits_85#0 : !quantum.bit
    %out_qubits_87 = quantum.custom "Rot"(%cst_2, %cst_1, %cst_0) %out_qubits_85#1 : !quantum.bit
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_79, %out_qubits_83, %out_qubits_86, %out_qubits_87 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_79 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_83 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_86 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_87 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}