module @circuit {
  func.func public @jit_circuit() -> tensor<128x6xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x6xi64>
    return %0 : tensor<128x6xi64>
  }
  func.func public @circuit_0() -> tensor<128x6xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -131.94689145077115 : f64
    %cst_0 = arith.constant 4.6633015951723493 : f64
    %cst_1 = arith.constant 3.9269908169872414 : f64
    %cst_2 = arith.constant 4.614214209960009 : f64
    %cst_3 = arith.constant 4.3196898986859651 : f64
    %cst_4 = arith.constant 4.5160394395353274 : f64
    %cst_5 = arith.constant 0.049087385212338089 : f64
    %cst_6 = arith.constant 0.098174770424680535 : f64
    %cst_7 = arith.constant 0.098174770424685059 : f64
    %cst_8 = arith.constant 1.570796326794897 : f64
    %cst_9 = arith.constant 0.19634954084936121 : f64
    %cst_10 = arith.constant -1.5707963267948966 : f64
    %cst_11 = arith.constant 0.3926990816987232 : f64
    %cst_12 = arith.constant 0.39269908169872436 : f64
    %cst_13 = arith.constant -1.5707963267948963 : f64
    %cst_14 = arith.constant 0.78539816339744783 : f64
    %cst_15 = arith.constant -4.7123889803846897 : f64
    %cst_16 = arith.constant 0.78539816339744839 : f64
    %cst_17 = arith.constant 4.7123889803846897 : f64
    %cst_18 = arith.constant 0.000000e+00 : f64
    %cst_19 = arith.constant 1.5707963267948966 : f64
    %cst_20 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %1 : !quantum.bit
    %2 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_21 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %2 : !quantum.bit
    %out_qubits_22:2 = quantum.custom "CZ"() %out_qubits_21, %out_qubits : !quantum.bit, !quantum.bit
    %out_qubits_23 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_19) %out_qubits_22#1 : !quantum.bit
    %out_qubits_24:2 = quantum.custom "CZ"() %out_qubits_22#0, %out_qubits_23 : !quantum.bit, !quantum.bit
    %out_qubits_25 = quantum.custom "Rot"(%cst_15, %cst_14, %cst_13) %out_qubits_24#1 : !quantum.bit
    %3 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_26 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %3 : !quantum.bit
    %out_qubits_27:2 = quantum.custom "CZ"() %out_qubits_24#0, %out_qubits_26 : !quantum.bit, !quantum.bit
    %out_qubits_28 = quantum.custom "Rot"(%cst_17, %cst_12, %cst_19) %out_qubits_27#1 : !quantum.bit
    %out_qubits_29:2 = quantum.custom "CZ"() %out_qubits_27#0, %out_qubits_28 : !quantum.bit, !quantum.bit
    %out_qubits_30 = quantum.custom "Rot"(%cst_15, %cst_11, %cst_10) %out_qubits_29#1 : !quantum.bit
    %out_qubits_31:2 = quantum.custom "CZ"() %out_qubits_25, %out_qubits_30 : !quantum.bit, !quantum.bit
    %out_qubits_32 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_19) %out_qubits_31#1 : !quantum.bit
    %out_qubits_33:2 = quantum.custom "CZ"() %out_qubits_31#0, %out_qubits_32 : !quantum.bit, !quantum.bit
    %out_qubits_34 = quantum.custom "Rot"(%cst_15, %cst_14, %cst_13) %out_qubits_33#1 : !quantum.bit
    %4 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_35 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %4 : !quantum.bit
    %out_qubits_36:2 = quantum.custom "CZ"() %out_qubits_29#0, %out_qubits_35 : !quantum.bit, !quantum.bit
    %out_qubits_37 = quantum.custom "Rot"(%cst_17, %cst_9, %cst_8) %out_qubits_36#1 : !quantum.bit
    %out_qubits_38:2 = quantum.custom "CZ"() %out_qubits_36#0, %out_qubits_37 : !quantum.bit, !quantum.bit
    %out_qubits_39 = quantum.custom "Rot"(%cst_19, %cst_9, %cst_17) %out_qubits_38#1 : !quantum.bit
    %out_qubits_40:2 = quantum.custom "CZ"() %out_qubits_33#0, %out_qubits_39 : !quantum.bit, !quantum.bit
    %out_qubits_41 = quantum.custom "Rot"(%cst_17, %cst_12, %cst_19) %out_qubits_40#1 : !quantum.bit
    %out_qubits_42:2 = quantum.custom "CZ"() %out_qubits_40#0, %out_qubits_41 : !quantum.bit, !quantum.bit
    %out_qubits_43 = quantum.custom "Rot"(%cst_15, %cst_11, %cst_10) %out_qubits_42#1 : !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_34, %out_qubits_43 : !quantum.bit, !quantum.bit
    %out_qubits_45 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_19) %out_qubits_44#1 : !quantum.bit
    %out_qubits_46:2 = quantum.custom "CZ"() %out_qubits_44#0, %out_qubits_45 : !quantum.bit, !quantum.bit
    %5 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_47 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %5 : !quantum.bit
    %out_qubits_48:2 = quantum.custom "CZ"() %out_qubits_38#0, %out_qubits_47 : !quantum.bit, !quantum.bit
    %out_qubits_49 = quantum.custom "Rot"(%cst_10, %cst_7, %cst_15) %out_qubits_48#1 : !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits_48#0, %out_qubits_49 : !quantum.bit, !quantum.bit
    %out_qubits_51 = quantum.custom "Rot"(%cst_19, %cst_6, %cst_17) %out_qubits_50#1 : !quantum.bit
    %out_qubits_52:2 = quantum.custom "CZ"() %out_qubits_42#0, %out_qubits_51 : !quantum.bit, !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_17, %cst_9, %cst_8) %out_qubits_52#1 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_52#0, %out_qubits_53 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_19, %cst_9, %cst_17) %out_qubits_54#1 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_46#0, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_17, %cst_12, %cst_19) %out_qubits_56#1 : !quantum.bit
    %out_qubits_58:2 = quantum.custom "CZ"() %out_qubits_56#0, %out_qubits_57 : !quantum.bit, !quantum.bit
    %6 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits_59 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %6 : !quantum.bit
    %out_qubits_60:2 = quantum.custom "CZ"() %out_qubits_50#0, %out_qubits_59 : !quantum.bit, !quantum.bit
    %out_qubits_61 = quantum.custom "Rot"(%cst_17, %cst_5, %cst_19) %out_qubits_60#1 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_60#0, %out_qubits_61 : !quantum.bit, !quantum.bit
    %out_qubits_63 = quantum.custom "Rot"(%cst_19, %cst_5, %cst_17) %out_qubits_62#1 : !quantum.bit
    %out_qubits_64:2 = quantum.custom "CZ"() %out_qubits_54#0, %out_qubits_63 : !quantum.bit, !quantum.bit
    %out_qubits_65 = quantum.custom "Rot"(%cst_10, %cst_7, %cst_15) %out_qubits_64#1 : !quantum.bit
    %out_qubits_66:2 = quantum.custom "CZ"() %out_qubits_64#0, %out_qubits_65 : !quantum.bit, !quantum.bit
    %out_qubits_67 = quantum.custom "Rot"(%cst_19, %cst_6, %cst_17) %out_qubits_66#1 : !quantum.bit
    %out_qubits_68:2 = quantum.custom "CZ"() %out_qubits_58#0, %out_qubits_67 : !quantum.bit, !quantum.bit
    %out_qubits_69 = quantum.custom "Rot"(%cst_17, %cst_9, %cst_8) %out_qubits_68#1 : !quantum.bit
    %out_qubits_70:2 = quantum.custom "CZ"() %out_qubits_68#0, %out_qubits_69 : !quantum.bit, !quantum.bit
    %out_qubits_71 = quantum.custom "Rot"(%cst_4, %cst_19, %cst_18) %out_qubits_70#0 : !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_15, %cst_14, %cst_13) %out_qubits_46#1 : !quantum.bit
    %out_qubits_73 = quantum.custom "Rot"(%cst_15, %cst_11, %cst_10) %out_qubits_58#1 : !quantum.bit
    %out_qubits_74:2 = quantum.custom "CZ"() %out_qubits_72, %out_qubits_73 : !quantum.bit, !quantum.bit
    %out_qubits_75 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_19) %out_qubits_74#1 : !quantum.bit
    %out_qubits_76:2 = quantum.custom "CZ"() %out_qubits_74#0, %out_qubits_75 : !quantum.bit, !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_19, %cst_9, %cst_17) %out_qubits_70#1 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_76#0, %out_qubits_77 : !quantum.bit, !quantum.bit
    %out_qubits_79 = quantum.custom "Rot"(%cst_17, %cst_12, %cst_19) %out_qubits_78#1 : !quantum.bit
    %out_qubits_80:2 = quantum.custom "CZ"() %out_qubits_78#0, %out_qubits_79 : !quantum.bit, !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_80#0, %out_qubits_71 : !quantum.bit, !quantum.bit
    %out_qubits_82 = quantum.custom "Rot"(%cst_3, %cst_19, %cst_18) %out_qubits_81#0 : !quantum.bit
    %out_qubits_83 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_81#1 : !quantum.bit
    %out_qubits_84:2 = quantum.custom "CZ"() %out_qubits_83, %out_qubits_82 : !quantum.bit, !quantum.bit
    %out_qubits_85 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_84#1 : !quantum.bit
    %out_qubits_86 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_84#0 : !quantum.bit
    %out_qubits_87:2 = quantum.custom "CZ"() %out_qubits_85, %out_qubits_86 : !quantum.bit, !quantum.bit
    %out_qubits_88 = quantum.custom "Hadamard"() %out_qubits_87#1 : !quantum.bit
    %out_qubits_89 = quantum.custom "Rot"(%cst_2, %cst_19, %cst_18) %out_qubits_66#0 : !quantum.bit
    %out_qubits_90 = quantum.custom "Rot"(%cst_15, %cst_14, %cst_13) %out_qubits_76#1 : !quantum.bit
    %out_qubits_91 = quantum.custom "Rot"(%cst_15, %cst_11, %cst_10) %out_qubits_80#1 : !quantum.bit
    %out_qubits_92:2 = quantum.custom "CZ"() %out_qubits_90, %out_qubits_91 : !quantum.bit, !quantum.bit
    %out_qubits_93 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_19) %out_qubits_92#1 : !quantum.bit
    %out_qubits_94:2 = quantum.custom "CZ"() %out_qubits_92#0, %out_qubits_93 : !quantum.bit, !quantum.bit
    %out_qubits_95:2 = quantum.custom "CZ"() %out_qubits_94#0, %out_qubits_89 : !quantum.bit, !quantum.bit
    %out_qubits_96 = quantum.custom "Rot"(%cst_1, %cst_19, %cst_18) %out_qubits_95#0 : !quantum.bit
    %out_qubits_97 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_95#1 : !quantum.bit
    %out_qubits_98:2 = quantum.custom "CZ"() %out_qubits_97, %out_qubits_96 : !quantum.bit, !quantum.bit
    %out_qubits_99 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_98#1 : !quantum.bit
    %out_qubits_100 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_98#0 : !quantum.bit
    %out_qubits_101:2 = quantum.custom "CZ"() %out_qubits_99, %out_qubits_100 : !quantum.bit, !quantum.bit
    %out_qubits_102 = quantum.custom "Hadamard"() %out_qubits_101#1 : !quantum.bit
    %out_qubits_103 = quantum.custom "Rot"(%cst_0, %cst_19, %cst_18) %out_qubits_62#0 : !quantum.bit
    %out_qubits_104 = quantum.custom "Rot"(%cst_15, %cst_14, %cst_13) %out_qubits_94#1 : !quantum.bit
    %out_qubits_105:2 = quantum.custom "CZ"() %out_qubits_104, %out_qubits_103 : !quantum.bit, !quantum.bit
    %out_qubits_106 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_105#0 : !quantum.bit
    %out_qubits_107 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_105#1 : !quantum.bit
    %out_qubits_108:2 = quantum.custom "CZ"() %out_qubits_107, %out_qubits_106 : !quantum.bit, !quantum.bit
    %out_qubits_109 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_108#1 : !quantum.bit
    %out_qubits_110 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_18) %out_qubits_108#0 : !quantum.bit
    %out_qubits_111:2 = quantum.custom "CZ"() %out_qubits_109, %out_qubits_110 : !quantum.bit, !quantum.bit
    %out_qubits_112 = quantum.custom "Hadamard"() %out_qubits_111#1 : !quantum.bit
    quantum.gphase(%cst)
    quantum.gphase(%cst_15)
    %7 = quantum.compbasis qubits %out_qubits_111#0, %out_qubits_101#0, %out_qubits_87#0, %out_qubits_88, %out_qubits_102, %out_qubits_112 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x6xf64>
    %9 = stablehlo.convert %8 : (tensor<128x6xf64>) -> tensor<128x6xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_111#0 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_101#0 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_87#0 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_88 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_102 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_112 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x6xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}