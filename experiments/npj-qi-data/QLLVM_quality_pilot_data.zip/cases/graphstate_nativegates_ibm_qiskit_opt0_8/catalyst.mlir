module @circuit {
  func.func public @jit_circuit() -> tensor<128x8xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x8xi64>
    return %0 : tensor<128x8xi64>
  }
  func.func public @circuit_0() -> tensor<128x8xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 0.000000e+00 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 8) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst) %1 : !quantum.bit
    %out_qubits_0 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_1 = quantum.custom "RZ"(%cst) %out_qubits_0 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_2 = quantum.custom "RZ"(%cst) %2 : !quantum.bit
    %out_qubits_3 = quantum.custom "Hadamard"() %out_qubits_2 : !quantum.bit
    %out_qubits_4 = quantum.custom "RZ"(%cst) %out_qubits_3 : !quantum.bit
    %out_qubits_5 = quantum.custom "Hadamard"() %out_qubits_4 : !quantum.bit
    %out_qubits_6 = quantum.custom "RZ"(%cst) %out_qubits_5 : !quantum.bit
    %out_qubits_7 = quantum.custom "Hadamard"() %out_qubits_6 : !quantum.bit
    %out_qubits_8:2 = quantum.custom "CZ"() %out_qubits_1, %out_qubits_7 : !quantum.bit, !quantum.bit
    %out_qubits_9 = quantum.custom "Hadamard"() %out_qubits_8#1 : !quantum.bit
    %out_qubits_10 = quantum.custom "RZ"(%cst) %out_qubits_9 : !quantum.bit
    %out_qubits_11 = quantum.custom "Hadamard"() %out_qubits_10 : !quantum.bit
    %out_qubits_12 = quantum.custom "RZ"(%cst) %out_qubits_11 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_13 = quantum.custom "RZ"(%cst) %3 : !quantum.bit
    %out_qubits_14 = quantum.custom "Hadamard"() %out_qubits_13 : !quantum.bit
    %out_qubits_15 = quantum.custom "RZ"(%cst) %out_qubits_14 : !quantum.bit
    %out_qubits_16 = quantum.custom "Hadamard"() %out_qubits_15 : !quantum.bit
    %out_qubits_17 = quantum.custom "RZ"(%cst) %out_qubits_16 : !quantum.bit
    %out_qubits_18 = quantum.custom "Hadamard"() %out_qubits_17 : !quantum.bit
    %out_qubits_19:2 = quantum.custom "CZ"() %out_qubits_8#0, %out_qubits_18 : !quantum.bit, !quantum.bit
    %out_qubits_20 = quantum.custom "Hadamard"() %out_qubits_19#1 : !quantum.bit
    %out_qubits_21 = quantum.custom "RZ"(%cst) %out_qubits_20 : !quantum.bit
    %out_qubits_22 = quantum.custom "Hadamard"() %out_qubits_21 : !quantum.bit
    %out_qubits_23 = quantum.custom "RZ"(%cst) %out_qubits_22 : !quantum.bit
    %out_qubits_24 = quantum.custom "Hadamard"() %out_qubits_23 : !quantum.bit
    %out_qubits_25 = quantum.custom "RZ"(%cst) %out_qubits_24 : !quantum.bit
    %out_qubits_26 = quantum.custom "Hadamard"() %out_qubits_25 : !quantum.bit
    %out_qubits_27:2 = quantum.custom "CZ"() %out_qubits_12, %out_qubits_26 : !quantum.bit, !quantum.bit
    %out_qubits_28 = quantum.custom "Hadamard"() %out_qubits_27#1 : !quantum.bit
    %out_qubits_29 = quantum.custom "RZ"(%cst) %out_qubits_28 : !quantum.bit
    %out_qubits_30 = quantum.custom "Hadamard"() %out_qubits_29 : !quantum.bit
    %out_qubits_31 = quantum.custom "RZ"(%cst) %out_qubits_30 : !quantum.bit
    %4 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_32 = quantum.custom "RZ"(%cst) %4 : !quantum.bit
    %out_qubits_33 = quantum.custom "Hadamard"() %out_qubits_32 : !quantum.bit
    %out_qubits_34 = quantum.custom "RZ"(%cst) %out_qubits_33 : !quantum.bit
    %5 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_35 = quantum.custom "RZ"(%cst) %5 : !quantum.bit
    %out_qubits_36 = quantum.custom "Hadamard"() %out_qubits_35 : !quantum.bit
    %out_qubits_37 = quantum.custom "RZ"(%cst) %out_qubits_36 : !quantum.bit
    %6 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_38 = quantum.custom "RZ"(%cst) %6 : !quantum.bit
    %out_qubits_39 = quantum.custom "Hadamard"() %out_qubits_38 : !quantum.bit
    %out_qubits_40 = quantum.custom "RZ"(%cst) %out_qubits_39 : !quantum.bit
    %out_qubits_41 = quantum.custom "Hadamard"() %out_qubits_40 : !quantum.bit
    %out_qubits_42 = quantum.custom "RZ"(%cst) %out_qubits_41 : !quantum.bit
    %out_qubits_43 = quantum.custom "Hadamard"() %out_qubits_42 : !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_37, %out_qubits_43 : !quantum.bit, !quantum.bit
    %out_qubits_45 = quantum.custom "Hadamard"() %out_qubits_44#1 : !quantum.bit
    %out_qubits_46 = quantum.custom "RZ"(%cst) %out_qubits_45 : !quantum.bit
    %out_qubits_47 = quantum.custom "Hadamard"() %out_qubits_46 : !quantum.bit
    %out_qubits_48 = quantum.custom "RZ"(%cst) %out_qubits_47 : !quantum.bit
    %7 = quantum.extract %0[ 6] : !quantum.reg -> !quantum.bit
    %out_qubits_49 = quantum.custom "RZ"(%cst) %7 : !quantum.bit
    %out_qubits_50 = quantum.custom "Hadamard"() %out_qubits_49 : !quantum.bit
    %out_qubits_51 = quantum.custom "RZ"(%cst) %out_qubits_50 : !quantum.bit
    %out_qubits_52 = quantum.custom "Hadamard"() %out_qubits_51 : !quantum.bit
    %out_qubits_53 = quantum.custom "RZ"(%cst) %out_qubits_52 : !quantum.bit
    %out_qubits_54 = quantum.custom "Hadamard"() %out_qubits_53 : !quantum.bit
    %out_qubits_55:2 = quantum.custom "CZ"() %out_qubits_48, %out_qubits_54 : !quantum.bit, !quantum.bit
    %out_qubits_56 = quantum.custom "Hadamard"() %out_qubits_55#1 : !quantum.bit
    %out_qubits_57 = quantum.custom "RZ"(%cst) %out_qubits_56 : !quantum.bit
    %out_qubits_58 = quantum.custom "Hadamard"() %out_qubits_57 : !quantum.bit
    %out_qubits_59 = quantum.custom "RZ"(%cst) %out_qubits_58 : !quantum.bit
    %out_qubits_60 = quantum.custom "Hadamard"() %out_qubits_59 : !quantum.bit
    %out_qubits_61 = quantum.custom "RZ"(%cst) %out_qubits_60 : !quantum.bit
    %out_qubits_62 = quantum.custom "Hadamard"() %out_qubits_61 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_34, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Hadamard"() %out_qubits_63#1 : !quantum.bit
    %out_qubits_65 = quantum.custom "RZ"(%cst) %out_qubits_64 : !quantum.bit
    %out_qubits_66 = quantum.custom "Hadamard"() %out_qubits_65 : !quantum.bit
    %out_qubits_67 = quantum.custom "RZ"(%cst) %out_qubits_66 : !quantum.bit
    %8 = quantum.extract %0[ 7] : !quantum.reg -> !quantum.bit
    %out_qubits_68 = quantum.custom "RZ"(%cst) %8 : !quantum.bit
    %out_qubits_69 = quantum.custom "Hadamard"() %out_qubits_68 : !quantum.bit
    %out_qubits_70 = quantum.custom "RZ"(%cst) %out_qubits_69 : !quantum.bit
    %out_qubits_71 = quantum.custom "Hadamard"() %out_qubits_70 : !quantum.bit
    %out_qubits_72 = quantum.custom "RZ"(%cst) %out_qubits_71 : !quantum.bit
    %out_qubits_73 = quantum.custom "Hadamard"() %out_qubits_72 : !quantum.bit
    %out_qubits_74:2 = quantum.custom "CZ"() %out_qubits_44#0, %out_qubits_73 : !quantum.bit, !quantum.bit
    %out_qubits_75 = quantum.custom "Hadamard"() %out_qubits_74#1 : !quantum.bit
    %out_qubits_76 = quantum.custom "RZ"(%cst) %out_qubits_75 : !quantum.bit
    %out_qubits_77 = quantum.custom "Hadamard"() %out_qubits_76 : !quantum.bit
    %out_qubits_78 = quantum.custom "RZ"(%cst) %out_qubits_77 : !quantum.bit
    %out_qubits_79 = quantum.custom "Hadamard"() %out_qubits_78 : !quantum.bit
    %out_qubits_80 = quantum.custom "RZ"(%cst) %out_qubits_79 : !quantum.bit
    %out_qubits_81 = quantum.custom "Hadamard"() %out_qubits_80 : !quantum.bit
    %out_qubits_82:2 = quantum.custom "CZ"() %out_qubits_63#0, %out_qubits_81 : !quantum.bit, !quantum.bit
    %out_qubits_83 = quantum.custom "Hadamard"() %out_qubits_82#1 : !quantum.bit
    %out_qubits_84 = quantum.custom "RZ"(%cst) %out_qubits_83 : !quantum.bit
    %out_qubits_85 = quantum.custom "Hadamard"() %out_qubits_84 : !quantum.bit
    %out_qubits_86 = quantum.custom "RZ"(%cst) %out_qubits_85 : !quantum.bit
    %9 = quantum.compbasis qubits %out_qubits_19#0, %out_qubits_27#0, %out_qubits_31, %out_qubits_74#0, %out_qubits_55#0, %out_qubits_82#0, %out_qubits_67, %out_qubits_86 : !quantum.obs
    %10 = quantum.sample %9 : tensor<128x8xf64>
    %11 = stablehlo.convert %10 : (tensor<128x8xf64>) -> tensor<128x8xi64>
    %12 = quantum.insert %0[ 0], %out_qubits_19#0 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 1], %out_qubits_27#0 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 2], %out_qubits_31 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 3], %out_qubits_74#0 : !quantum.reg, !quantum.bit
    %16 = quantum.insert %15[ 4], %out_qubits_55#0 : !quantum.reg, !quantum.bit
    %17 = quantum.insert %16[ 5], %out_qubits_82#0 : !quantum.reg, !quantum.bit
    %18 = quantum.insert %17[ 6], %out_qubits_67 : !quantum.reg, !quantum.bit
    %19 = quantum.insert %18[ 7], %out_qubits_86 : !quantum.reg, !quantum.bit
    quantum.dealloc %19 : !quantum.reg
    quantum.device_release
    return %11 : tensor<128x8xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}