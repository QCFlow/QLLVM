module @circuit {
  func.func public @jit_circuit() -> tensor<128x6xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x6xi64>
    return %0 : tensor<128x6xi64>
  }
  func.func public @circuit_0() -> tensor<128x6xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -358.14156250923548 : f64
    %cst_0 = arith.constant 2.3238980791090578 : f64
    %cst_1 = arith.constant 1.8857914349828353 : f64
    %cst_2 = arith.constant 12.566370614359172 : f64
    %cst_3 = arith.constant 0.24285628308942403 : f64
    %cst_4 = arith.constant 0.22078732784470267 : f64
    %cst_5 = arith.constant -3.141592653589794 : f64
    %cst_6 = arith.constant 9.4247779607693793 : f64
    %cst_7 = arith.constant 0.88546721445894361 : f64
    %cst_8 = arith.constant 0.5165405936775348 : f64
    %cst_9 = arith.constant 2.9386970794733358 : f64
    %cst_10 = arith.constant 2.2204460492503131E-16 : f64
    %cst_11 = arith.constant 0.32894831447101225 : f64
    %cst_12 = arith.constant 6.2831853071795853 : f64
    %cst_13 = arith.constant 0.71776190813591634 : f64
    %cst_14 = arith.constant 2.5298036701820763 : f64
    %cst_15 = arith.constant 6.2831853071795862 : f64
    %cst_16 = arith.constant 0.98587975949392059 : f64
    %cst_17 = arith.constant -1.5707963267948961 : f64
    %cst_18 = arith.constant 2.0796663812185208 : f64
    %cst_19 = arith.constant 0.3996323416401647 : f64
    %cst_20 = arith.constant 3.1415926535897909 : f64
    %cst_21 = arith.constant 4.2547201282710887 : f64
    %cst_22 = arith.constant 8.8817841970012523E-16 : f64
    %cst_23 = arith.constant 1.6102190012230528 : f64
    %cst_24 = arith.constant 1.1066323418363253 : f64
    %cst_25 = arith.constant -3.1415926535897927 : f64
    %cst_26 = arith.constant 2.4158125689295411 : f64
    %cst_27 = arith.constant -1.5707963267948968 : f64
    %cst_28 = arith.constant 0.000000e+00 : f64
    %cst_29 = arith.constant 4.7123889803846897 : f64
    %cst_30 = arith.constant -1.5707963267948963 : f64
    %cst_31 = arith.constant 1.2207640464119656 : f64
    %cst_32 = arith.constant 1.5707963267948963 : f64
    %cst_33 = arith.constant 2.288346576773812 : f64
    %cst_34 = arith.constant -3.1415926535897936 : f64
    %cst_35 = arith.constant 0.61887884853166497 : f64
    %cst_36 = arith.constant 2.1671831681143443 : f64
    %cst_37 = arith.constant -3.1415926535897931 : f64
    %cst_38 = arith.constant 3.1415926535897927 : f64
    %cst_39 = arith.constant 1.2368643640668651 : f64
    %cst_40 = arith.constant 3.1415926535897936 : f64
    %cst_41 = arith.constant 0.44351773122959381 : f64
    %cst_42 = arith.constant 3.1415926535897922 : f64
    %cst_43 = arith.constant 1.5707963267948966 : f64
    %cst_44 = arith.constant 0.096529414223379836 : f64
    %cst_45 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_45, %cst_44, %cst_43) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_46 = quantum.custom "Rot"(%cst_42, %cst_41, %cst_45) %2 : !quantum.bit
    %out_qubits_47:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_46 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_48 = quantum.custom "Rot"(%cst_40, %cst_39, %cst_38) %3 : !quantum.bit
    %out_qubits_49:2 = quantum.custom "CZ"() %out_qubits_47#0, %out_qubits_48 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_50 = quantum.custom "Rot"(%cst_37, %cst_36, %cst_45) %4 : !quantum.bit
    %out_qubits_51:2 = quantum.custom "CZ"() %out_qubits_49#0, %out_qubits_50 : !quantum.bit, !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_38, %cst_35, %cst_34) %5 : !quantum.bit
    %out_qubits_53:2 = quantum.custom "CZ"() %out_qubits_51#0, %out_qubits_52 : !quantum.bit, !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_54 = quantum.custom "Rot"(%cst_34, %cst_33, %cst_38) %6 : !quantum.bit
    %out_qubits_55:2 = quantum.custom "CZ"() %out_qubits_53#0, %out_qubits_54 : !quantum.bit, !quantum.bit
    %out_qubits_56 = quantum.custom "Rot"(%cst_32, %cst_31, %cst_30) %out_qubits_55#0 : !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_47#1 : !quantum.bit
    %out_qubits_58 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_49#1 : !quantum.bit
    %out_qubits_59:2 = quantum.custom "CZ"() %out_qubits_57, %out_qubits_58 : !quantum.bit, !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_51#1 : !quantum.bit
    %out_qubits_61:2 = quantum.custom "CZ"() %out_qubits_59#0, %out_qubits_60 : !quantum.bit, !quantum.bit
    %out_qubits_62 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_53#1 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_61#0, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_55#1 : !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_63#0, %out_qubits_64 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "Rot"(%cst_34, %cst_26, %cst_38) %out_qubits_65#0 : !quantum.bit
    %out_qubits_67:2 = quantum.custom "CZ"() %out_qubits_56, %out_qubits_66 : !quantum.bit, !quantum.bit
    %out_qubits_68 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_59#1 : !quantum.bit
    %out_qubits_69 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_61#1 : !quantum.bit
    %out_qubits_70:2 = quantum.custom "CZ"() %out_qubits_68, %out_qubits_69 : !quantum.bit, !quantum.bit
    %out_qubits_71 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_63#1 : !quantum.bit
    %out_qubits_72:2 = quantum.custom "CZ"() %out_qubits_70#0, %out_qubits_71 : !quantum.bit, !quantum.bit
    %out_qubits_73 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_65#1 : !quantum.bit
    %out_qubits_74:2 = quantum.custom "CZ"() %out_qubits_72#0, %out_qubits_73 : !quantum.bit, !quantum.bit
    %out_qubits_75 = quantum.custom "Rot"(%cst_25, %cst_24, %cst_38) %out_qubits_74#0 : !quantum.bit
    %out_qubits_76:2 = quantum.custom "CZ"() %out_qubits_67#0, %out_qubits_75 : !quantum.bit, !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_70#1 : !quantum.bit
    %out_qubits_78 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_72#1 : !quantum.bit
    %out_qubits_79:2 = quantum.custom "CZ"() %out_qubits_77, %out_qubits_78 : !quantum.bit, !quantum.bit
    %out_qubits_80 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_74#1 : !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_79#0, %out_qubits_80 : !quantum.bit, !quantum.bit
    %out_qubits_82 = quantum.custom "Rot"(%cst_25, %cst_23, %cst_38) %out_qubits_81#0 : !quantum.bit
    %out_qubits_83:2 = quantum.custom "CZ"() %out_qubits_76#0, %out_qubits_82 : !quantum.bit, !quantum.bit
    %out_qubits_84 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_79#1 : !quantum.bit
    %out_qubits_85 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_81#1 : !quantum.bit
    %out_qubits_86:2 = quantum.custom "CZ"() %out_qubits_84, %out_qubits_85 : !quantum.bit, !quantum.bit
    %out_qubits_87 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_28) %out_qubits_86#0 : !quantum.bit
    %out_qubits_88:2 = quantum.custom "CZ"() %out_qubits_83#0, %out_qubits_87 : !quantum.bit, !quantum.bit
    %out_qubits_89 = quantum.custom "Rot"(%cst_20, %cst_19, %cst_38) %out_qubits_86#1 : !quantum.bit
    %out_qubits_90:2 = quantum.custom "CZ"() %out_qubits_88#0, %out_qubits_89 : !quantum.bit, !quantum.bit
    %out_qubits_91 = quantum.custom "Rot"(%cst_43, %cst_18, %cst_17) %out_qubits_90#0 : !quantum.bit
    %out_qubits_92 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_67#1 : !quantum.bit
    %out_qubits_93 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_76#1 : !quantum.bit
    %out_qubits_94:2 = quantum.custom "CZ"() %out_qubits_92, %out_qubits_93 : !quantum.bit, !quantum.bit
    %out_qubits_95 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_83#1 : !quantum.bit
    %out_qubits_96:2 = quantum.custom "CZ"() %out_qubits_94#0, %out_qubits_95 : !quantum.bit, !quantum.bit
    %out_qubits_97 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_88#1 : !quantum.bit
    %out_qubits_98:2 = quantum.custom "CZ"() %out_qubits_96#0, %out_qubits_97 : !quantum.bit, !quantum.bit
    %out_qubits_99 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_90#1 : !quantum.bit
    %out_qubits_100:2 = quantum.custom "CZ"() %out_qubits_98#0, %out_qubits_99 : !quantum.bit, !quantum.bit
    %out_qubits_101 = quantum.custom "Rot"(%cst_28, %cst_16, %cst_15) %out_qubits_100#0 : !quantum.bit
    %out_qubits_102:2 = quantum.custom "CZ"() %out_qubits_91, %out_qubits_101 : !quantum.bit, !quantum.bit
    %out_qubits_103 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_94#1 : !quantum.bit
    %out_qubits_104 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_96#1 : !quantum.bit
    %out_qubits_105:2 = quantum.custom "CZ"() %out_qubits_103, %out_qubits_104 : !quantum.bit, !quantum.bit
    %out_qubits_106 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_98#1 : !quantum.bit
    %out_qubits_107:2 = quantum.custom "CZ"() %out_qubits_105#0, %out_qubits_106 : !quantum.bit, !quantum.bit
    %out_qubits_108 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_100#1 : !quantum.bit
    %out_qubits_109:2 = quantum.custom "CZ"() %out_qubits_107#0, %out_qubits_108 : !quantum.bit, !quantum.bit
    %out_qubits_110 = quantum.custom "Rot"(%cst_34, %cst_14, %cst_38) %out_qubits_109#0 : !quantum.bit
    %out_qubits_111:2 = quantum.custom "CZ"() %out_qubits_102#0, %out_qubits_110 : !quantum.bit, !quantum.bit
    %out_qubits_112 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_105#1 : !quantum.bit
    %out_qubits_113 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_107#1 : !quantum.bit
    %out_qubits_114:2 = quantum.custom "CZ"() %out_qubits_112, %out_qubits_113 : !quantum.bit, !quantum.bit
    %out_qubits_115 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_109#1 : !quantum.bit
    %out_qubits_116:2 = quantum.custom "CZ"() %out_qubits_114#0, %out_qubits_115 : !quantum.bit, !quantum.bit
    %out_qubits_117 = quantum.custom "Rot"(%cst_28, %cst_13, %cst_12) %out_qubits_116#0 : !quantum.bit
    %out_qubits_118:2 = quantum.custom "CZ"() %out_qubits_111#0, %out_qubits_117 : !quantum.bit, !quantum.bit
    %out_qubits_119 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_114#1 : !quantum.bit
    %out_qubits_120 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_116#1 : !quantum.bit
    %out_qubits_121:2 = quantum.custom "CZ"() %out_qubits_119, %out_qubits_120 : !quantum.bit, !quantum.bit
    %out_qubits_122 = quantum.custom "Rot"(%cst_38, %cst_11, %cst_34) %out_qubits_121#0 : !quantum.bit
    %out_qubits_123:2 = quantum.custom "CZ"() %out_qubits_118#0, %out_qubits_122 : !quantum.bit, !quantum.bit
    %out_qubits_124 = quantum.custom "Rot"(%cst_10, %cst_9, %cst_28) %out_qubits_121#1 : !quantum.bit
    %out_qubits_125:2 = quantum.custom "CZ"() %out_qubits_123#0, %out_qubits_124 : !quantum.bit, !quantum.bit
    %out_qubits_126 = quantum.custom "Rot"(%cst_30, %cst_8, %cst_45) %out_qubits_125#0 : !quantum.bit
    %out_qubits_127 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_102#1 : !quantum.bit
    %out_qubits_128 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_111#1 : !quantum.bit
    %out_qubits_129:2 = quantum.custom "CZ"() %out_qubits_127, %out_qubits_128 : !quantum.bit, !quantum.bit
    %out_qubits_130 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_118#1 : !quantum.bit
    %out_qubits_131:2 = quantum.custom "CZ"() %out_qubits_129#0, %out_qubits_130 : !quantum.bit, !quantum.bit
    %out_qubits_132 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_123#1 : !quantum.bit
    %out_qubits_133:2 = quantum.custom "CZ"() %out_qubits_131#0, %out_qubits_132 : !quantum.bit, !quantum.bit
    %out_qubits_134 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_125#1 : !quantum.bit
    %out_qubits_135:2 = quantum.custom "CZ"() %out_qubits_133#0, %out_qubits_134 : !quantum.bit, !quantum.bit
    %out_qubits_136 = quantum.custom "Rot"(%cst_45, %cst_7, %cst_6) %out_qubits_135#0 : !quantum.bit
    %out_qubits_137 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_129#1 : !quantum.bit
    %out_qubits_138 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_131#1 : !quantum.bit
    %out_qubits_139:2 = quantum.custom "CZ"() %out_qubits_137, %out_qubits_138 : !quantum.bit, !quantum.bit
    %out_qubits_140 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_133#1 : !quantum.bit
    %out_qubits_141:2 = quantum.custom "CZ"() %out_qubits_139#0, %out_qubits_140 : !quantum.bit, !quantum.bit
    %out_qubits_142 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_135#1 : !quantum.bit
    %out_qubits_143:2 = quantum.custom "CZ"() %out_qubits_141#0, %out_qubits_142 : !quantum.bit, !quantum.bit
    %out_qubits_144 = quantum.custom "Rot"(%cst_5, %cst_4, %cst_6) %out_qubits_143#0 : !quantum.bit
    %out_qubits_145 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_139#1 : !quantum.bit
    %out_qubits_146 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_141#1 : !quantum.bit
    %out_qubits_147:2 = quantum.custom "CZ"() %out_qubits_145, %out_qubits_146 : !quantum.bit, !quantum.bit
    %out_qubits_148 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_143#1 : !quantum.bit
    %out_qubits_149:2 = quantum.custom "CZ"() %out_qubits_147#0, %out_qubits_148 : !quantum.bit, !quantum.bit
    %out_qubits_150 = quantum.custom "Rot"(%cst_28, %cst_3, %cst_2) %out_qubits_149#0 : !quantum.bit
    %out_qubits_151 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_43) %out_qubits_147#1 : !quantum.bit
    %out_qubits_152 = quantum.custom "Rot"(%cst_27, %cst_28, %cst_32) %out_qubits_149#1 : !quantum.bit
    %out_qubits_153:2 = quantum.custom "CZ"() %out_qubits_151, %out_qubits_152 : !quantum.bit, !quantum.bit
    %out_qubits_154 = quantum.custom "Rot"(%cst_34, %cst_1, %cst_6) %out_qubits_153#0 : !quantum.bit
    %out_qubits_155 = quantum.custom "Rot"(%cst_5, %cst_0, %cst_6) %out_qubits_153#1 : !quantum.bit
    quantum.gphase(%cst)
    %7 = quantum.compbasis qubits %out_qubits_126, %out_qubits_136, %out_qubits_144, %out_qubits_150, %out_qubits_154, %out_qubits_155 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x6xf64>
    %9 = stablehlo.convert %8 : (tensor<128x6xf64>) -> tensor<128x6xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_126 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_136 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_144 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_150 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_154 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_155 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x6xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}