module @circuit {
  func.func public @jit_circuit() -> tensor<128x3xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x3xi64>
    return %0 : tensor<128x3xi64>
  }
  func.func public @circuit_0() -> tensor<128x3xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 0.000000e+00 : f64
    %cst_0 = arith.constant 0.39269908169872414 : f64
    %cst_1 = arith.constant -0.39269908169872414 : f64
    %cst_2 = arith.constant 0.78539816339744828 : f64
    %cst_3 = arith.constant 3.1415926535897931 : f64
    %cst_4 = arith.constant -0.78539816339744828 : f64
    %cst_5 = arith.constant -1.5707963267948966 : f64
    %cst_6 = arith.constant 1.5707963267948966 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst) %1 : !quantum.bit
    %out_qubits_7 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_8 = quantum.custom "RZ"(%cst_4) %out_qubits_7 : !quantum.bit
    %2 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_9 = quantum.custom "RZ"(%cst) %2 : !quantum.bit
    %out_qubits_10 = quantum.custom "Hadamard"() %out_qubits_9 : !quantum.bit
    %out_qubits_11 = quantum.custom "RZ"(%cst) %out_qubits_10 : !quantum.bit
    %out_qubits_12 = quantum.custom "Hadamard"() %out_qubits_11 : !quantum.bit
    %3 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits_13 = quantum.custom "RZ"(%cst) %3 : !quantum.bit
    %out_qubits_14 = quantum.custom "Hadamard"() %out_qubits_13 : !quantum.bit
    %out_qubits_15 = quantum.custom "RZ"(%cst) %out_qubits_14 : !quantum.bit
    %out_qubits_16 = quantum.custom "Hadamard"() %out_qubits_15 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_17 = quantum.custom "RX"(%cst_3) %4 : !quantum.bit
    %out_qubits_18 = quantum.custom "RZ"(%cst_6) %out_qubits_17 : !quantum.bit
    %out_qubits_19:2 = quantum.custom "CZ"() %out_qubits_18, %out_qubits_16 : !quantum.bit, !quantum.bit
    %out_qubits_20 = quantum.custom "Hadamard"() %out_qubits_19#1 : !quantum.bit
    %out_qubits_21 = quantum.custom "RZ"(%cst_5) %out_qubits_20 : !quantum.bit
    %out_qubits_22 = quantum.custom "Hadamard"() %out_qubits_21 : !quantum.bit
    %out_qubits_23:2 = quantum.custom "CZ"() %out_qubits_19#0, %out_qubits_22 : !quantum.bit, !quantum.bit
    %out_qubits_24 = quantum.custom "Hadamard"() %out_qubits_23#1 : !quantum.bit
    %out_qubits_25 = quantum.custom "RZ"(%cst_6) %out_qubits_24 : !quantum.bit
    %out_qubits_26:2 = quantum.custom "CZ"() %out_qubits_25, %out_qubits_12 : !quantum.bit, !quantum.bit
    %out_qubits_27 = quantum.custom "Hadamard"() %out_qubits_26#0 : !quantum.bit
    %out_qubits_28 = quantum.custom "Hadamard"() %out_qubits_26#1 : !quantum.bit
    %out_qubits_29:2 = quantum.custom "CZ"() %out_qubits_28, %out_qubits_27 : !quantum.bit, !quantum.bit
    %out_qubits_30 = quantum.custom "Hadamard"() %out_qubits_29#1 : !quantum.bit
    %out_qubits_31 = quantum.custom "Hadamard"() %out_qubits_29#0 : !quantum.bit
    %out_qubits_32:2 = quantum.custom "CZ"() %out_qubits_30, %out_qubits_31 : !quantum.bit, !quantum.bit
    %out_qubits_33 = quantum.custom "RZ"(%cst) %out_qubits_32#0 : !quantum.bit
    %out_qubits_34 = quantum.custom "Hadamard"() %out_qubits_33 : !quantum.bit
    %out_qubits_35 = quantum.custom "RZ"(%cst) %out_qubits_34 : !quantum.bit
    %out_qubits_36 = quantum.custom "Hadamard"() %out_qubits_35 : !quantum.bit
    %out_qubits_37:2 = quantum.custom "CZ"() %out_qubits_8, %out_qubits_36 : !quantum.bit, !quantum.bit
    %out_qubits_38 = quantum.custom "Hadamard"() %out_qubits_37#1 : !quantum.bit
    %out_qubits_39 = quantum.custom "RZ"(%cst_2) %out_qubits_38 : !quantum.bit
    %out_qubits_40 = quantum.custom "Hadamard"() %out_qubits_39 : !quantum.bit
    %out_qubits_41:2 = quantum.custom "CZ"() %out_qubits_37#0, %out_qubits_40 : !quantum.bit, !quantum.bit
    %out_qubits_42 = quantum.custom "Hadamard"() %out_qubits_41#1 : !quantum.bit
    %out_qubits_43 = quantum.custom "RZ"(%cst_4) %out_qubits_42 : !quantum.bit
    %out_qubits_44 = quantum.custom "Hadamard"() %out_qubits_43 : !quantum.bit
    %out_qubits_45 = quantum.custom "Hadamard"() %out_qubits_32#1 : !quantum.bit
    %out_qubits_46 = quantum.custom "RZ"(%cst_1) %out_qubits_45 : !quantum.bit
    %out_qubits_47:2 = quantum.custom "CZ"() %out_qubits_46, %out_qubits_44 : !quantum.bit, !quantum.bit
    %out_qubits_48 = quantum.custom "Hadamard"() %out_qubits_47#1 : !quantum.bit
    %out_qubits_49 = quantum.custom "RZ"(%cst_0) %out_qubits_48 : !quantum.bit
    %out_qubits_50 = quantum.custom "Hadamard"() %out_qubits_49 : !quantum.bit
    %out_qubits_51:2 = quantum.custom "CZ"() %out_qubits_47#0, %out_qubits_50 : !quantum.bit, !quantum.bit
    %out_qubits_52 = quantum.custom "Hadamard"() %out_qubits_51#1 : !quantum.bit
    %out_qubits_53 = quantum.custom "RZ"(%cst_1) %out_qubits_52 : !quantum.bit
    %out_qubits_54 = quantum.custom "RZ"(%cst) %out_qubits_41#0 : !quantum.bit
    %out_qubits_55 = quantum.custom "Hadamard"() %out_qubits_54 : !quantum.bit
    %out_qubits_56 = quantum.custom "RZ"(%cst) %out_qubits_55 : !quantum.bit
    %out_qubits_57 = quantum.custom "Hadamard"() %out_qubits_56 : !quantum.bit
    %out_qubits_58 = quantum.custom "RZ"(%cst_4) %out_qubits_51#0 : !quantum.bit
    %out_qubits_59:2 = quantum.custom "CZ"() %out_qubits_58, %out_qubits_57 : !quantum.bit, !quantum.bit
    %out_qubits_60 = quantum.custom "Hadamard"() %out_qubits_59#1 : !quantum.bit
    %out_qubits_61 = quantum.custom "RZ"(%cst_2) %out_qubits_60 : !quantum.bit
    %out_qubits_62 = quantum.custom "Hadamard"() %out_qubits_61 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_59#0, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Hadamard"() %out_qubits_63#1 : !quantum.bit
    %out_qubits_65 = quantum.custom "RZ"(%cst_4) %out_qubits_64 : !quantum.bit
    %out_qubits_66 = quantum.custom "RZ"(%cst) %out_qubits_63#0 : !quantum.bit
    %out_qubits_67 = quantum.custom "Hadamard"() %out_qubits_66 : !quantum.bit
    %out_qubits_68 = quantum.custom "RZ"(%cst) %out_qubits_67 : !quantum.bit
    %5 = quantum.compbasis qubits %out_qubits_53, %out_qubits_65, %out_qubits_68 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x3xf64>
    %7 = stablehlo.convert %6 : (tensor<128x3xf64>) -> tensor<128x3xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_53 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_65 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_68 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_23#0 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x3xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}