module @circuit {
  func.func public @jit_circuit() -> tensor<128x3xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x3xi64>
    return %0 : tensor<128x3xi64>
  }
  func.func public @circuit_0() -> tensor<128x3xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 0.000000e+00 : f64
    %cst_0 = arith.constant 0.78539816339744828 : f64
    %cst_1 = arith.constant -0.78539816339744828 : f64
    %cst_2 = arith.constant -0.39269908169872414 : f64
    %cst_3 = arith.constant 0.39269908169872414 : f64
    %cst_4 = arith.constant 1.3744467859455345 : f64
    %cst_5 = arith.constant -1.3744467859455345 : f64
    %cst_6 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst) %1 : !quantum.bit
    %out_qubits_7 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_8 = quantum.custom "RZ"(%cst) %out_qubits_7 : !quantum.bit
    %out_qubits_9 = quantum.custom "Hadamard"() %out_qubits_8 : !quantum.bit
    %2 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits_10 = quantum.custom "RZ"(%cst) %2 : !quantum.bit
    %out_qubits_11 = quantum.custom "Hadamard"() %out_qubits_10 : !quantum.bit
    %out_qubits_12 = quantum.custom "RZ"(%cst) %out_qubits_11 : !quantum.bit
    %out_qubits_13 = quantum.custom "Hadamard"() %out_qubits_12 : !quantum.bit
    %3 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_14 = quantum.custom "RX"(%cst_6) %3 : !quantum.bit
    %out_qubits_15 = quantum.custom "RZ"(%cst_5) %out_qubits_14 : !quantum.bit
    %out_qubits_16:2 = quantum.custom "CZ"() %out_qubits_15, %out_qubits_13 : !quantum.bit, !quantum.bit
    %out_qubits_17 = quantum.custom "Hadamard"() %out_qubits_16#1 : !quantum.bit
    %out_qubits_18 = quantum.custom "RZ"(%cst_4) %out_qubits_17 : !quantum.bit
    %out_qubits_19 = quantum.custom "Hadamard"() %out_qubits_18 : !quantum.bit
    %out_qubits_20:2 = quantum.custom "CZ"() %out_qubits_16#0, %out_qubits_19 : !quantum.bit, !quantum.bit
    %out_qubits_21 = quantum.custom "RZ"(%cst_3) %out_qubits_20#0 : !quantum.bit
    %out_qubits_22:2 = quantum.custom "CZ"() %out_qubits_21, %out_qubits_9 : !quantum.bit, !quantum.bit
    %out_qubits_23 = quantum.custom "Hadamard"() %out_qubits_22#1 : !quantum.bit
    %out_qubits_24 = quantum.custom "RZ"(%cst_2) %out_qubits_23 : !quantum.bit
    %out_qubits_25 = quantum.custom "Hadamard"() %out_qubits_24 : !quantum.bit
    %out_qubits_26:2 = quantum.custom "CZ"() %out_qubits_22#0, %out_qubits_25 : !quantum.bit, !quantum.bit
    %out_qubits_27 = quantum.custom "Hadamard"() %out_qubits_26#1 : !quantum.bit
    %out_qubits_28 = quantum.custom "RZ"(%cst_2) %out_qubits_27 : !quantum.bit
    %out_qubits_29 = quantum.custom "Hadamard"() %out_qubits_20#1 : !quantum.bit
    %out_qubits_30 = quantum.custom "RZ"(%cst_5) %out_qubits_29 : !quantum.bit
    %4 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_31 = quantum.custom "RZ"(%cst) %4 : !quantum.bit
    %out_qubits_32 = quantum.custom "Hadamard"() %out_qubits_31 : !quantum.bit
    %out_qubits_33 = quantum.custom "RZ"(%cst) %out_qubits_32 : !quantum.bit
    %out_qubits_34 = quantum.custom "Hadamard"() %out_qubits_33 : !quantum.bit
    %out_qubits_35 = quantum.custom "RZ"(%cst_0) %out_qubits_26#0 : !quantum.bit
    %out_qubits_36:2 = quantum.custom "CZ"() %out_qubits_35, %out_qubits_34 : !quantum.bit, !quantum.bit
    %out_qubits_37 = quantum.custom "Hadamard"() %out_qubits_36#1 : !quantum.bit
    %out_qubits_38 = quantum.custom "RZ"(%cst_1) %out_qubits_37 : !quantum.bit
    %out_qubits_39 = quantum.custom "Hadamard"() %out_qubits_38 : !quantum.bit
    %out_qubits_40:2 = quantum.custom "CZ"() %out_qubits_36#0, %out_qubits_39 : !quantum.bit, !quantum.bit
    %out_qubits_41 = quantum.custom "Hadamard"() %out_qubits_40#1 : !quantum.bit
    %out_qubits_42 = quantum.custom "RZ"(%cst_0) %out_qubits_41 : !quantum.bit
    %out_qubits_43 = quantum.custom "Hadamard"() %out_qubits_42 : !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_30, %out_qubits_43 : !quantum.bit, !quantum.bit
    %out_qubits_45 = quantum.custom "Hadamard"() %out_qubits_44#0 : !quantum.bit
    %out_qubits_46 = quantum.custom "Hadamard"() %out_qubits_44#1 : !quantum.bit
    %out_qubits_47:2 = quantum.custom "CZ"() %out_qubits_46, %out_qubits_45 : !quantum.bit, !quantum.bit
    %out_qubits_48 = quantum.custom "Hadamard"() %out_qubits_47#1 : !quantum.bit
    %out_qubits_49 = quantum.custom "Hadamard"() %out_qubits_47#0 : !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits_48, %out_qubits_49 : !quantum.bit, !quantum.bit
    %out_qubits_51 = quantum.custom "RZ"(%cst) %out_qubits_50#0 : !quantum.bit
    %out_qubits_52 = quantum.custom "Hadamard"() %out_qubits_51 : !quantum.bit
    %out_qubits_53 = quantum.custom "RZ"(%cst) %out_qubits_52 : !quantum.bit
    %out_qubits_54 = quantum.custom "Hadamard"() %out_qubits_53 : !quantum.bit
    %out_qubits_55:2 = quantum.custom "CZ"() %out_qubits_28, %out_qubits_54 : !quantum.bit, !quantum.bit
    %out_qubits_56 = quantum.custom "Hadamard"() %out_qubits_55#1 : !quantum.bit
    %out_qubits_57 = quantum.custom "RZ"(%cst_0) %out_qubits_56 : !quantum.bit
    %out_qubits_58 = quantum.custom "Hadamard"() %out_qubits_57 : !quantum.bit
    %out_qubits_59:2 = quantum.custom "CZ"() %out_qubits_55#0, %out_qubits_58 : !quantum.bit, !quantum.bit
    %out_qubits_60 = quantum.custom "Hadamard"() %out_qubits_59#1 : !quantum.bit
    %out_qubits_61 = quantum.custom "RZ"(%cst_1) %out_qubits_60 : !quantum.bit
    %out_qubits_62 = quantum.custom "Hadamard"() %out_qubits_61 : !quantum.bit
    %out_qubits_63 = quantum.custom "Hadamard"() %out_qubits_50#1 : !quantum.bit
    %out_qubits_64 = quantum.custom "RZ"(%cst_2) %out_qubits_63 : !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_64, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "Hadamard"() %out_qubits_65#1 : !quantum.bit
    %out_qubits_67 = quantum.custom "RZ"(%cst_3) %out_qubits_66 : !quantum.bit
    %out_qubits_68 = quantum.custom "Hadamard"() %out_qubits_67 : !quantum.bit
    %out_qubits_69:2 = quantum.custom "CZ"() %out_qubits_65#0, %out_qubits_68 : !quantum.bit, !quantum.bit
    %out_qubits_70 = quantum.custom "Hadamard"() %out_qubits_69#1 : !quantum.bit
    %out_qubits_71 = quantum.custom "RZ"(%cst_2) %out_qubits_70 : !quantum.bit
    %out_qubits_72 = quantum.custom "RZ"(%cst) %out_qubits_59#0 : !quantum.bit
    %out_qubits_73 = quantum.custom "Hadamard"() %out_qubits_72 : !quantum.bit
    %out_qubits_74 = quantum.custom "RZ"(%cst) %out_qubits_73 : !quantum.bit
    %out_qubits_75 = quantum.custom "Hadamard"() %out_qubits_74 : !quantum.bit
    %out_qubits_76 = quantum.custom "RZ"(%cst_1) %out_qubits_69#0 : !quantum.bit
    %out_qubits_77:2 = quantum.custom "CZ"() %out_qubits_76, %out_qubits_75 : !quantum.bit, !quantum.bit
    %out_qubits_78 = quantum.custom "Hadamard"() %out_qubits_77#1 : !quantum.bit
    %out_qubits_79 = quantum.custom "RZ"(%cst_0) %out_qubits_78 : !quantum.bit
    %out_qubits_80 = quantum.custom "Hadamard"() %out_qubits_79 : !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_77#0, %out_qubits_80 : !quantum.bit, !quantum.bit
    %out_qubits_82 = quantum.custom "Hadamard"() %out_qubits_81#1 : !quantum.bit
    %out_qubits_83 = quantum.custom "RZ"(%cst_1) %out_qubits_82 : !quantum.bit
    %out_qubits_84 = quantum.custom "RZ"(%cst) %out_qubits_81#0 : !quantum.bit
    %out_qubits_85 = quantum.custom "Hadamard"() %out_qubits_84 : !quantum.bit
    %out_qubits_86 = quantum.custom "RZ"(%cst) %out_qubits_85 : !quantum.bit
    %5 = quantum.compbasis qubits %out_qubits_71, %out_qubits_83, %out_qubits_86 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x3xf64>
    %7 = stablehlo.convert %6 : (tensor<128x3xf64>) -> tensor<128x3xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_71 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_83 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_86 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_40#0 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x3xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}