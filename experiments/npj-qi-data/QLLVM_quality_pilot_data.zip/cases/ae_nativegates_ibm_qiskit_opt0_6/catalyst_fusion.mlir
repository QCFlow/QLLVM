module @circuit {
  func.func public @jit_circuit() -> tensor<128x6xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x6xi64>
    return %0 : tensor<128x6xi64>
  }
  func.func public @circuit_0() -> tensor<128x6xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -144.51326206513028 : f64
    %cst_0 = arith.constant 9.4247779607693793 : f64
    %cst_1 = arith.constant 2.4420361067180716 : f64
    %cst_2 = arith.constant -1.2212453270876722E-15 : f64
    %cst_3 = arith.constant -0.098174770424681035 : f64
    %cst_4 = arith.constant -0.19634954084936207 : f64
    %cst_5 = arith.constant -0.39269908169872414 : f64
    %cst_6 = arith.constant -0.78539816339744828 : f64
    %cst_7 = arith.constant 1.6689710972195777 : f64
    %cst_8 = arith.constant 0.098174770424680535 : f64
    %cst_9 = arith.constant 1.570796326794897 : f64
    %cst_10 = arith.constant 2.454369260617026 : f64
    %cst_11 = arith.constant 0.19634954084936121 : f64
    %cst_12 = arith.constant 0.39269908169872436 : f64
    %cst_13 = arith.constant 5.6941366846315002 : f64
    %cst_14 = arith.constant -0.58904862254808599 : f64
    %cst_15 = arith.constant -1.5707963267948966 : f64
    %cst_16 = arith.constant 0.3926990816987232 : f64
    %cst_17 = arith.constant 0.78539816339744839 : f64
    %cst_18 = arith.constant 1.1780972450961724 : f64
    %cst_19 = arith.constant 4.3196898986859651 : f64
    %cst_20 = arith.constant -1.5707963267948963 : f64
    %cst_21 = arith.constant 0.78539816339744783 : f64
    %cst_22 = arith.constant -4.7123889803846897 : f64
    %cst_23 = arith.constant 4.7123889803846897 : f64
    %cst_24 = arith.constant 4.4408920985006262E-16 : f64
    %cst_25 = arith.constant 2.2703528736666216 : f64
    %cst_26 = arith.constant 6.2831853071795862 : f64
    %cst_27 = arith.constant 1.1351764368333119 : f64
    %cst_28 = arith.constant 7.9109156708797175E-16 : f64
    %cst_29 = arith.constant 1.1351764368333115 : f64
    %cst_30 = arith.constant -6.6494387529486556E-16 : f64
    %cst_31 = arith.constant -7.6832007517935119E-16 : f64
    %cst_32 = arith.constant 2.574004435173137 : f64
    %cst_33 = arith.constant -9.1119553507987583E-16 : f64
    %cst_34 = arith.constant 3.1415926535897936 : f64
    %cst_35 = arith.constant 2.5740044351731379 : f64
    %cst_36 = arith.constant 1.854590436003225 : f64
    %cst_37 = arith.constant -3.1415926535897931 : f64
    %cst_38 = arith.constant 1.8545904360032237 : f64
    %cst_39 = arith.constant -3.1415926535897936 : f64
    %cst_40 = arith.constant -3.1415926535897927 : f64
    %cst_41 = arith.constant -6.2831853071795862 : f64
    %cst_42 = arith.constant 0.92729521800161285 : f64
    %cst_43 = arith.constant -4.4408920985006262E-16 : f64
    %cst_44 = arith.constant 8.8817841970012523E-16 : f64
    %cst_45 = arith.constant 0.64350110879328382 : f64
    %cst_46 = arith.constant 3.1415926535897922 : f64
    %cst_47 = arith.constant 0.000000e+00 : f64
    %cst_48 = arith.constant 1.5707963267948966 : f64
    %cst_49 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_49, %cst_48, %cst_47) %1 : !quantum.bit
    %2 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_50 = quantum.custom "Rot"(%cst_49, %cst_48, %cst_47) %2 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_51 = quantum.custom "Rot"(%cst_49, %cst_48, %cst_47) %3 : !quantum.bit
    %4 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_49, %cst_48, %cst_47) %4 : !quantum.bit
    %5 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_49, %cst_48, %cst_47) %5 : !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_54 = quantum.custom "Rot"(%cst_46, %cst_45, %cst_44) %6 : !quantum.bit
    %out_qubits_55:2 = quantum.custom "CZ"() %out_qubits_53, %out_qubits_54 : !quantum.bit, !quantum.bit
    %out_qubits_56 = quantum.custom "Rot"(%cst_43, %cst_42, %cst_41) %out_qubits_55#1 : !quantum.bit
    %out_qubits_57:2 = quantum.custom "CZ"() %out_qubits_55#0, %out_qubits_56 : !quantum.bit, !quantum.bit
    %out_qubits_58 = quantum.custom "Rot"(%cst_40, %cst_42, %cst_39) %out_qubits_57#1 : !quantum.bit
    %out_qubits_59:2 = quantum.custom "CZ"() %out_qubits_52, %out_qubits_58 : !quantum.bit, !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_47, %cst_38, %cst_41) %out_qubits_59#1 : !quantum.bit
    %out_qubits_61:2 = quantum.custom "CZ"() %out_qubits_59#0, %out_qubits_60 : !quantum.bit, !quantum.bit
    %out_qubits_62 = quantum.custom "Rot"(%cst_37, %cst_36, %cst_37) %out_qubits_61#1 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_51, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Rot"(%cst_40, %cst_35, %cst_34) %out_qubits_63#1 : !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_63#0, %out_qubits_64 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %out_qubits_65#1 : !quantum.bit
    %out_qubits_67:2 = quantum.custom "CZ"() %out_qubits_50, %out_qubits_66 : !quantum.bit, !quantum.bit
    %out_qubits_68 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %out_qubits_67#1 : !quantum.bit
    %out_qubits_69:2 = quantum.custom "CZ"() %out_qubits_67#0, %out_qubits_68 : !quantum.bit, !quantum.bit
    %out_qubits_70 = quantum.custom "Rot"(%cst_37, %cst_27, %cst_49) %out_qubits_69#1 : !quantum.bit
    %out_qubits_71:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_70 : !quantum.bit, !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_26, %cst_25, %cst_24) %out_qubits_71#1 : !quantum.bit
    %out_qubits_73:2 = quantum.custom "CZ"() %out_qubits_71#0, %out_qubits_72 : !quantum.bit, !quantum.bit
    %out_qubits_74 = quantum.custom "Rot"(%cst_23, %cst_47, %cst_48) %out_qubits_73#0 : !quantum.bit
    %out_qubits_75:2 = quantum.custom "CZ"() %out_qubits_69#0, %out_qubits_74 : !quantum.bit, !quantum.bit
    %out_qubits_76 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_75#1 : !quantum.bit
    %out_qubits_77:2 = quantum.custom "CZ"() %out_qubits_75#0, %out_qubits_76 : !quantum.bit, !quantum.bit
    %out_qubits_78 = quantum.custom "Rot"(%cst_19, %cst_47, %cst_18) %out_qubits_77#0 : !quantum.bit
    %out_qubits_79 = quantum.custom "Rot"(%cst_23, %cst_17, %cst_48) %out_qubits_77#1 : !quantum.bit
    %out_qubits_80:2 = quantum.custom "CZ"() %out_qubits_65#0, %out_qubits_79 : !quantum.bit, !quantum.bit
    %out_qubits_81 = quantum.custom "Rot"(%cst_22, %cst_16, %cst_15) %out_qubits_80#1 : !quantum.bit
    %out_qubits_82:2 = quantum.custom "CZ"() %out_qubits_80#0, %out_qubits_81 : !quantum.bit, !quantum.bit
    %out_qubits_83:2 = quantum.custom "CZ"() %out_qubits_82#0, %out_qubits_78 : !quantum.bit, !quantum.bit
    %out_qubits_84 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_83#1 : !quantum.bit
    %out_qubits_85:2 = quantum.custom "CZ"() %out_qubits_83#0, %out_qubits_84 : !quantum.bit, !quantum.bit
    %out_qubits_86 = quantum.custom "Rot"(%cst_14, %cst_47, %cst_13) %out_qubits_85#0 : !quantum.bit
    %out_qubits_87 = quantum.custom "Rot"(%cst_23, %cst_17, %cst_48) %out_qubits_85#1 : !quantum.bit
    %out_qubits_88 = quantum.custom "Rot"(%cst_23, %cst_12, %cst_48) %out_qubits_82#1 : !quantum.bit
    %out_qubits_89:2 = quantum.custom "CZ"() %out_qubits_61#0, %out_qubits_88 : !quantum.bit, !quantum.bit
    %out_qubits_90 = quantum.custom "Rot"(%cst_48, %cst_11, %cst_23) %out_qubits_89#1 : !quantum.bit
    %out_qubits_91:2 = quantum.custom "CZ"() %out_qubits_89#0, %out_qubits_90 : !quantum.bit, !quantum.bit
    %out_qubits_92:2 = quantum.custom "CZ"() %out_qubits_91#0, %out_qubits_87 : !quantum.bit, !quantum.bit
    %out_qubits_93 = quantum.custom "Rot"(%cst_22, %cst_16, %cst_15) %out_qubits_92#1 : !quantum.bit
    %out_qubits_94:2 = quantum.custom "CZ"() %out_qubits_92#0, %out_qubits_93 : !quantum.bit, !quantum.bit
    %out_qubits_95:2 = quantum.custom "CZ"() %out_qubits_94#0, %out_qubits_86 : !quantum.bit, !quantum.bit
    %out_qubits_96 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_95#1 : !quantum.bit
    %out_qubits_97:2 = quantum.custom "CZ"() %out_qubits_95#0, %out_qubits_96 : !quantum.bit, !quantum.bit
    %out_qubits_98 = quantum.custom "Rot"(%cst_10, %cst_47, %cst_10) %out_qubits_97#0 : !quantum.bit
    %out_qubits_99 = quantum.custom "Rot"(%cst_23, %cst_17, %cst_48) %out_qubits_97#1 : !quantum.bit
    %out_qubits_100 = quantum.custom "Rot"(%cst_23, %cst_12, %cst_48) %out_qubits_94#1 : !quantum.bit
    %out_qubits_101 = quantum.custom "Rot"(%cst_23, %cst_11, %cst_9) %out_qubits_91#1 : !quantum.bit
    %out_qubits_102:2 = quantum.custom "CZ"() %out_qubits_57#0, %out_qubits_101 : !quantum.bit, !quantum.bit
    %out_qubits_103 = quantum.custom "Rot"(%cst_48, %cst_8, %cst_23) %out_qubits_102#1 : !quantum.bit
    %out_qubits_104:2 = quantum.custom "CZ"() %out_qubits_102#0, %out_qubits_103 : !quantum.bit, !quantum.bit
    %out_qubits_105:2 = quantum.custom "CZ"() %out_qubits_104#0, %out_qubits_100 : !quantum.bit, !quantum.bit
    %out_qubits_106 = quantum.custom "Rot"(%cst_48, %cst_11, %cst_23) %out_qubits_105#1 : !quantum.bit
    %out_qubits_107:2 = quantum.custom "CZ"() %out_qubits_105#0, %out_qubits_106 : !quantum.bit, !quantum.bit
    %out_qubits_108:2 = quantum.custom "CZ"() %out_qubits_107#0, %out_qubits_99 : !quantum.bit, !quantum.bit
    %out_qubits_109 = quantum.custom "Rot"(%cst_22, %cst_16, %cst_15) %out_qubits_108#1 : !quantum.bit
    %out_qubits_110:2 = quantum.custom "CZ"() %out_qubits_108#0, %out_qubits_109 : !quantum.bit, !quantum.bit
    %out_qubits_111:2 = quantum.custom "CZ"() %out_qubits_110#0, %out_qubits_98 : !quantum.bit, !quantum.bit
    %out_qubits_112 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_111#1 : !quantum.bit
    %out_qubits_113:2 = quantum.custom "CZ"() %out_qubits_111#0, %out_qubits_112 : !quantum.bit, !quantum.bit
    %out_qubits_114 = quantum.custom "Rot"(%cst_7, %cst_48, %cst_47) %out_qubits_113#0 : !quantum.bit
    %out_qubits_115 = quantum.custom "Rot"(%cst_49, %cst_48, %cst_6) %out_qubits_113#1 : !quantum.bit
    %out_qubits_116 = quantum.custom "Rot"(%cst_49, %cst_48, %cst_5) %out_qubits_110#1 : !quantum.bit
    %out_qubits_117 = quantum.custom "Rot"(%cst_49, %cst_48, %cst_4) %out_qubits_107#1 : !quantum.bit
    %out_qubits_118 = quantum.custom "Rot"(%cst_49, %cst_48, %cst_3) %out_qubits_104#1 : !quantum.bit
    %out_qubits_119 = quantum.custom "Rot"(%cst_2, %cst_1, %cst_0) %out_qubits_73#1 : !quantum.bit
    quantum.gphase(%cst)
    %7 = quantum.compbasis qubits %out_qubits_114, %out_qubits_115, %out_qubits_116, %out_qubits_117, %out_qubits_118, %out_qubits_119 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x6xf64>
    %9 = stablehlo.convert %8 : (tensor<128x6xf64>) -> tensor<128x6xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_114 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_115 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_116 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_117 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_118 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_119 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x6xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}