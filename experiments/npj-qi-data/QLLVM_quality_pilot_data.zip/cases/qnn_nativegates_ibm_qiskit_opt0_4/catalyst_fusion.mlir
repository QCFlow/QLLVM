module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -103.67255756846309 : f64
    %cst_0 = arith.constant 2.3815389759495798 : f64
    %cst_1 = arith.constant 2.1389074003892983 : f64
    %cst_2 = arith.constant -3.1415926535897931 : f64
    %cst_3 = arith.constant 1.8875281310520247 : f64
    %cst_4 = arith.constant -3.1415926535897936 : f64
    %cst_5 = arith.constant 6.2831853071795862 : f64
    %cst_6 = arith.constant 0.082827766101336631 : f64
    %cst_7 = arith.constant 1.5707963267948963 : f64
    %cst_8 = arith.constant 10.995574287564276 : f64
    %cst_9 = arith.constant 3.1415926535897905 : f64
    %cst_10 = arith.constant 0.29988699354690107 : f64
    %cst_11 = arith.constant 3.1415926535897958 : f64
    %cst_12 = arith.constant 0.69742128627286115 : f64
    %cst_13 = arith.constant 4.7123889803846897 : f64
    %cst_14 = arith.constant 0.8176401212561285 : f64
    %cst_15 = arith.constant -1.5707963267948959 : f64
    %cst_16 = arith.constant 0.084880298294856951 : f64
    %cst_17 = arith.constant -4.2831853071795871 : f64
    %cst_18 = arith.constant 11.424777960769379 : f64
    %cst_19 = arith.constant 5.1415926535897931 : f64
    %cst_20 = arith.constant -1.5707963267948952 : f64
    %cst_21 = arith.constant 2.8896528806399568 : f64
    %cst_22 = arith.constant 1.5707963267948979 : f64
    %cst_23 = arith.constant -1.5707963267948966 : f64
    %cst_24 = arith.constant 1.9999999999999998 : f64
    %cst_25 = arith.constant -4.7123889803846897 : f64
    %cst_26 = arith.constant 0.000000e+00 : f64
    %cst_27 = arith.constant 1.5707963267948966 : f64
    %cst_28 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_28, %cst_27, %cst_26) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_29 = quantum.custom "Rot"(%cst_25, %cst_24, %cst_23) %2 : !quantum.bit
    %out_qubits_30:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_29 : !quantum.bit, !quantum.bit
    %out_qubits_31 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_30#1 : !quantum.bit
    %out_qubits_32:2 = quantum.custom "CZ"() %out_qubits_30#0, %out_qubits_31 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_33 = quantum.custom "Rot"(%cst_25, %cst_24, %cst_23) %3 : !quantum.bit
    %out_qubits_34:2 = quantum.custom "CZ"() %out_qubits_32#0, %out_qubits_33 : !quantum.bit, !quantum.bit
    %out_qubits_35 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_34#1 : !quantum.bit
    %out_qubits_36:2 = quantum.custom "CZ"() %out_qubits_34#0, %out_qubits_35 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_37 = quantum.custom "Rot"(%cst_25, %cst_24, %cst_23) %4 : !quantum.bit
    %out_qubits_38:2 = quantum.custom "CZ"() %out_qubits_36#0, %out_qubits_37 : !quantum.bit, !quantum.bit
    %out_qubits_39 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_38#1 : !quantum.bit
    %out_qubits_40:2 = quantum.custom "CZ"() %out_qubits_38#0, %out_qubits_39 : !quantum.bit, !quantum.bit
    %out_qubits_41 = quantum.custom "Rot"(%cst_19, %cst_27, %cst_26) %out_qubits_40#0 : !quantum.bit
    %out_qubits_42 = quantum.custom "Rot"(%cst_28, %cst_27, %cst_26) %out_qubits_32#1 : !quantum.bit
    %out_qubits_43:2 = quantum.custom "CZ"() %out_qubits_42, %out_qubits_36#1 : !quantum.bit, !quantum.bit
    %out_qubits_44 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_43#1 : !quantum.bit
    %out_qubits_45:2 = quantum.custom "CZ"() %out_qubits_43#0, %out_qubits_44 : !quantum.bit, !quantum.bit
    %out_qubits_46:2 = quantum.custom "CZ"() %out_qubits_45#0, %out_qubits_40#1 : !quantum.bit, !quantum.bit
    %out_qubits_47 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_46#1 : !quantum.bit
    %out_qubits_48:2 = quantum.custom "CZ"() %out_qubits_46#0, %out_qubits_47 : !quantum.bit, !quantum.bit
    %out_qubits_49 = quantum.custom "Rot"(%cst_25, %cst_24, %cst_23) %out_qubits_48#0 : !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits_41, %out_qubits_49 : !quantum.bit, !quantum.bit
    %out_qubits_51 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_50#1 : !quantum.bit
    %out_qubits_52:2 = quantum.custom "CZ"() %out_qubits_50#0, %out_qubits_51 : !quantum.bit, !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_28, %cst_27, %cst_26) %out_qubits_45#1 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_53, %out_qubits_48#1 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_54#1 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_54#0, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_25, %cst_24, %cst_23) %out_qubits_56#0 : !quantum.bit
    %out_qubits_58:2 = quantum.custom "CZ"() %out_qubits_52#0, %out_qubits_57 : !quantum.bit, !quantum.bit
    %out_qubits_59 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_58#1 : !quantum.bit
    %out_qubits_60:2 = quantum.custom "CZ"() %out_qubits_58#0, %out_qubits_59 : !quantum.bit, !quantum.bit
    %out_qubits_61 = quantum.custom "Rot"(%cst_18, %cst_27, %cst_26) %out_qubits_56#1 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_60#0, %out_qubits_61 : !quantum.bit, !quantum.bit
    %out_qubits_63 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_62#1 : !quantum.bit
    %out_qubits_64:2 = quantum.custom "CZ"() %out_qubits_62#0, %out_qubits_63 : !quantum.bit, !quantum.bit
    %out_qubits_65 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %out_qubits_64#0 : !quantum.bit
    %out_qubits_66 = quantum.custom "Rot"(%cst_28, %cst_27, %cst_26) %out_qubits_52#1 : !quantum.bit
    %out_qubits_67:2 = quantum.custom "CZ"() %out_qubits_66, %out_qubits_60#1 : !quantum.bit, !quantum.bit
    %out_qubits_68 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_67#1 : !quantum.bit
    %out_qubits_69:2 = quantum.custom "CZ"() %out_qubits_67#0, %out_qubits_68 : !quantum.bit, !quantum.bit
    %out_qubits_70:2 = quantum.custom "CZ"() %out_qubits_69#0, %out_qubits_64#1 : !quantum.bit, !quantum.bit
    %out_qubits_71 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_70#1 : !quantum.bit
    %out_qubits_72:2 = quantum.custom "CZ"() %out_qubits_70#0, %out_qubits_71 : !quantum.bit, !quantum.bit
    %out_qubits_73 = quantum.custom "Rot"(%cst_26, %cst_14, %cst_13) %out_qubits_72#0 : !quantum.bit
    %out_qubits_74 = quantum.custom "Rot"(%cst_28, %cst_27, %cst_26) %out_qubits_69#1 : !quantum.bit
    %out_qubits_75:2 = quantum.custom "CZ"() %out_qubits_74, %out_qubits_72#1 : !quantum.bit, !quantum.bit
    %out_qubits_76 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_75#1 : !quantum.bit
    %out_qubits_77:2 = quantum.custom "CZ"() %out_qubits_75#0, %out_qubits_76 : !quantum.bit, !quantum.bit
    %out_qubits_78 = quantum.custom "Rot"(%cst_26, %cst_12, %cst_13) %out_qubits_77#0 : !quantum.bit
    %out_qubits_79 = quantum.custom "Rot"(%cst_11, %cst_10, %cst_9) %out_qubits_77#1 : !quantum.bit
    %out_qubits_80:2 = quantum.custom "CZ"() %out_qubits_78, %out_qubits_79 : !quantum.bit, !quantum.bit
    %out_qubits_81 = quantum.custom "Rot"(%cst_8, %cst_27, %cst_26) %out_qubits_80#0 : !quantum.bit
    %out_qubits_82:2 = quantum.custom "CZ"() %out_qubits_73, %out_qubits_81 : !quantum.bit, !quantum.bit
    %out_qubits_83 = quantum.custom "Rot"(%cst_8, %cst_27, %cst_26) %out_qubits_82#0 : !quantum.bit
    %out_qubits_84:2 = quantum.custom "CZ"() %out_qubits_65, %out_qubits_83 : !quantum.bit, !quantum.bit
    %out_qubits_85 = quantum.custom "Rot"(%cst_7, %cst_6, %cst_5) %out_qubits_84#0 : !quantum.bit
    %out_qubits_86 = quantum.custom "Rot"(%cst_4, %cst_3, %cst_5) %out_qubits_84#1 : !quantum.bit
    %out_qubits_87 = quantum.custom "Rot"(%cst_2, %cst_1, %cst_5) %out_qubits_82#1 : !quantum.bit
    %out_qubits_88 = quantum.custom "Rot"(%cst_2, %cst_0, %cst_5) %out_qubits_80#1 : !quantum.bit
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_85, %out_qubits_86, %out_qubits_87, %out_qubits_88 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_85 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_86 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_87 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_88 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}