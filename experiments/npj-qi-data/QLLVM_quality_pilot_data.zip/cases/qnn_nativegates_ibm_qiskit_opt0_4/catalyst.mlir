module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 0.81074264915468274 : f64
    %cst_0 = arith.constant 0.56811107359440172 : f64
    %cst_1 = arith.constant 0.31673180425712832 : f64
    %cst_2 = arith.constant 0.082827766101337019 : f64
    %cst_3 = arith.constant 0.29988699354689974 : f64
    %cst_4 = arith.constant 0.69742128627286082 : f64
    %cst_5 = arith.constant 0.81764012125612862 : f64
    %cst_6 = arith.constant 7.8539816339744828 : f64
    %cst_7 = arith.constant 0.084880298294860435 : f64
    %cst_8 = arith.constant -1.5707963267948966 : f64
    %cst_9 = arith.constant 2.000000e+00 : f64
    %cst_10 = arith.constant 0.000000e+00 : f64
    %cst_11 = arith.constant 9.1728381878195435 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst_10) %1 : !quantum.bit
    %out_qubits_12 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_13 = quantum.custom "RZ"(%cst_9) %out_qubits_12 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_14 = quantum.custom "RZ"(%cst_10) %2 : !quantum.bit
    %out_qubits_15 = quantum.custom "Hadamard"() %out_qubits_14 : !quantum.bit
    %out_qubits_16 = quantum.custom "RZ"(%cst_9) %out_qubits_15 : !quantum.bit
    %out_qubits_17 = quantum.custom "Hadamard"() %out_qubits_16 : !quantum.bit
    %out_qubits_18:2 = quantum.custom "CZ"() %out_qubits_13, %out_qubits_17 : !quantum.bit, !quantum.bit
    %out_qubits_19 = quantum.custom "Hadamard"() %out_qubits_18#1 : !quantum.bit
    %out_qubits_20 = quantum.custom "RZ"(%cst_11) %out_qubits_19 : !quantum.bit
    %out_qubits_21 = quantum.custom "Hadamard"() %out_qubits_20 : !quantum.bit
    %out_qubits_22:2 = quantum.custom "CZ"() %out_qubits_18#0, %out_qubits_21 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_23 = quantum.custom "RZ"(%cst_10) %3 : !quantum.bit
    %out_qubits_24 = quantum.custom "Hadamard"() %out_qubits_23 : !quantum.bit
    %out_qubits_25 = quantum.custom "RZ"(%cst_9) %out_qubits_24 : !quantum.bit
    %out_qubits_26 = quantum.custom "Hadamard"() %out_qubits_25 : !quantum.bit
    %out_qubits_27:2 = quantum.custom "CZ"() %out_qubits_22#0, %out_qubits_26 : !quantum.bit, !quantum.bit
    %out_qubits_28 = quantum.custom "Hadamard"() %out_qubits_27#1 : !quantum.bit
    %out_qubits_29 = quantum.custom "RZ"(%cst_11) %out_qubits_28 : !quantum.bit
    %out_qubits_30 = quantum.custom "Hadamard"() %out_qubits_29 : !quantum.bit
    %out_qubits_31:2 = quantum.custom "CZ"() %out_qubits_27#0, %out_qubits_30 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_32 = quantum.custom "RZ"(%cst_10) %4 : !quantum.bit
    %out_qubits_33 = quantum.custom "Hadamard"() %out_qubits_32 : !quantum.bit
    %out_qubits_34 = quantum.custom "RZ"(%cst_9) %out_qubits_33 : !quantum.bit
    %out_qubits_35 = quantum.custom "Hadamard"() %out_qubits_34 : !quantum.bit
    %out_qubits_36:2 = quantum.custom "CZ"() %out_qubits_31#0, %out_qubits_35 : !quantum.bit, !quantum.bit
    %out_qubits_37 = quantum.custom "Hadamard"() %out_qubits_36#1 : !quantum.bit
    %out_qubits_38 = quantum.custom "RZ"(%cst_11) %out_qubits_37 : !quantum.bit
    %out_qubits_39 = quantum.custom "Hadamard"() %out_qubits_38 : !quantum.bit
    %out_qubits_40:2 = quantum.custom "CZ"() %out_qubits_36#0, %out_qubits_39 : !quantum.bit, !quantum.bit
    %out_qubits_41 = quantum.custom "RZ"(%cst_10) %out_qubits_40#0 : !quantum.bit
    %out_qubits_42 = quantum.custom "Hadamard"() %out_qubits_41 : !quantum.bit
    %out_qubits_43 = quantum.custom "RZ"(%cst_9) %out_qubits_42 : !quantum.bit
    %out_qubits_44 = quantum.custom "Hadamard"() %out_qubits_22#1 : !quantum.bit
    %out_qubits_45:2 = quantum.custom "CZ"() %out_qubits_44, %out_qubits_31#1 : !quantum.bit, !quantum.bit
    %out_qubits_46 = quantum.custom "Hadamard"() %out_qubits_45#1 : !quantum.bit
    %out_qubits_47 = quantum.custom "RZ"(%cst_11) %out_qubits_46 : !quantum.bit
    %out_qubits_48 = quantum.custom "Hadamard"() %out_qubits_47 : !quantum.bit
    %out_qubits_49:2 = quantum.custom "CZ"() %out_qubits_45#0, %out_qubits_48 : !quantum.bit, !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits_49#0, %out_qubits_40#1 : !quantum.bit, !quantum.bit
    %out_qubits_51 = quantum.custom "Hadamard"() %out_qubits_50#1 : !quantum.bit
    %out_qubits_52 = quantum.custom "RZ"(%cst_11) %out_qubits_51 : !quantum.bit
    %out_qubits_53 = quantum.custom "Hadamard"() %out_qubits_52 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_50#0, %out_qubits_53 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "RZ"(%cst_10) %out_qubits_54#0 : !quantum.bit
    %out_qubits_56 = quantum.custom "Hadamard"() %out_qubits_55 : !quantum.bit
    %out_qubits_57 = quantum.custom "RZ"(%cst_9) %out_qubits_56 : !quantum.bit
    %out_qubits_58 = quantum.custom "Hadamard"() %out_qubits_57 : !quantum.bit
    %out_qubits_59:2 = quantum.custom "CZ"() %out_qubits_43, %out_qubits_58 : !quantum.bit, !quantum.bit
    %out_qubits_60 = quantum.custom "Hadamard"() %out_qubits_59#1 : !quantum.bit
    %out_qubits_61 = quantum.custom "RZ"(%cst_11) %out_qubits_60 : !quantum.bit
    %out_qubits_62 = quantum.custom "Hadamard"() %out_qubits_61 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_59#0, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Hadamard"() %out_qubits_49#1 : !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_64, %out_qubits_54#1 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "Hadamard"() %out_qubits_65#1 : !quantum.bit
    %out_qubits_67 = quantum.custom "RZ"(%cst_11) %out_qubits_66 : !quantum.bit
    %out_qubits_68 = quantum.custom "Hadamard"() %out_qubits_67 : !quantum.bit
    %out_qubits_69:2 = quantum.custom "CZ"() %out_qubits_65#0, %out_qubits_68 : !quantum.bit, !quantum.bit
    %out_qubits_70 = quantum.custom "RZ"(%cst_10) %out_qubits_69#0 : !quantum.bit
    %out_qubits_71 = quantum.custom "Hadamard"() %out_qubits_70 : !quantum.bit
    %out_qubits_72 = quantum.custom "RZ"(%cst_9) %out_qubits_71 : !quantum.bit
    %out_qubits_73 = quantum.custom "Hadamard"() %out_qubits_72 : !quantum.bit
    %out_qubits_74:2 = quantum.custom "CZ"() %out_qubits_63#0, %out_qubits_73 : !quantum.bit, !quantum.bit
    %out_qubits_75 = quantum.custom "Hadamard"() %out_qubits_74#1 : !quantum.bit
    %out_qubits_76 = quantum.custom "RZ"(%cst_11) %out_qubits_75 : !quantum.bit
    %out_qubits_77 = quantum.custom "Hadamard"() %out_qubits_76 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_74#0, %out_qubits_77 : !quantum.bit, !quantum.bit
    %out_qubits_79 = quantum.custom "Hadamard"() %out_qubits_69#1 : !quantum.bit
    %out_qubits_80 = quantum.custom "RZ"(%cst_10) %out_qubits_79 : !quantum.bit
    %out_qubits_81 = quantum.custom "Hadamard"() %out_qubits_80 : !quantum.bit
    %out_qubits_82 = quantum.custom "RZ"(%cst_9) %out_qubits_81 : !quantum.bit
    %out_qubits_83 = quantum.custom "Hadamard"() %out_qubits_82 : !quantum.bit
    %out_qubits_84:2 = quantum.custom "CZ"() %out_qubits_78#0, %out_qubits_83 : !quantum.bit, !quantum.bit
    %out_qubits_85 = quantum.custom "Hadamard"() %out_qubits_84#1 : !quantum.bit
    %out_qubits_86 = quantum.custom "RZ"(%cst_11) %out_qubits_85 : !quantum.bit
    %out_qubits_87 = quantum.custom "Hadamard"() %out_qubits_86 : !quantum.bit
    %out_qubits_88:2 = quantum.custom "CZ"() %out_qubits_84#0, %out_qubits_87 : !quantum.bit, !quantum.bit
    %out_qubits_89 = quantum.custom "RZ"(%cst_8) %out_qubits_88#0 : !quantum.bit
    %out_qubits_90 = quantum.custom "Hadamard"() %out_qubits_89 : !quantum.bit
    %out_qubits_91 = quantum.custom "RZ"(%cst_7) %out_qubits_90 : !quantum.bit
    %out_qubits_92 = quantum.custom "Hadamard"() %out_qubits_91 : !quantum.bit
    %out_qubits_93 = quantum.custom "RZ"(%cst_6) %out_qubits_92 : !quantum.bit
    %out_qubits_94 = quantum.custom "Hadamard"() %out_qubits_63#1 : !quantum.bit
    %out_qubits_95:2 = quantum.custom "CZ"() %out_qubits_94, %out_qubits_78#1 : !quantum.bit, !quantum.bit
    %out_qubits_96 = quantum.custom "Hadamard"() %out_qubits_95#1 : !quantum.bit
    %out_qubits_97 = quantum.custom "RZ"(%cst_11) %out_qubits_96 : !quantum.bit
    %out_qubits_98 = quantum.custom "Hadamard"() %out_qubits_97 : !quantum.bit
    %out_qubits_99:2 = quantum.custom "CZ"() %out_qubits_95#0, %out_qubits_98 : !quantum.bit, !quantum.bit
    %out_qubits_100:2 = quantum.custom "CZ"() %out_qubits_99#0, %out_qubits_88#1 : !quantum.bit, !quantum.bit
    %out_qubits_101 = quantum.custom "Hadamard"() %out_qubits_100#1 : !quantum.bit
    %out_qubits_102 = quantum.custom "RZ"(%cst_11) %out_qubits_101 : !quantum.bit
    %out_qubits_103 = quantum.custom "Hadamard"() %out_qubits_102 : !quantum.bit
    %out_qubits_104:2 = quantum.custom "CZ"() %out_qubits_100#0, %out_qubits_103 : !quantum.bit, !quantum.bit
    %out_qubits_105 = quantum.custom "RZ"(%cst_8) %out_qubits_104#0 : !quantum.bit
    %out_qubits_106 = quantum.custom "Hadamard"() %out_qubits_105 : !quantum.bit
    %out_qubits_107 = quantum.custom "RZ"(%cst_5) %out_qubits_106 : !quantum.bit
    %out_qubits_108 = quantum.custom "Hadamard"() %out_qubits_107 : !quantum.bit
    %out_qubits_109 = quantum.custom "RZ"(%cst_6) %out_qubits_108 : !quantum.bit
    %out_qubits_110 = quantum.custom "Hadamard"() %out_qubits_99#1 : !quantum.bit
    %out_qubits_111:2 = quantum.custom "CZ"() %out_qubits_110, %out_qubits_104#1 : !quantum.bit, !quantum.bit
    %out_qubits_112 = quantum.custom "Hadamard"() %out_qubits_111#1 : !quantum.bit
    %out_qubits_113 = quantum.custom "RZ"(%cst_11) %out_qubits_112 : !quantum.bit
    %out_qubits_114 = quantum.custom "Hadamard"() %out_qubits_113 : !quantum.bit
    %out_qubits_115:2 = quantum.custom "CZ"() %out_qubits_111#0, %out_qubits_114 : !quantum.bit, !quantum.bit
    %out_qubits_116 = quantum.custom "RZ"(%cst_8) %out_qubits_115#0 : !quantum.bit
    %out_qubits_117 = quantum.custom "Hadamard"() %out_qubits_116 : !quantum.bit
    %out_qubits_118 = quantum.custom "RZ"(%cst_4) %out_qubits_117 : !quantum.bit
    %out_qubits_119 = quantum.custom "Hadamard"() %out_qubits_118 : !quantum.bit
    %out_qubits_120 = quantum.custom "RZ"(%cst_6) %out_qubits_119 : !quantum.bit
    %out_qubits_121 = quantum.custom "Hadamard"() %out_qubits_115#1 : !quantum.bit
    %out_qubits_122 = quantum.custom "RZ"(%cst_8) %out_qubits_121 : !quantum.bit
    %out_qubits_123 = quantum.custom "Hadamard"() %out_qubits_122 : !quantum.bit
    %out_qubits_124 = quantum.custom "RZ"(%cst_3) %out_qubits_123 : !quantum.bit
    %out_qubits_125 = quantum.custom "Hadamard"() %out_qubits_124 : !quantum.bit
    %out_qubits_126 = quantum.custom "RZ"(%cst_6) %out_qubits_125 : !quantum.bit
    %out_qubits_127 = quantum.custom "Hadamard"() %out_qubits_126 : !quantum.bit
    %out_qubits_128:2 = quantum.custom "CZ"() %out_qubits_120, %out_qubits_127 : !quantum.bit, !quantum.bit
    %out_qubits_129 = quantum.custom "Hadamard"() %out_qubits_128#0 : !quantum.bit
    %out_qubits_130:2 = quantum.custom "CZ"() %out_qubits_109, %out_qubits_129 : !quantum.bit, !quantum.bit
    %out_qubits_131 = quantum.custom "Hadamard"() %out_qubits_130#0 : !quantum.bit
    %out_qubits_132:2 = quantum.custom "CZ"() %out_qubits_93, %out_qubits_131 : !quantum.bit, !quantum.bit
    %out_qubits_133 = quantum.custom "RZ"(%cst_8) %out_qubits_132#0 : !quantum.bit
    %out_qubits_134 = quantum.custom "Hadamard"() %out_qubits_133 : !quantum.bit
    %out_qubits_135 = quantum.custom "RZ"(%cst_2) %out_qubits_134 : !quantum.bit
    %out_qubits_136 = quantum.custom "Hadamard"() %out_qubits_135 : !quantum.bit
    %out_qubits_137 = quantum.custom "RZ"(%cst_6) %out_qubits_136 : !quantum.bit
    %out_qubits_138 = quantum.custom "Hadamard"() %out_qubits_132#1 : !quantum.bit
    %out_qubits_139 = quantum.custom "RZ"(%cst_8) %out_qubits_138 : !quantum.bit
    %out_qubits_140 = quantum.custom "Hadamard"() %out_qubits_139 : !quantum.bit
    %out_qubits_141 = quantum.custom "RZ"(%cst_1) %out_qubits_140 : !quantum.bit
    %out_qubits_142 = quantum.custom "Hadamard"() %out_qubits_141 : !quantum.bit
    %out_qubits_143 = quantum.custom "RZ"(%cst_6) %out_qubits_142 : !quantum.bit
    %out_qubits_144 = quantum.custom "Hadamard"() %out_qubits_130#1 : !quantum.bit
    %out_qubits_145 = quantum.custom "RZ"(%cst_8) %out_qubits_144 : !quantum.bit
    %out_qubits_146 = quantum.custom "Hadamard"() %out_qubits_145 : !quantum.bit
    %out_qubits_147 = quantum.custom "RZ"(%cst_0) %out_qubits_146 : !quantum.bit
    %out_qubits_148 = quantum.custom "Hadamard"() %out_qubits_147 : !quantum.bit
    %out_qubits_149 = quantum.custom "RZ"(%cst_6) %out_qubits_148 : !quantum.bit
    %out_qubits_150 = quantum.custom "Hadamard"() %out_qubits_128#1 : !quantum.bit
    %out_qubits_151 = quantum.custom "RZ"(%cst_8) %out_qubits_150 : !quantum.bit
    %out_qubits_152 = quantum.custom "Hadamard"() %out_qubits_151 : !quantum.bit
    %out_qubits_153 = quantum.custom "RZ"(%cst) %out_qubits_152 : !quantum.bit
    %out_qubits_154 = quantum.custom "Hadamard"() %out_qubits_153 : !quantum.bit
    %out_qubits_155 = quantum.custom "RZ"(%cst_6) %out_qubits_154 : !quantum.bit
    %5 = quantum.compbasis qubits %out_qubits_137, %out_qubits_143, %out_qubits_149, %out_qubits_155 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_137 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_143 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_149 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_155 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}