module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -3.1415926535897931 : f64
    %cst_0 = arith.constant -62.831853071795912 : f64
    %cst_1 = arith.constant 4.5160394395353274 : f64
    %cst_2 = arith.constant 3.9269908169872414 : f64
    %cst_3 = arith.constant 4.3196898986859651 : f64
    %cst_4 = arith.constant 1.570796326794897 : f64
    %cst_5 = arith.constant 0.19634954084936121 : f64
    %cst_6 = arith.constant -1.5707963267948966 : f64
    %cst_7 = arith.constant 0.3926990816987232 : f64
    %cst_8 = arith.constant 0.39269908169872436 : f64
    %cst_9 = arith.constant -1.5707963267948963 : f64
    %cst_10 = arith.constant 0.78539816339744783 : f64
    %cst_11 = arith.constant -4.7123889803846897 : f64
    %cst_12 = arith.constant 0.78539816339744839 : f64
    %cst_13 = arith.constant 4.7123889803846897 : f64
    %cst_14 = arith.constant 0.000000e+00 : f64
    %cst_15 = arith.constant 1.5707963267948966 : f64
    %cst_16 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %1 : !quantum.bit
    %2 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_17 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %2 : !quantum.bit
    %out_qubits_18:2 = quantum.custom "CZ"() %out_qubits_17, %out_qubits : !quantum.bit, !quantum.bit
    %out_qubits_19 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_15) %out_qubits_18#1 : !quantum.bit
    %out_qubits_20:2 = quantum.custom "CZ"() %out_qubits_18#0, %out_qubits_19 : !quantum.bit, !quantum.bit
    %out_qubits_21 = quantum.custom "Rot"(%cst_11, %cst_10, %cst_9) %out_qubits_20#1 : !quantum.bit
    %3 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_22 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %3 : !quantum.bit
    %out_qubits_23:2 = quantum.custom "CZ"() %out_qubits_20#0, %out_qubits_22 : !quantum.bit, !quantum.bit
    %out_qubits_24 = quantum.custom "Rot"(%cst_13, %cst_8, %cst_15) %out_qubits_23#1 : !quantum.bit
    %out_qubits_25:2 = quantum.custom "CZ"() %out_qubits_23#0, %out_qubits_24 : !quantum.bit, !quantum.bit
    %out_qubits_26 = quantum.custom "Rot"(%cst_11, %cst_7, %cst_6) %out_qubits_25#1 : !quantum.bit
    %out_qubits_27:2 = quantum.custom "CZ"() %out_qubits_21, %out_qubits_26 : !quantum.bit, !quantum.bit
    %out_qubits_28 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_15) %out_qubits_27#1 : !quantum.bit
    %out_qubits_29:2 = quantum.custom "CZ"() %out_qubits_27#0, %out_qubits_28 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits_30 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %4 : !quantum.bit
    %out_qubits_31:2 = quantum.custom "CZ"() %out_qubits_25#0, %out_qubits_30 : !quantum.bit, !quantum.bit
    %out_qubits_32 = quantum.custom "Rot"(%cst_13, %cst_5, %cst_4) %out_qubits_31#1 : !quantum.bit
    %out_qubits_33:2 = quantum.custom "CZ"() %out_qubits_31#0, %out_qubits_32 : !quantum.bit, !quantum.bit
    %out_qubits_34 = quantum.custom "Rot"(%cst_15, %cst_5, %cst_13) %out_qubits_33#1 : !quantum.bit
    %out_qubits_35:2 = quantum.custom "CZ"() %out_qubits_29#0, %out_qubits_34 : !quantum.bit, !quantum.bit
    %out_qubits_36 = quantum.custom "Rot"(%cst_13, %cst_8, %cst_15) %out_qubits_35#1 : !quantum.bit
    %out_qubits_37:2 = quantum.custom "CZ"() %out_qubits_35#0, %out_qubits_36 : !quantum.bit, !quantum.bit
    %out_qubits_38 = quantum.custom "Rot"(%cst_3, %cst_15, %cst_14) %out_qubits_37#0 : !quantum.bit
    %out_qubits_39 = quantum.custom "Rot"(%cst_11, %cst_10, %cst_9) %out_qubits_29#1 : !quantum.bit
    %out_qubits_40 = quantum.custom "Rot"(%cst_11, %cst_7, %cst_6) %out_qubits_37#1 : !quantum.bit
    %out_qubits_41:2 = quantum.custom "CZ"() %out_qubits_39, %out_qubits_40 : !quantum.bit, !quantum.bit
    %out_qubits_42 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_15) %out_qubits_41#1 : !quantum.bit
    %out_qubits_43:2 = quantum.custom "CZ"() %out_qubits_41#0, %out_qubits_42 : !quantum.bit, !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_43#0, %out_qubits_38 : !quantum.bit, !quantum.bit
    %out_qubits_45 = quantum.custom "Rot"(%cst_2, %cst_15, %cst_14) %out_qubits_44#0 : !quantum.bit
    %out_qubits_46 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_44#1 : !quantum.bit
    %out_qubits_47:2 = quantum.custom "CZ"() %out_qubits_46, %out_qubits_45 : !quantum.bit, !quantum.bit
    %out_qubits_48 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_47#1 : !quantum.bit
    %out_qubits_49 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_47#0 : !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits_48, %out_qubits_49 : !quantum.bit, !quantum.bit
    %out_qubits_51 = quantum.custom "Hadamard"() %out_qubits_50#1 : !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_1, %cst_15, %cst_14) %out_qubits_33#0 : !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_11, %cst_10, %cst_9) %out_qubits_43#1 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_53, %out_qubits_52 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_54#0 : !quantum.bit
    %out_qubits_56 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_54#1 : !quantum.bit
    %out_qubits_57:2 = quantum.custom "CZ"() %out_qubits_56, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_58 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_57#1 : !quantum.bit
    %out_qubits_59 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_57#0 : !quantum.bit
    %out_qubits_60:2 = quantum.custom "CZ"() %out_qubits_58, %out_qubits_59 : !quantum.bit, !quantum.bit
    %out_qubits_61 = quantum.custom "Hadamard"() %out_qubits_60#1 : !quantum.bit
    quantum.gphase(%cst_0)
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_60#0, %out_qubits_50#0, %out_qubits_51, %out_qubits_61 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_60#0 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_50#0 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_51 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_61 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}