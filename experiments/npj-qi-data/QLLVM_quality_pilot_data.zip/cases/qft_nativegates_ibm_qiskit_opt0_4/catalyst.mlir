module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 0.78539816339744828 : f64
    %cst_0 = arith.constant 0.000000e+00 : f64
    %cst_1 = arith.constant -0.19634954084936207 : f64
    %cst_2 = arith.constant 0.19634954084936207 : f64
    %cst_3 = arith.constant -0.39269908169872414 : f64
    %cst_4 = arith.constant 0.39269908169872414 : f64
    %cst_5 = arith.constant -0.78539816339744828 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Hadamard"() %1 : !quantum.bit
    %2 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_6 = quantum.custom "RZ"(%cst_0) %2 : !quantum.bit
    %out_qubits_7 = quantum.custom "Hadamard"() %out_qubits_6 : !quantum.bit
    %out_qubits_8 = quantum.custom "RZ"(%cst) %out_qubits_7 : !quantum.bit
    %out_qubits_9:2 = quantum.custom "CZ"() %out_qubits_8, %out_qubits : !quantum.bit, !quantum.bit
    %out_qubits_10 = quantum.custom "Hadamard"() %out_qubits_9#1 : !quantum.bit
    %out_qubits_11 = quantum.custom "RZ"(%cst_5) %out_qubits_10 : !quantum.bit
    %out_qubits_12 = quantum.custom "Hadamard"() %out_qubits_11 : !quantum.bit
    %out_qubits_13:2 = quantum.custom "CZ"() %out_qubits_9#0, %out_qubits_12 : !quantum.bit, !quantum.bit
    %out_qubits_14 = quantum.custom "Hadamard"() %out_qubits_13#1 : !quantum.bit
    %out_qubits_15 = quantum.custom "RZ"(%cst) %out_qubits_14 : !quantum.bit
    %out_qubits_16 = quantum.custom "Hadamard"() %out_qubits_15 : !quantum.bit
    %out_qubits_17 = quantum.custom "RZ"(%cst) %out_qubits_16 : !quantum.bit
    %3 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_18 = quantum.custom "Hadamard"() %3 : !quantum.bit
    %out_qubits_19 = quantum.custom "RZ"(%cst_4) %out_qubits_13#0 : !quantum.bit
    %out_qubits_20:2 = quantum.custom "CZ"() %out_qubits_19, %out_qubits_18 : !quantum.bit, !quantum.bit
    %out_qubits_21 = quantum.custom "Hadamard"() %out_qubits_20#1 : !quantum.bit
    %out_qubits_22 = quantum.custom "RZ"(%cst_3) %out_qubits_21 : !quantum.bit
    %out_qubits_23 = quantum.custom "Hadamard"() %out_qubits_22 : !quantum.bit
    %out_qubits_24:2 = quantum.custom "CZ"() %out_qubits_20#0, %out_qubits_23 : !quantum.bit, !quantum.bit
    %out_qubits_25 = quantum.custom "Hadamard"() %out_qubits_24#1 : !quantum.bit
    %out_qubits_26 = quantum.custom "RZ"(%cst_4) %out_qubits_25 : !quantum.bit
    %out_qubits_27 = quantum.custom "Hadamard"() %out_qubits_26 : !quantum.bit
    %out_qubits_28:2 = quantum.custom "CZ"() %out_qubits_17, %out_qubits_27 : !quantum.bit, !quantum.bit
    %out_qubits_29 = quantum.custom "Hadamard"() %out_qubits_28#1 : !quantum.bit
    %out_qubits_30 = quantum.custom "RZ"(%cst_5) %out_qubits_29 : !quantum.bit
    %out_qubits_31 = quantum.custom "Hadamard"() %out_qubits_30 : !quantum.bit
    %out_qubits_32:2 = quantum.custom "CZ"() %out_qubits_28#0, %out_qubits_31 : !quantum.bit, !quantum.bit
    %out_qubits_33 = quantum.custom "Hadamard"() %out_qubits_32#1 : !quantum.bit
    %out_qubits_34 = quantum.custom "RZ"(%cst) %out_qubits_33 : !quantum.bit
    %out_qubits_35 = quantum.custom "Hadamard"() %out_qubits_34 : !quantum.bit
    %out_qubits_36 = quantum.custom "RZ"(%cst) %out_qubits_35 : !quantum.bit
    %out_qubits_37 = quantum.custom "RZ"(%cst_4) %out_qubits_32#0 : !quantum.bit
    %4 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits_38 = quantum.custom "Hadamard"() %4 : !quantum.bit
    %out_qubits_39 = quantum.custom "RZ"(%cst_2) %out_qubits_24#0 : !quantum.bit
    %out_qubits_40:2 = quantum.custom "CZ"() %out_qubits_39, %out_qubits_38 : !quantum.bit, !quantum.bit
    %out_qubits_41 = quantum.custom "Hadamard"() %out_qubits_40#1 : !quantum.bit
    %out_qubits_42 = quantum.custom "RZ"(%cst_1) %out_qubits_41 : !quantum.bit
    %out_qubits_43 = quantum.custom "Hadamard"() %out_qubits_42 : !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_40#0, %out_qubits_43 : !quantum.bit, !quantum.bit
    %out_qubits_45 = quantum.custom "Hadamard"() %out_qubits_44#1 : !quantum.bit
    %out_qubits_46 = quantum.custom "RZ"(%cst_2) %out_qubits_45 : !quantum.bit
    %out_qubits_47 = quantum.custom "Hadamard"() %out_qubits_46 : !quantum.bit
    %out_qubits_48:2 = quantum.custom "CZ"() %out_qubits_37, %out_qubits_47 : !quantum.bit, !quantum.bit
    %out_qubits_49 = quantum.custom "Hadamard"() %out_qubits_48#1 : !quantum.bit
    %out_qubits_50 = quantum.custom "RZ"(%cst_3) %out_qubits_49 : !quantum.bit
    %out_qubits_51 = quantum.custom "Hadamard"() %out_qubits_50 : !quantum.bit
    %out_qubits_52:2 = quantum.custom "CZ"() %out_qubits_48#0, %out_qubits_51 : !quantum.bit, !quantum.bit
    %out_qubits_53 = quantum.custom "Hadamard"() %out_qubits_52#1 : !quantum.bit
    %out_qubits_54 = quantum.custom "RZ"(%cst_4) %out_qubits_53 : !quantum.bit
    %out_qubits_55 = quantum.custom "Hadamard"() %out_qubits_54 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_36, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "Hadamard"() %out_qubits_56#1 : !quantum.bit
    %out_qubits_58 = quantum.custom "RZ"(%cst_5) %out_qubits_57 : !quantum.bit
    %out_qubits_59 = quantum.custom "Hadamard"() %out_qubits_58 : !quantum.bit
    %out_qubits_60:2 = quantum.custom "CZ"() %out_qubits_56#0, %out_qubits_59 : !quantum.bit, !quantum.bit
    %out_qubits_61 = quantum.custom "Hadamard"() %out_qubits_52#0 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_60#0, %out_qubits_61 : !quantum.bit, !quantum.bit
    %out_qubits_63 = quantum.custom "Hadamard"() %out_qubits_62#0 : !quantum.bit
    %out_qubits_64 = quantum.custom "Hadamard"() %out_qubits_62#1 : !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_64, %out_qubits_63 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "Hadamard"() %out_qubits_65#1 : !quantum.bit
    %out_qubits_67 = quantum.custom "Hadamard"() %out_qubits_65#0 : !quantum.bit
    %out_qubits_68:2 = quantum.custom "CZ"() %out_qubits_66, %out_qubits_67 : !quantum.bit, !quantum.bit
    %out_qubits_69 = quantum.custom "Hadamard"() %out_qubits_68#1 : !quantum.bit
    %out_qubits_70 = quantum.custom "Hadamard"() %out_qubits_60#1 : !quantum.bit
    %out_qubits_71 = quantum.custom "RZ"(%cst) %out_qubits_70 : !quantum.bit
    %out_qubits_72 = quantum.custom "Hadamard"() %out_qubits_71 : !quantum.bit
    %out_qubits_73 = quantum.custom "RZ"(%cst_0) %out_qubits_72 : !quantum.bit
    %out_qubits_74 = quantum.custom "Hadamard"() %out_qubits_44#0 : !quantum.bit
    %out_qubits_75:2 = quantum.custom "CZ"() %out_qubits_73, %out_qubits_74 : !quantum.bit, !quantum.bit
    %out_qubits_76 = quantum.custom "Hadamard"() %out_qubits_75#0 : !quantum.bit
    %out_qubits_77 = quantum.custom "Hadamard"() %out_qubits_75#1 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_77, %out_qubits_76 : !quantum.bit, !quantum.bit
    %out_qubits_79 = quantum.custom "Hadamard"() %out_qubits_78#1 : !quantum.bit
    %out_qubits_80 = quantum.custom "Hadamard"() %out_qubits_78#0 : !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_79, %out_qubits_80 : !quantum.bit, !quantum.bit
    %out_qubits_82 = quantum.custom "Hadamard"() %out_qubits_81#1 : !quantum.bit
    %5 = quantum.compbasis qubits %out_qubits_81#0, %out_qubits_68#0, %out_qubits_69, %out_qubits_82 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_81#0 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_68#0 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_69 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_82 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}