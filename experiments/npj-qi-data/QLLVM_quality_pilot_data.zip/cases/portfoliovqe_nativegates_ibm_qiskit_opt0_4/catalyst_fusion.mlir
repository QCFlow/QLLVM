module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -163.36281798666897 : f64
    %cst_0 = arith.constant 1.4554565535713047 : f64
    %cst_1 = arith.constant 6.2831853071795871 : f64
    %cst_2 = arith.constant 2.6376491569121621 : f64
    %cst_3 = arith.constant 1.1102230246251565E-15 : f64
    %cst_4 = arith.constant 9.4247779607693793 : f64
    %cst_5 = arith.constant 2.6840591122070832 : f64
    %cst_6 = arith.constant 9.4247779607693686 : f64
    %cst_7 = arith.constant 3.0928616644555467 : f64
    %cst_8 = arith.constant -1.5707963267949081 : f64
    %cst_9 = arith.constant 3.1415926535897829 : f64
    %cst_10 = arith.constant 3.0786004564569263 : f64
    %cst_11 = arith.constant -3.1415926535898024 : f64
    %cst_12 = arith.constant 3.1415926535897931 : f64
    %cst_13 = arith.constant 1.8833398101823027 : f64
    %cst_14 = arith.constant -3.1415926535897931 : f64
    %cst_15 = arith.constant -3.1415926535897936 : f64
    %cst_16 = arith.constant 0.71381745491974202 : f64
    %cst_17 = arith.constant 3.1415926535897927 : f64
    %cst_18 = arith.constant 0.14503168515743253 : f64
    %cst_19 = arith.constant 4.7123889803846888 : f64
    %cst_20 = arith.constant 6.2831853071795853 : f64
    %cst_21 = arith.constant 2.4217330946376951 : f64
    %cst_22 = arith.constant -8.8817841970012523E-16 : f64
    %cst_23 = arith.constant 1.788267827975027 : f64
    %cst_24 = arith.constant -4.4408920985006262E-16 : f64
    %cst_25 = arith.constant 3.1415926535897913 : f64
    %cst_26 = arith.constant 2.7836526343107377 : f64
    %cst_27 = arith.constant 1.5707963267948966 : f64
    %cst_28 = arith.constant 4.7123889803846897 : f64
    %cst_29 = arith.constant -1.5707963267948968 : f64
    %cst_30 = arith.constant 0.081111021558120027 : f64
    %cst_31 = arith.constant 1.5707963267948963 : f64
    %cst_32 = arith.constant 4.4936207202032064 : f64
    %cst_33 = arith.constant 1.9984014443252818E-15 : f64
    %cst_34 = arith.constant 6.2831853071795862 : f64
    %cst_35 = arith.constant 1.0176360310545978 : f64
    %cst_36 = arith.constant 0.000000e+00 : f64
    %cst_37 = arith.constant 4.4408920985006262E-16 : f64
    %cst_38 = arith.constant 0.29848076836031506 : f64
    %cst_39 = arith.constant 6.2831853071795845 : f64
    %cst_40 = arith.constant 1.5707963267948968 : f64
    %cst_41 = arith.constant 0.33501927355938632 : f64
    %cst_42 = arith.constant -3.141592653589794 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_42, %cst_41, %cst_40) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_43 = quantum.custom "Rot"(%cst_39, %cst_38, %cst_37) %2 : !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_43 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_45 = quantum.custom "Rot"(%cst_36, %cst_35, %cst_34) %3 : !quantum.bit
    %out_qubits_46:2 = quantum.custom "CZ"() %out_qubits_44#0, %out_qubits_45 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_47 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_36) %4 : !quantum.bit
    %out_qubits_48:2 = quantum.custom "CZ"() %out_qubits_46#0, %out_qubits_47 : !quantum.bit, !quantum.bit
    %out_qubits_49 = quantum.custom "Rot"(%cst_31, %cst_30, %cst_29) %out_qubits_48#0 : !quantum.bit
    %out_qubits_50 = quantum.custom "Rot"(%cst_28, %cst_36, %cst_27) %out_qubits_44#1 : !quantum.bit
    %out_qubits_51 = quantum.custom "Rot"(%cst_29, %cst_36, %cst_31) %out_qubits_46#1 : !quantum.bit
    %out_qubits_52:2 = quantum.custom "CZ"() %out_qubits_50, %out_qubits_51 : !quantum.bit, !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_29, %cst_36, %cst_31) %out_qubits_48#1 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_52#0, %out_qubits_53 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_42, %cst_26, %cst_25) %out_qubits_54#0 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_49, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_28, %cst_36, %cst_27) %out_qubits_52#1 : !quantum.bit
    %out_qubits_58 = quantum.custom "Rot"(%cst_29, %cst_36, %cst_31) %out_qubits_54#1 : !quantum.bit
    %out_qubits_59:2 = quantum.custom "CZ"() %out_qubits_57, %out_qubits_58 : !quantum.bit, !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_24, %cst_23, %cst_34) %out_qubits_59#0 : !quantum.bit
    %out_qubits_61:2 = quantum.custom "CZ"() %out_qubits_56#0, %out_qubits_60 : !quantum.bit, !quantum.bit
    %out_qubits_62 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_59#1 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_61#0, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Rot"(%cst_19, %cst_18, %cst_40) %out_qubits_63#0 : !quantum.bit
    %out_qubits_65 = quantum.custom "Rot"(%cst_28, %cst_36, %cst_27) %out_qubits_56#1 : !quantum.bit
    %out_qubits_66 = quantum.custom "Rot"(%cst_29, %cst_36, %cst_31) %out_qubits_61#1 : !quantum.bit
    %out_qubits_67:2 = quantum.custom "CZ"() %out_qubits_65, %out_qubits_66 : !quantum.bit, !quantum.bit
    %out_qubits_68 = quantum.custom "Rot"(%cst_29, %cst_36, %cst_31) %out_qubits_63#1 : !quantum.bit
    %out_qubits_69:2 = quantum.custom "CZ"() %out_qubits_67#0, %out_qubits_68 : !quantum.bit, !quantum.bit
    %out_qubits_70 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %out_qubits_69#0 : !quantum.bit
    %out_qubits_71:2 = quantum.custom "CZ"() %out_qubits_64, %out_qubits_70 : !quantum.bit, !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_28, %cst_36, %cst_27) %out_qubits_67#1 : !quantum.bit
    %out_qubits_73 = quantum.custom "Rot"(%cst_29, %cst_36, %cst_31) %out_qubits_69#1 : !quantum.bit
    %out_qubits_74:2 = quantum.custom "CZ"() %out_qubits_72, %out_qubits_73 : !quantum.bit, !quantum.bit
    %out_qubits_75 = quantum.custom "Rot"(%cst_14, %cst_13, %cst_12) %out_qubits_74#0 : !quantum.bit
    %out_qubits_76:2 = quantum.custom "CZ"() %out_qubits_71#0, %out_qubits_75 : !quantum.bit, !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_11, %cst_10, %cst_9) %out_qubits_74#1 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_76#0, %out_qubits_77 : !quantum.bit, !quantum.bit
    %out_qubits_79 = quantum.custom "Rot"(%cst_8, %cst_7, %cst_6) %out_qubits_78#0 : !quantum.bit
    %out_qubits_80 = quantum.custom "Rot"(%cst_28, %cst_36, %cst_27) %out_qubits_71#1 : !quantum.bit
    %out_qubits_81 = quantum.custom "Rot"(%cst_29, %cst_36, %cst_31) %out_qubits_76#1 : !quantum.bit
    %out_qubits_82:2 = quantum.custom "CZ"() %out_qubits_80, %out_qubits_81 : !quantum.bit, !quantum.bit
    %out_qubits_83 = quantum.custom "Rot"(%cst_29, %cst_36, %cst_31) %out_qubits_78#1 : !quantum.bit
    %out_qubits_84:2 = quantum.custom "CZ"() %out_qubits_82#0, %out_qubits_83 : !quantum.bit, !quantum.bit
    %out_qubits_85 = quantum.custom "Rot"(%cst_42, %cst_5, %cst_4) %out_qubits_84#0 : !quantum.bit
    %out_qubits_86 = quantum.custom "Rot"(%cst_28, %cst_36, %cst_27) %out_qubits_82#1 : !quantum.bit
    %out_qubits_87 = quantum.custom "Rot"(%cst_29, %cst_36, %cst_31) %out_qubits_84#1 : !quantum.bit
    %out_qubits_88:2 = quantum.custom "CZ"() %out_qubits_86, %out_qubits_87 : !quantum.bit, !quantum.bit
    %out_qubits_89 = quantum.custom "Rot"(%cst_3, %cst_2, %cst_1) %out_qubits_88#0 : !quantum.bit
    %out_qubits_90 = quantum.custom "Rot"(%cst_12, %cst_0, %cst_4) %out_qubits_88#1 : !quantum.bit
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_79, %out_qubits_85, %out_qubits_89, %out_qubits_90 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_79 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_85 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_89 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_90 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}