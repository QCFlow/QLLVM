module @circuit {
  func.func public @jit_circuit() -> tensor<128x8xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x8xi64>
    return %0 : tensor<128x8xi64>
  }
  func.func public @circuit_0() -> tensor<128x8xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -144.51326206513028 : f64
    %cst_0 = arith.constant 1.5707963267948968 : f64
    %cst_1 = arith.constant 6.2831853071795862 : f64
    %cst_2 = arith.constant 17.559996726629613 : f64
    %cst_3 = arith.constant 1.8520334586806475 : f64
    %cst_4 = arith.constant -4.7123889803846897 : f64
    %cst_5 = arith.constant 1.5714367923822752 : f64
    %cst_6 = arith.constant 2.2149379011755594 : f64
    %cst_7 = arith.constant 0.6448309816094886 : f64
    %cst_8 = arith.constant 1.5707963267948961 : f64
    %cst_9 = arith.constant 2.4968106136217516 : f64
    %cst_10 = arith.constant -2.4968106136217516 : f64
    %cst_11 = arith.constant 1.5707963267948963 : f64
    %cst_12 = arith.constant 1.8521482104918034 : f64
    %cst_13 = arith.constant -1.5707963267948972 : f64
    %cst_14 = arith.constant 4.7123889803846897 : f64
    %cst_15 = arith.constant 0.000000e+00 : f64
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %cst_17 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 8) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %1 : !quantum.bit
    %2 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_18 = quantum.custom "Rot"(%cst_14, %cst_15, %cst_16) %2 : !quantum.bit
    %out_qubits_19:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_18 : !quantum.bit, !quantum.bit
    %out_qubits_20 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_19#1 : !quantum.bit
    %out_qubits_21:2 = quantum.custom "CZ"() %out_qubits_19#0, %out_qubits_20 : !quantum.bit, !quantum.bit
    %out_qubits_22 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %out_qubits_21#1 : !quantum.bit
    %3 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_23 = quantum.custom "Rot"(%cst_14, %cst_15, %cst_16) %3 : !quantum.bit
    %out_qubits_24:2 = quantum.custom "CZ"() %out_qubits_22, %out_qubits_23 : !quantum.bit, !quantum.bit
    %out_qubits_25 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_24#1 : !quantum.bit
    %out_qubits_26:2 = quantum.custom "CZ"() %out_qubits_24#0, %out_qubits_25 : !quantum.bit, !quantum.bit
    %out_qubits_27 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_10) %out_qubits_26#0 : !quantum.bit
    %4 = quantum.extract %0[ 6] : !quantum.reg -> !quantum.bit
    %out_qubits_28 = quantum.custom "Rot"(%cst_14, %cst_15, %cst_16) %4 : !quantum.bit
    %out_qubits_29:2 = quantum.custom "CZ"() %out_qubits_21#0, %out_qubits_28 : !quantum.bit, !quantum.bit
    %out_qubits_30 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_29#1 : !quantum.bit
    %out_qubits_31:2 = quantum.custom "CZ"() %out_qubits_29#0, %out_qubits_30 : !quantum.bit, !quantum.bit
    %out_qubits_32 = quantum.custom "Rot"(%cst_14, %cst_9, %cst_8) %out_qubits_31#0 : !quantum.bit
    %out_qubits_33:2 = quantum.custom "CZ"() %out_qubits_32, %out_qubits_27 : !quantum.bit, !quantum.bit
    %out_qubits_34 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_16) %out_qubits_33#1 : !quantum.bit
    %out_qubits_35:2 = quantum.custom "CZ"() %out_qubits_33#0, %out_qubits_34 : !quantum.bit, !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_36 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %5 : !quantum.bit
    %6 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_37 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %6 : !quantum.bit
    %7 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_38 = quantum.custom "Rot"(%cst_14, %cst_15, %cst_16) %7 : !quantum.bit
    %out_qubits_39:2 = quantum.custom "CZ"() %out_qubits_37, %out_qubits_38 : !quantum.bit, !quantum.bit
    %out_qubits_40 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_39#1 : !quantum.bit
    %out_qubits_41:2 = quantum.custom "CZ"() %out_qubits_39#0, %out_qubits_40 : !quantum.bit, !quantum.bit
    %out_qubits_42:2 = quantum.custom "CZ"() %out_qubits_36, %out_qubits_41#1 : !quantum.bit, !quantum.bit
    %out_qubits_43 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_42#1 : !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_42#0, %out_qubits_43 : !quantum.bit, !quantum.bit
    %out_qubits_45:2 = quantum.custom "CZ"() %out_qubits_44#0, %out_qubits_31#1 : !quantum.bit, !quantum.bit
    %out_qubits_46 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_45#1 : !quantum.bit
    %out_qubits_47:2 = quantum.custom "CZ"() %out_qubits_45#0, %out_qubits_46 : !quantum.bit, !quantum.bit
    %out_qubits_48 = quantum.custom "Rot"(%cst_6, %cst_15, %cst_5) %out_qubits_47#1 : !quantum.bit
    %out_qubits_49:2 = quantum.custom "CZ"() %out_qubits_35#0, %out_qubits_48 : !quantum.bit, !quantum.bit
    %out_qubits_50 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_16) %out_qubits_49#1 : !quantum.bit
    %out_qubits_51:2 = quantum.custom "CZ"() %out_qubits_49#0, %out_qubits_50 : !quantum.bit, !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_4, %cst_3, %cst_14) %out_qubits_51#0 : !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_14, %cst_9, %cst_8) %out_qubits_47#0 : !quantum.bit
    %out_qubits_54 = quantum.custom "Rot"(%cst_6, %cst_15, %cst_5) %out_qubits_44#1 : !quantum.bit
    %8 = quantum.extract %0[ 7] : !quantum.reg -> !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_14, %cst_15, %cst_16) %8 : !quantum.bit
    %out_qubits_56:2 = quantum.custom "CZ"() %out_qubits_41#0, %out_qubits_55 : !quantum.bit, !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_56#1 : !quantum.bit
    %out_qubits_58:2 = quantum.custom "CZ"() %out_qubits_56#0, %out_qubits_57 : !quantum.bit, !quantum.bit
    %out_qubits_59 = quantum.custom "Rot"(%cst_14, %cst_9, %cst_8) %out_qubits_58#0 : !quantum.bit
    %out_qubits_60:2 = quantum.custom "CZ"() %out_qubits_59, %out_qubits_54 : !quantum.bit, !quantum.bit
    %out_qubits_61 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_16) %out_qubits_60#1 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_60#0, %out_qubits_61 : !quantum.bit, !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_53, %out_qubits_62#1 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_16) %out_qubits_63#1 : !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_63#0, %out_qubits_64 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "Rot"(%cst_2, %cst_16, %cst_1) %out_qubits_65#1 : !quantum.bit
    %out_qubits_67:2 = quantum.custom "CZ"() %out_qubits_65#0, %out_qubits_51#1 : !quantum.bit, !quantum.bit
    %out_qubits_68 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_16) %out_qubits_67#1 : !quantum.bit
    %out_qubits_69:2 = quantum.custom "CZ"() %out_qubits_67#0, %out_qubits_68 : !quantum.bit, !quantum.bit
    %out_qubits_70 = quantum.custom "Rot"(%cst_4, %cst_3, %cst_14) %out_qubits_69#0 : !quantum.bit
    %out_qubits_71 = quantum.custom "Rot"(%cst_2, %cst_16, %cst_1) %out_qubits_69#1 : !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %out_qubits_35#1 : !quantum.bit
    %out_qubits_73 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %out_qubits_26#1 : !quantum.bit
    %out_qubits_74:2 = quantum.custom "CZ"() %out_qubits_73, %out_qubits_58#1 : !quantum.bit, !quantum.bit
    %out_qubits_75 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_74#1 : !quantum.bit
    %out_qubits_76:2 = quantum.custom "CZ"() %out_qubits_74#0, %out_qubits_75 : !quantum.bit, !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_10) %out_qubits_76#0 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_72, %out_qubits_77 : !quantum.bit, !quantum.bit
    %out_qubits_79 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_16) %out_qubits_78#1 : !quantum.bit
    %out_qubits_80:2 = quantum.custom "CZ"() %out_qubits_78#0, %out_qubits_79 : !quantum.bit, !quantum.bit
    %out_qubits_81 = quantum.custom "Rot"(%cst_0, %cst_3, %cst_14) %out_qubits_80#0 : !quantum.bit
    %out_qubits_82 = quantum.custom "Rot"(%cst_6, %cst_15, %cst_5) %out_qubits_76#1 : !quantum.bit
    %out_qubits_83:2 = quantum.custom "CZ"() %out_qubits_62#0, %out_qubits_82 : !quantum.bit, !quantum.bit
    %out_qubits_84 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_16) %out_qubits_83#1 : !quantum.bit
    %out_qubits_85:2 = quantum.custom "CZ"() %out_qubits_83#0, %out_qubits_84 : !quantum.bit, !quantum.bit
    %out_qubits_86 = quantum.custom "Rot"(%cst_4, %cst_3, %cst_14) %out_qubits_85#0 : !quantum.bit
    %out_qubits_87 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %out_qubits_80#1 : !quantum.bit
    %out_qubits_88:2 = quantum.custom "CZ"() %out_qubits_87, %out_qubits_85#1 : !quantum.bit, !quantum.bit
    %out_qubits_89 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_16) %out_qubits_88#1 : !quantum.bit
    %out_qubits_90:2 = quantum.custom "CZ"() %out_qubits_88#0, %out_qubits_89 : !quantum.bit, !quantum.bit
    %out_qubits_91 = quantum.custom "Rot"(%cst_0, %cst_3, %cst_14) %out_qubits_90#0 : !quantum.bit
    %out_qubits_92 = quantum.custom "Rot"(%cst_2, %cst_16, %cst_1) %out_qubits_90#1 : !quantum.bit
    quantum.gphase(%cst)
    %9 = quantum.compbasis qubits %out_qubits_52, %out_qubits_86, %out_qubits_81, %out_qubits_91, %out_qubits_70, %out_qubits_66, %out_qubits_71, %out_qubits_92 : !quantum.obs
    %10 = quantum.sample %9 : tensor<128x8xf64>
    %11 = stablehlo.convert %10 : (tensor<128x8xf64>) -> tensor<128x8xi64>
    %12 = quantum.insert %0[ 0], %out_qubits_52 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 1], %out_qubits_86 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 2], %out_qubits_81 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 3], %out_qubits_91 : !quantum.reg, !quantum.bit
    %16 = quantum.insert %15[ 4], %out_qubits_70 : !quantum.reg, !quantum.bit
    %17 = quantum.insert %16[ 5], %out_qubits_66 : !quantum.reg, !quantum.bit
    %18 = quantum.insert %17[ 6], %out_qubits_71 : !quantum.reg, !quantum.bit
    %19 = quantum.insert %18[ 7], %out_qubits_92 : !quantum.reg, !quantum.bit
    quantum.dealloc %19 : !quantum.reg
    quantum.device_release
    return %11 : tensor<128x8xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}