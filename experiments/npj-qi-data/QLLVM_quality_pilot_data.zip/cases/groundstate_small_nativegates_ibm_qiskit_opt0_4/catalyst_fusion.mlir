module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -131.94689145077115 : f64
    %cst_0 = arith.constant -0.59352982534528209 : f64
    %cst_1 = arith.constant 10.405449844882932 : f64
    %cst_2 = arith.constant 10.996952348363155 : f64
    %cst_3 = arith.constant 6.2831853071795862 : f64
    %cst_4 = arith.constant -1.6134361991188584 : f64
    %cst_5 = arith.constant 6.8384460067081356 : f64
    %cst_6 = arith.constant -1.2905927595412212 : f64
    %cst_7 = arith.constant 1.4570162491738428 : f64
    %cst_8 = arith.constant 1.5707963267948963 : f64
    %cst_9 = arith.constant -1.5707963267948968 : f64
    %cst_10 = arith.constant 4.7123889803846897 : f64
    %cst_11 = arith.constant 1.4180275178025499 : f64
    %cst_12 = arith.constant 7.8860143331452726 : f64
    %cst_13 = arith.constant 0.19841313075081501 : f64
    %cst_14 = arith.constant 1.5344807431906915 : f64
    %cst_15 = arith.constant 0.000000e+00 : f64
    %cst_16 = arith.constant 1.5707963267948966 : f64
    %cst_17 = arith.constant 6.4641188152328573 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_18 = quantum.custom "Rot"(%cst_14, %cst_16, %cst_15) %2 : !quantum.bit
    %out_qubits_19:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_18 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_20 = quantum.custom "Rot"(%cst_13, %cst_16, %cst_15) %3 : !quantum.bit
    %out_qubits_21:2 = quantum.custom "CZ"() %out_qubits_19#0, %out_qubits_20 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_22 = quantum.custom "Rot"(%cst_12, %cst_16, %cst_15) %4 : !quantum.bit
    %out_qubits_23:2 = quantum.custom "CZ"() %out_qubits_21#0, %out_qubits_22 : !quantum.bit, !quantum.bit
    %out_qubits_24 = quantum.custom "Rot"(%cst_11, %cst_16, %cst_15) %out_qubits_23#0 : !quantum.bit
    %out_qubits_25 = quantum.custom "Rot"(%cst_10, %cst_15, %cst_16) %out_qubits_19#1 : !quantum.bit
    %out_qubits_26 = quantum.custom "Rot"(%cst_9, %cst_15, %cst_8) %out_qubits_21#1 : !quantum.bit
    %out_qubits_27:2 = quantum.custom "CZ"() %out_qubits_25, %out_qubits_26 : !quantum.bit, !quantum.bit
    %out_qubits_28 = quantum.custom "Rot"(%cst_9, %cst_15, %cst_8) %out_qubits_23#1 : !quantum.bit
    %out_qubits_29:2 = quantum.custom "CZ"() %out_qubits_27#0, %out_qubits_28 : !quantum.bit, !quantum.bit
    %out_qubits_30 = quantum.custom "Rot"(%cst_7, %cst_16, %cst_15) %out_qubits_29#0 : !quantum.bit
    %out_qubits_31:2 = quantum.custom "CZ"() %out_qubits_24, %out_qubits_30 : !quantum.bit, !quantum.bit
    %out_qubits_32 = quantum.custom "Rot"(%cst_10, %cst_15, %cst_16) %out_qubits_27#1 : !quantum.bit
    %out_qubits_33 = quantum.custom "Rot"(%cst_9, %cst_15, %cst_8) %out_qubits_29#1 : !quantum.bit
    %out_qubits_34:2 = quantum.custom "CZ"() %out_qubits_32, %out_qubits_33 : !quantum.bit, !quantum.bit
    %out_qubits_35 = quantum.custom "Rot"(%cst_6, %cst_16, %cst_15) %out_qubits_34#0 : !quantum.bit
    %out_qubits_36:2 = quantum.custom "CZ"() %out_qubits_31#0, %out_qubits_35 : !quantum.bit, !quantum.bit
    %out_qubits_37 = quantum.custom "Rot"(%cst_5, %cst_16, %cst_15) %out_qubits_34#1 : !quantum.bit
    %out_qubits_38:2 = quantum.custom "CZ"() %out_qubits_36#0, %out_qubits_37 : !quantum.bit, !quantum.bit
    %out_qubits_39 = quantum.custom "Rot"(%cst_4, %cst_16, %cst_3) %out_qubits_38#0 : !quantum.bit
    %out_qubits_40 = quantum.custom "Rot"(%cst_10, %cst_15, %cst_16) %out_qubits_31#1 : !quantum.bit
    %out_qubits_41 = quantum.custom "Rot"(%cst_9, %cst_15, %cst_8) %out_qubits_36#1 : !quantum.bit
    %out_qubits_42:2 = quantum.custom "CZ"() %out_qubits_40, %out_qubits_41 : !quantum.bit, !quantum.bit
    %out_qubits_43 = quantum.custom "Rot"(%cst_9, %cst_15, %cst_8) %out_qubits_38#1 : !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_42#0, %out_qubits_43 : !quantum.bit, !quantum.bit
    %out_qubits_45 = quantum.custom "Rot"(%cst_2, %cst_16, %cst_3) %out_qubits_44#0 : !quantum.bit
    %out_qubits_46 = quantum.custom "Rot"(%cst_10, %cst_15, %cst_16) %out_qubits_42#1 : !quantum.bit
    %out_qubits_47 = quantum.custom "Rot"(%cst_9, %cst_15, %cst_8) %out_qubits_44#1 : !quantum.bit
    %out_qubits_48:2 = quantum.custom "CZ"() %out_qubits_46, %out_qubits_47 : !quantum.bit, !quantum.bit
    %out_qubits_49 = quantum.custom "Rot"(%cst_1, %cst_16, %cst_3) %out_qubits_48#0 : !quantum.bit
    %out_qubits_50 = quantum.custom "Rot"(%cst_0, %cst_16, %cst_3) %out_qubits_48#1 : !quantum.bit
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_39, %out_qubits_45, %out_qubits_49, %out_qubits_50 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_39 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_45 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_49 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_50 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}