module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -1.5707963267948966 : f64
    %cst_0 = arith.constant -10.995574287564276 : f64
    %cst_1 = arith.constant 0.000000e+00 : f64
    %cst_2 = arith.constant 1.5707963267948966 : f64
    %cst_3 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_3, %cst_2, %cst_1) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_4 = quantum.custom "Rot"(%cst_3, %cst_2, %cst_1) %2 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_5 = quantum.custom "Rot"(%cst_3, %cst_2, %cst_1) %3 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_6 = quantum.custom "Rot"(%cst_3, %cst_2, %cst_1) %4 : !quantum.bit
    %out_qubits_7:2 = quantum.custom "CZ"() %out_qubits_6, %out_qubits_5 : !quantum.bit, !quantum.bit
    %out_qubits_8 = quantum.custom "Rot"(%cst_3, %cst_2, %cst_1) %out_qubits_7#1 : !quantum.bit
    %out_qubits_9:2 = quantum.custom "CZ"() %out_qubits_8, %out_qubits_4 : !quantum.bit, !quantum.bit
    %out_qubits_10 = quantum.custom "Rot"(%cst_3, %cst_2, %cst_1) %out_qubits_9#1 : !quantum.bit
    %out_qubits_11:2 = quantum.custom "CZ"() %out_qubits_10, %out_qubits : !quantum.bit, !quantum.bit
    %out_qubits_12 = quantum.custom "Hadamard"() %out_qubits_11#1 : !quantum.bit
    quantum.gphase(%cst_0)
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_12, %out_qubits_11#0, %out_qubits_9#0, %out_qubits_7#0 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_12 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_11#0 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_9#0 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_7#0 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}