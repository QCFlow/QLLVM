module @circuit {
  func.func public @jit_circuit() -> tensor<128x5xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x5xi64>
    return %0 : tensor<128x5xi64>
  }
  func.func public @circuit_0() -> tensor<128x5xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 0.000000e+00 : f64
    %cst_0 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst) %1 : !quantum.bit
    %out_qubits_1 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_2 = quantum.custom "RZ"(%cst) %out_qubits_1 : !quantum.bit
    %out_qubits_3 = quantum.custom "RX"(%cst_0) %out_qubits_2 : !quantum.bit
    %2 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_4 = quantum.custom "RX"(%cst_0) %2 : !quantum.bit
    %out_qubits_5 = quantum.custom "RZ"(%cst) %out_qubits_4 : !quantum.bit
    %out_qubits_6 = quantum.custom "Hadamard"() %out_qubits_5 : !quantum.bit
    %out_qubits_7 = quantum.custom "RZ"(%cst) %out_qubits_6 : !quantum.bit
    %out_qubits_8 = quantum.custom "Hadamard"() %out_qubits_7 : !quantum.bit
    %out_qubits_9:2 = quantum.custom "CZ"() %out_qubits_3, %out_qubits_8 : !quantum.bit, !quantum.bit
    %out_qubits_10 = quantum.custom "RX"(%cst_0) %out_qubits_9#0 : !quantum.bit
    %out_qubits_11 = quantum.custom "RZ"(%cst) %out_qubits_10 : !quantum.bit
    %out_qubits_12 = quantum.custom "Hadamard"() %out_qubits_11 : !quantum.bit
    %out_qubits_13 = quantum.custom "RZ"(%cst) %out_qubits_12 : !quantum.bit
    %3 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_14 = quantum.custom "RZ"(%cst) %3 : !quantum.bit
    %out_qubits_15 = quantum.custom "Hadamard"() %out_qubits_14 : !quantum.bit
    %out_qubits_16 = quantum.custom "RZ"(%cst) %out_qubits_15 : !quantum.bit
    %out_qubits_17 = quantum.custom "RX"(%cst_0) %out_qubits_16 : !quantum.bit
    %out_qubits_18:2 = quantum.custom "CZ"() %out_qubits_17, %out_qubits_9#1 : !quantum.bit, !quantum.bit
    %out_qubits_19 = quantum.custom "RX"(%cst_0) %out_qubits_18#0 : !quantum.bit
    %out_qubits_20 = quantum.custom "RZ"(%cst) %out_qubits_19 : !quantum.bit
    %out_qubits_21 = quantum.custom "Hadamard"() %out_qubits_20 : !quantum.bit
    %out_qubits_22 = quantum.custom "RZ"(%cst) %out_qubits_21 : !quantum.bit
    %4 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_23 = quantum.custom "RZ"(%cst) %4 : !quantum.bit
    %out_qubits_24 = quantum.custom "Hadamard"() %out_qubits_23 : !quantum.bit
    %out_qubits_25 = quantum.custom "RZ"(%cst) %out_qubits_24 : !quantum.bit
    %out_qubits_26:2 = quantum.custom "CZ"() %out_qubits_25, %out_qubits_18#1 : !quantum.bit, !quantum.bit
    %out_qubits_27 = quantum.custom "RZ"(%cst) %out_qubits_26#0 : !quantum.bit
    %out_qubits_28 = quantum.custom "Hadamard"() %out_qubits_27 : !quantum.bit
    %out_qubits_29 = quantum.custom "RZ"(%cst) %out_qubits_28 : !quantum.bit
    %5 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_30 = quantum.custom "RZ"(%cst) %5 : !quantum.bit
    %out_qubits_31 = quantum.custom "Hadamard"() %out_qubits_30 : !quantum.bit
    %out_qubits_32 = quantum.custom "RZ"(%cst) %out_qubits_31 : !quantum.bit
    %out_qubits_33 = quantum.custom "RX"(%cst_0) %out_qubits_32 : !quantum.bit
    %out_qubits_34:2 = quantum.custom "CZ"() %out_qubits_33, %out_qubits_26#1 : !quantum.bit, !quantum.bit
    %out_qubits_35 = quantum.custom "RX"(%cst_0) %out_qubits_34#0 : !quantum.bit
    %out_qubits_36 = quantum.custom "RZ"(%cst) %out_qubits_35 : !quantum.bit
    %out_qubits_37 = quantum.custom "Hadamard"() %out_qubits_36 : !quantum.bit
    %out_qubits_38 = quantum.custom "RZ"(%cst) %out_qubits_37 : !quantum.bit
    %6 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_39 = quantum.custom "RZ"(%cst) %6 : !quantum.bit
    %out_qubits_40 = quantum.custom "Hadamard"() %out_qubits_39 : !quantum.bit
    %out_qubits_41 = quantum.custom "RZ"(%cst) %out_qubits_40 : !quantum.bit
    %out_qubits_42:2 = quantum.custom "CZ"() %out_qubits_41, %out_qubits_34#1 : !quantum.bit, !quantum.bit
    %out_qubits_43 = quantum.custom "RZ"(%cst) %out_qubits_42#0 : !quantum.bit
    %out_qubits_44 = quantum.custom "Hadamard"() %out_qubits_43 : !quantum.bit
    %out_qubits_45 = quantum.custom "RZ"(%cst) %out_qubits_44 : !quantum.bit
    %out_qubits_46 = quantum.custom "Hadamard"() %out_qubits_42#1 : !quantum.bit
    %7 = quantum.compbasis qubits %out_qubits_13, %out_qubits_22, %out_qubits_29, %out_qubits_38, %out_qubits_45 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x5xf64>
    %9 = stablehlo.convert %8 : (tensor<128x5xf64>) -> tensor<128x5xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_13 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_22 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_29 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_38 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_45 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_46 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x5xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}