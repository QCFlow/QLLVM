// Benchmark was created by MQT Bench on 2024-03-17
// For more information about MQT Bench, please visit https://www.cda.cit.tum.de/mqtbench/
// MQT Bench version: 1.1.0
// Qiskit version: 1.0.2
// Used Gate Set: ['id', 'rz', 'sx', 'x', 'cx', 'measure', 'barrier']

OPENQASM 3;
include "qelib1.inc";
qreg q[8];
creg meas[8];
rz(pi/2) q[7];
rz(-pi/2) q[7];
h q[7];
rz(-pi/2) q[7];
rz(pi/2) q[7];
h q[6];
cz q[7],q[6];
h q[6];
h q[5];
cz q[6],q[5];
h q[5];
h q[4];
cz q[5],q[4];
h q[4];
h q[3];
cz q[4],q[3];
h q[3];
h q[2];
cz q[3],q[2];
h q[2];
h q[1];
cz q[2],q[1];
h q[1];
h q[0];
cz q[1],q[0];
h q[0];
barrier q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7];
measure q[0] -> meas[0];
measure q[1] -> meas[1];
measure q[2] -> meas[2];
measure q[3] -> meas[3];
measure q[4] -> meas[4];
measure q[5] -> meas[5];
measure q[6] -> meas[6];
measure q[7] -> meas[7];
