module @circuit {
  func.func public @jit_circuit() -> tensor<128x6xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x6xi64>
    return %0 : tensor<128x6xi64>
  }
  func.func public @circuit_0() -> tensor<128x6xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -122.52211349000179 : f64
    %cst_0 = arith.constant 0.4766825551239709 : f64
    %cst_1 = arith.constant -9.9920072216264088E-16 : f64
    %cst_2 = arith.constant 2.345769178126651 : f64
    %cst_3 = arith.constant 12.566370614359172 : f64
    %cst_4 = arith.constant 0.89328075421093611 : f64
    %cst_5 = arith.constant 9.4247779607693775 : f64
    %cst_6 = arith.constant 2.8742785055981952 : f64
    %cst_7 = arith.constant -3.1415926535897949 : f64
    %cst_8 = arith.constant 1.7933732440688748 : f64
    %cst_9 = arith.constant -3.1415926535897936 : f64
    %cst_10 = arith.constant 9.4247779607693793 : f64
    %cst_11 = arith.constant 0.51664042529662213 : f64
    %cst_12 = arith.constant 4.7123889803846897 : f64
    %cst_13 = arith.constant 1.8339114230470697 : f64
    %cst_14 = arith.constant -3.1415926535897931 : f64
    %cst_15 = arith.constant 3.1415926535897958 : f64
    %cst_16 = arith.constant 2.9641260790713253 : f64
    %cst_17 = arith.constant 2.886579864025407E-15 : f64
    %cst_18 = arith.constant 2.2778184565720165 : f64
    %cst_19 = arith.constant 8.8817841970012523E-16 : f64
    %cst_20 = arith.constant -1.3322676295501878E-15 : f64
    %cst_21 = arith.constant 2.7481335474157782 : f64
    %cst_22 = arith.constant -3.1415926535897944 : f64
    %cst_23 = arith.constant 3.1415926535897936 : f64
    %cst_24 = arith.constant 1.6474025769616722 : f64
    %cst_25 = arith.constant -1.5707963267948968 : f64
    %cst_26 = arith.constant 0.0248076889803788 : f64
    %cst_27 = arith.constant 1.2185281489032193E-15 : f64
    %cst_28 = arith.constant 0.29283824240478123 : f64
    %cst_29 = arith.constant -1.3951740851243746E-15 : f64
    %cst_30 = arith.constant 3.1415926535897944 : f64
    %cst_31 = arith.constant 2.7354464141049171 : f64
    %cst_32 = arith.constant 1.3322676295501878E-15 : f64
    %cst_33 = arith.constant 4.4408920985006262E-16 : f64
    %cst_34 = arith.constant 1.0157409043377801 : f64
    %cst_35 = arith.constant 1.1102230246251565E-15 : f64
    %cst_36 = arith.constant 0.5082416032203253 : f64
    %cst_37 = arith.constant 3.1415926535897922 : f64
    %cst_38 = arith.constant -7.3274719625260332E-15 : f64
    %cst_39 = arith.constant 3.0754262374271604 : f64
    %cst_40 = arith.constant -3.1415926535898002 : f64
    %cst_41 = arith.constant -1.5707963267948963 : f64
    %cst_42 = arith.constant 1.2444656817555666 : f64
    %cst_43 = arith.constant 1.5707963267948963 : f64
    %cst_44 = arith.constant 3.7747582837255322E-15 : f64
    %cst_45 = arith.constant 0.15835734649221744 : f64
    %cst_46 = arith.constant 3.1415926535897896 : f64
    %cst_47 = arith.constant 3.1415926535897931 : f64
    %cst_48 = arith.constant 1.5614156084307378 : f64
    %cst_49 = arith.constant 3.1415926535898584 : f64
    %cst_50 = arith.constant 3.1340772259307204 : f64
    %cst_51 = arith.constant 6.5281113847959205E-14 : f64
    %cst_52 = arith.constant 3.141592653589794 : f64
    %cst_53 = arith.constant 2.4105329528141568 : f64
    %cst_54 = arith.constant 6.6613381477509392E-16 : f64
    %cst_55 = arith.constant 0.000000e+00 : f64
    %cst_56 = arith.constant 1.4404079834845696 : f64
    %cst_57 = arith.constant 3.1415926535897927 : f64
    %cst_58 = arith.constant 1.5707963267948966 : f64
    %cst_59 = arith.constant 1.4368347742816614 : f64
    %cst_60 = arith.constant -3.141592653589794 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_60, %cst_59, %cst_58) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_61 = quantum.custom "Rot"(%cst_57, %cst_56, %cst_55) %2 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_61 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_63 = quantum.custom "Rot"(%cst_54, %cst_53, %cst_52) %3 : !quantum.bit
    %out_qubits_64:2 = quantum.custom "CZ"() %out_qubits_62#0, %out_qubits_63 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_65 = quantum.custom "Rot"(%cst_51, %cst_50, %cst_49) %4 : !quantum.bit
    %out_qubits_66:2 = quantum.custom "CZ"() %out_qubits_64#0, %out_qubits_65 : !quantum.bit, !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_67 = quantum.custom "Rot"(%cst_54, %cst_48, %cst_47) %5 : !quantum.bit
    %out_qubits_68:2 = quantum.custom "CZ"() %out_qubits_66#0, %out_qubits_67 : !quantum.bit, !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_69 = quantum.custom "Rot"(%cst_46, %cst_45, %cst_44) %6 : !quantum.bit
    %out_qubits_70:2 = quantum.custom "CZ"() %out_qubits_68#0, %out_qubits_69 : !quantum.bit, !quantum.bit
    %out_qubits_71 = quantum.custom "Rot"(%cst_43, %cst_42, %cst_41) %out_qubits_70#0 : !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_62#1 : !quantum.bit
    %out_qubits_73:2 = quantum.custom "CZ"() %out_qubits_72, %out_qubits_64#1 : !quantum.bit, !quantum.bit
    %out_qubits_74:2 = quantum.custom "CZ"() %out_qubits_73#0, %out_qubits_66#1 : !quantum.bit, !quantum.bit
    %out_qubits_75:2 = quantum.custom "CZ"() %out_qubits_74#0, %out_qubits_68#1 : !quantum.bit, !quantum.bit
    %out_qubits_76:2 = quantum.custom "CZ"() %out_qubits_75#0, %out_qubits_70#1 : !quantum.bit, !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_40, %cst_39, %cst_38) %out_qubits_76#0 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_71, %out_qubits_77 : !quantum.bit, !quantum.bit
    %out_qubits_79 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_73#1 : !quantum.bit
    %out_qubits_80:2 = quantum.custom "CZ"() %out_qubits_79, %out_qubits_74#1 : !quantum.bit, !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_80#0, %out_qubits_75#1 : !quantum.bit, !quantum.bit
    %out_qubits_82:2 = quantum.custom "CZ"() %out_qubits_81#0, %out_qubits_76#1 : !quantum.bit, !quantum.bit
    %out_qubits_83 = quantum.custom "Rot"(%cst_37, %cst_36, %cst_35) %out_qubits_82#0 : !quantum.bit
    %out_qubits_84:2 = quantum.custom "CZ"() %out_qubits_78#0, %out_qubits_83 : !quantum.bit, !quantum.bit
    %out_qubits_85 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_80#1 : !quantum.bit
    %out_qubits_86:2 = quantum.custom "CZ"() %out_qubits_85, %out_qubits_81#1 : !quantum.bit, !quantum.bit
    %out_qubits_87:2 = quantum.custom "CZ"() %out_qubits_86#0, %out_qubits_82#1 : !quantum.bit, !quantum.bit
    %out_qubits_88 = quantum.custom "Rot"(%cst_57, %cst_34, %cst_33) %out_qubits_87#0 : !quantum.bit
    %out_qubits_89:2 = quantum.custom "CZ"() %out_qubits_84#0, %out_qubits_88 : !quantum.bit, !quantum.bit
    %out_qubits_90 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_86#1 : !quantum.bit
    %out_qubits_91:2 = quantum.custom "CZ"() %out_qubits_90, %out_qubits_87#1 : !quantum.bit, !quantum.bit
    %out_qubits_92 = quantum.custom "Rot"(%cst_32, %cst_31, %cst_30) %out_qubits_91#0 : !quantum.bit
    %out_qubits_93:2 = quantum.custom "CZ"() %out_qubits_89#0, %out_qubits_92 : !quantum.bit, !quantum.bit
    %out_qubits_94 = quantum.custom "Rot"(%cst_29, %cst_28, %cst_27) %out_qubits_91#1 : !quantum.bit
    %out_qubits_95:2 = quantum.custom "CZ"() %out_qubits_93#0, %out_qubits_94 : !quantum.bit, !quantum.bit
    %out_qubits_96 = quantum.custom "Rot"(%cst_43, %cst_26, %cst_25) %out_qubits_95#0 : !quantum.bit
    %out_qubits_97 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_78#1 : !quantum.bit
    %out_qubits_98:2 = quantum.custom "CZ"() %out_qubits_97, %out_qubits_84#1 : !quantum.bit, !quantum.bit
    %out_qubits_99:2 = quantum.custom "CZ"() %out_qubits_98#0, %out_qubits_89#1 : !quantum.bit, !quantum.bit
    %out_qubits_100:2 = quantum.custom "CZ"() %out_qubits_99#0, %out_qubits_93#1 : !quantum.bit, !quantum.bit
    %out_qubits_101:2 = quantum.custom "CZ"() %out_qubits_100#0, %out_qubits_95#1 : !quantum.bit, !quantum.bit
    %out_qubits_102 = quantum.custom "Rot"(%cst_33, %cst_24, %cst_23) %out_qubits_101#0 : !quantum.bit
    %out_qubits_103:2 = quantum.custom "CZ"() %out_qubits_96, %out_qubits_102 : !quantum.bit, !quantum.bit
    %out_qubits_104 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_98#1 : !quantum.bit
    %out_qubits_105:2 = quantum.custom "CZ"() %out_qubits_104, %out_qubits_99#1 : !quantum.bit, !quantum.bit
    %out_qubits_106:2 = quantum.custom "CZ"() %out_qubits_105#0, %out_qubits_100#1 : !quantum.bit, !quantum.bit
    %out_qubits_107:2 = quantum.custom "CZ"() %out_qubits_106#0, %out_qubits_101#1 : !quantum.bit, !quantum.bit
    %out_qubits_108 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_107#0 : !quantum.bit
    %out_qubits_109:2 = quantum.custom "CZ"() %out_qubits_103#0, %out_qubits_108 : !quantum.bit, !quantum.bit
    %out_qubits_110 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_105#1 : !quantum.bit
    %out_qubits_111:2 = quantum.custom "CZ"() %out_qubits_110, %out_qubits_106#1 : !quantum.bit, !quantum.bit
    %out_qubits_112:2 = quantum.custom "CZ"() %out_qubits_111#0, %out_qubits_107#1 : !quantum.bit, !quantum.bit
    %out_qubits_113 = quantum.custom "Rot"(%cst_19, %cst_18, %cst_23) %out_qubits_112#0 : !quantum.bit
    %out_qubits_114:2 = quantum.custom "CZ"() %out_qubits_109#0, %out_qubits_113 : !quantum.bit, !quantum.bit
    %out_qubits_115 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_111#1 : !quantum.bit
    %out_qubits_116:2 = quantum.custom "CZ"() %out_qubits_115, %out_qubits_112#1 : !quantum.bit, !quantum.bit
    %out_qubits_117 = quantum.custom "Rot"(%cst_17, %cst_16, %cst_15) %out_qubits_116#0 : !quantum.bit
    %out_qubits_118:2 = quantum.custom "CZ"() %out_qubits_114#0, %out_qubits_117 : !quantum.bit, !quantum.bit
    %out_qubits_119 = quantum.custom "Rot"(%cst_14, %cst_13, %cst_14) %out_qubits_116#1 : !quantum.bit
    %out_qubits_120:2 = quantum.custom "CZ"() %out_qubits_118#0, %out_qubits_119 : !quantum.bit, !quantum.bit
    %out_qubits_121 = quantum.custom "Rot"(%cst_12, %cst_11, %cst_10) %out_qubits_120#0 : !quantum.bit
    %out_qubits_122 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_103#1 : !quantum.bit
    %out_qubits_123:2 = quantum.custom "CZ"() %out_qubits_122, %out_qubits_109#1 : !quantum.bit, !quantum.bit
    %out_qubits_124:2 = quantum.custom "CZ"() %out_qubits_123#0, %out_qubits_114#1 : !quantum.bit, !quantum.bit
    %out_qubits_125:2 = quantum.custom "CZ"() %out_qubits_124#0, %out_qubits_118#1 : !quantum.bit, !quantum.bit
    %out_qubits_126:2 = quantum.custom "CZ"() %out_qubits_125#0, %out_qubits_120#1 : !quantum.bit, !quantum.bit
    %out_qubits_127 = quantum.custom "Rot"(%cst_9, %cst_8, %cst_10) %out_qubits_126#0 : !quantum.bit
    %out_qubits_128 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_123#1 : !quantum.bit
    %out_qubits_129:2 = quantum.custom "CZ"() %out_qubits_128, %out_qubits_124#1 : !quantum.bit, !quantum.bit
    %out_qubits_130:2 = quantum.custom "CZ"() %out_qubits_129#0, %out_qubits_125#1 : !quantum.bit, !quantum.bit
    %out_qubits_131:2 = quantum.custom "CZ"() %out_qubits_130#0, %out_qubits_126#1 : !quantum.bit, !quantum.bit
    %out_qubits_132 = quantum.custom "Rot"(%cst_7, %cst_6, %cst_5) %out_qubits_131#0 : !quantum.bit
    %out_qubits_133 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_129#1 : !quantum.bit
    %out_qubits_134:2 = quantum.custom "CZ"() %out_qubits_133, %out_qubits_130#1 : !quantum.bit, !quantum.bit
    %out_qubits_135:2 = quantum.custom "CZ"() %out_qubits_134#0, %out_qubits_131#1 : !quantum.bit, !quantum.bit
    %out_qubits_136 = quantum.custom "Rot"(%cst_55, %cst_4, %cst_3) %out_qubits_135#0 : !quantum.bit
    %out_qubits_137 = quantum.custom "Rot"(%cst_47, %cst_58, %cst_55) %out_qubits_134#1 : !quantum.bit
    %out_qubits_138:2 = quantum.custom "CZ"() %out_qubits_137, %out_qubits_135#1 : !quantum.bit, !quantum.bit
    %out_qubits_139 = quantum.custom "Rot"(%cst_19, %cst_2, %cst_3) %out_qubits_138#0 : !quantum.bit
    %out_qubits_140 = quantum.custom "Rot"(%cst_1, %cst_0, %cst_10) %out_qubits_138#1 : !quantum.bit
    quantum.gphase(%cst)
    %7 = quantum.compbasis qubits %out_qubits_121, %out_qubits_127, %out_qubits_132, %out_qubits_136, %out_qubits_139, %out_qubits_140 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x6xf64>
    %9 = stablehlo.convert %8 : (tensor<128x6xf64>) -> tensor<128x6xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_121 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_127 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_132 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_136 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_139 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_140 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x6xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}