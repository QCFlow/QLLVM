module @circuit {
  func.func public @jit_circuit() -> tensor<128x8xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x8xi64>
    return %0 : tensor<128x8xi64>
  }
  func.func public @circuit_0() -> tensor<128x8xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -119.380520836412 : f64
    %cst_0 = arith.constant 3.0951342638977697 : f64
    %cst_1 = arith.constant 6.2831853071795862 : f64
    %cst_2 = arith.constant 1.9786651829490918 : f64
    %cst_3 = arith.constant -3.1415926535897931 : f64
    %cst_4 = arith.constant 3.1415926535897949 : f64
    %cst_5 = arith.constant 0.23371484836988146 : f64
    %cst_6 = arith.constant -1.7763568394002505E-15 : f64
    %cst_7 = arith.constant 3.1415926535901786 : f64
    %cst_8 = arith.constant 8.1362986165691938E-4 : f64
    %cst_9 = arith.constant -3.8591352335970441E-13 : f64
    %cst_10 = arith.constant 1.5708508912210548 : f64
    %cst_11 = arith.constant 9.4247779607693793 : f64
    %cst_12 = arith.constant 1.6097339326594784 : f64
    %cst_13 = arith.constant -1.5707963267948963 : f64
    %cst_14 = arith.constant -3.1415926535897936 : f64
    %cst_15 = arith.constant 1.6566791564272456 : f64
    %cst_16 = arith.constant -3.1415926535897927 : f64
    %cst_17 = arith.constant -4.7123889803844978 : f64
    %cst_18 = arith.constant 0.0016393098741886193 : f64
    %cst_19 = arith.constant -1.9140244944537699E-13 : f64
    %cst_20 = arith.constant 3.1381094409743966 : f64
    %cst_21 = arith.constant -1.5707963267949112 : f64
    %cst_22 = arith.constant 0.021625726779208196 : f64
    %cst_23 = arith.constant -3.1415926535897785 : f64
    %cst_24 = arith.constant 1.570796326794897 : f64
    %cst_25 = arith.constant -3.3306690738754696E-16 : f64
    %cst_26 = arith.constant -4.7123889803846897 : f64
    %cst_27 = arith.constant 1.5704495414374424 : f64
    %cst_28 = arith.constant 1.5707963267948968 : f64
    %cst_29 = arith.constant 1.5708738876358839 : f64
    %cst_30 = arith.constant -4.4408920985006262E-16 : f64
    %cst_31 = arith.constant -1.5707963267578198 : f64
    %cst_32 = arith.constant 3.1415806759848888 : f64
    %cst_33 = arith.constant 1.5707963268319729 : f64
    %cst_34 = arith.constant 10.995574287564276 : f64
    %cst_35 = arith.constant 1.484730387757103 : f64
    %cst_36 = arith.constant 3.1415926535897927 : f64
    %cst_37 = arith.constant 4.7123889803846968 : f64
    %cst_38 = arith.constant 3.095027412227799 : f64
    %cst_39 = arith.constant 7.1054273576010019E-15 : f64
    %cst_40 = arith.constant 1.1627197371872604 : f64
    %cst_41 = arith.constant 4.7123889803846915 : f64
    %cst_42 = arith.constant 2.9080486209242409 : f64
    %cst_43 = arith.constant 1.7763568394002505E-15 : f64
    %cst_44 = arith.constant 2.6984978499412397E-5 : f64
    %cst_45 = arith.constant 1.5487357514185458 : f64
    %cst_46 = arith.constant 4.7123889803846897 : f64
    %cst_47 = arith.constant 6.0373297249293802E-5 : f64
    %cst_48 = arith.constant 0.000000e+00 : f64
    %cst_49 = arith.constant 1.5707963267948966 : f64
    %cst_50 = arith.constant 1.6098237945191911 : f64
    %cst_51 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 8) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_51, %cst_50, %cst_49) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_48, %cst_47, %cst_46) %2 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_48, %cst_45, %cst_46) %3 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_54 = quantum.custom "Rot"(%cst_48, %cst_44, %cst_46) %4 : !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_43, %cst_42, %cst_41) %5 : !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_56 = quantum.custom "Rot"(%cst_51, %cst_40, %cst_49) %6 : !quantum.bit
    %7 = quantum.extract %0[ 6] : !quantum.reg -> !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_39, %cst_38, %cst_37) %7 : !quantum.bit
    %8 = quantum.extract %0[ 7] : !quantum.reg -> !quantum.bit
    %out_qubits_58 = quantum.custom "Rot"(%cst_36, %cst_35, %cst_48) %8 : !quantum.bit
    %out_qubits_59:2 = quantum.custom "CZ"() %out_qubits_57, %out_qubits_58 : !quantum.bit, !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_59#0 : !quantum.bit
    %out_qubits_61:2 = quantum.custom "CZ"() %out_qubits_56, %out_qubits_60 : !quantum.bit, !quantum.bit
    %out_qubits_62 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_61#0 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_55, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_63#0 : !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_54, %out_qubits_64 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_65#0 : !quantum.bit
    %out_qubits_67:2 = quantum.custom "CZ"() %out_qubits_53, %out_qubits_66 : !quantum.bit, !quantum.bit
    %out_qubits_68 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_67#0 : !quantum.bit
    %out_qubits_69:2 = quantum.custom "CZ"() %out_qubits_52, %out_qubits_68 : !quantum.bit, !quantum.bit
    %out_qubits_70 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_69#0 : !quantum.bit
    %out_qubits_71:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_70 : !quantum.bit, !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_33, %cst_32, %cst_31) %out_qubits_71#0 : !quantum.bit
    %out_qubits_73 = quantum.custom "Rot"(%cst_30, %cst_29, %cst_28) %out_qubits_71#1 : !quantum.bit
    %out_qubits_74 = quantum.custom "Rot"(%cst_48, %cst_27, %cst_26) %out_qubits_69#1 : !quantum.bit
    %out_qubits_75 = quantum.custom "Rot"(%cst_25, %cst_28, %cst_24) %out_qubits_67#1 : !quantum.bit
    %out_qubits_76 = quantum.custom "Rot"(%cst_23, %cst_22, %cst_21) %out_qubits_65#1 : !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_25, %cst_20, %cst_24) %out_qubits_63#1 : !quantum.bit
    %out_qubits_78 = quantum.custom "Rot"(%cst_19, %cst_18, %cst_17) %out_qubits_61#1 : !quantum.bit
    %out_qubits_79 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_59#1 : !quantum.bit
    %out_qubits_80:2 = quantum.custom "CZ"() %out_qubits_78, %out_qubits_79 : !quantum.bit, !quantum.bit
    %out_qubits_81 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_80#0 : !quantum.bit
    %out_qubits_82:2 = quantum.custom "CZ"() %out_qubits_77, %out_qubits_81 : !quantum.bit, !quantum.bit
    %out_qubits_83 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_82#0 : !quantum.bit
    %out_qubits_84:2 = quantum.custom "CZ"() %out_qubits_76, %out_qubits_83 : !quantum.bit, !quantum.bit
    %out_qubits_85 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_84#0 : !quantum.bit
    %out_qubits_86:2 = quantum.custom "CZ"() %out_qubits_75, %out_qubits_85 : !quantum.bit, !quantum.bit
    %out_qubits_87 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_86#0 : !quantum.bit
    %out_qubits_88:2 = quantum.custom "CZ"() %out_qubits_74, %out_qubits_87 : !quantum.bit, !quantum.bit
    %out_qubits_89 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_88#0 : !quantum.bit
    %out_qubits_90:2 = quantum.custom "CZ"() %out_qubits_73, %out_qubits_89 : !quantum.bit, !quantum.bit
    %out_qubits_91 = quantum.custom "Rot"(%cst_34, %cst_49, %cst_48) %out_qubits_90#0 : !quantum.bit
    %out_qubits_92:2 = quantum.custom "CZ"() %out_qubits_72, %out_qubits_91 : !quantum.bit, !quantum.bit
    %out_qubits_93 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_92#0 : !quantum.bit
    %out_qubits_94 = quantum.custom "Rot"(%cst_25, %cst_10, %cst_11) %out_qubits_92#1 : !quantum.bit
    %out_qubits_95 = quantum.custom "Rot"(%cst_9, %cst_8, %cst_7) %out_qubits_90#1 : !quantum.bit
    %out_qubits_96 = quantum.custom "Rot"(%cst_25, %cst_28, %cst_11) %out_qubits_88#1 : !quantum.bit
    %out_qubits_97 = quantum.custom "Rot"(%cst_30, %cst_28, %cst_51) %out_qubits_86#1 : !quantum.bit
    %out_qubits_98 = quantum.custom "Rot"(%cst_6, %cst_5, %cst_4) %out_qubits_84#1 : !quantum.bit
    %out_qubits_99 = quantum.custom "Rot"(%cst_3, %cst_2, %cst_1) %out_qubits_82#1 : !quantum.bit
    %out_qubits_100 = quantum.custom "Rot"(%cst_48, %cst_0, %cst_11) %out_qubits_80#1 : !quantum.bit
    quantum.gphase(%cst)
    %9 = quantum.compbasis qubits %out_qubits_93, %out_qubits_94, %out_qubits_95, %out_qubits_96, %out_qubits_97, %out_qubits_98, %out_qubits_99, %out_qubits_100 : !quantum.obs
    %10 = quantum.sample %9 : tensor<128x8xf64>
    %11 = stablehlo.convert %10 : (tensor<128x8xf64>) -> tensor<128x8xi64>
    %12 = quantum.insert %0[ 0], %out_qubits_93 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 1], %out_qubits_94 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 2], %out_qubits_95 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 3], %out_qubits_96 : !quantum.reg, !quantum.bit
    %16 = quantum.insert %15[ 4], %out_qubits_97 : !quantum.reg, !quantum.bit
    %17 = quantum.insert %16[ 5], %out_qubits_98 : !quantum.reg, !quantum.bit
    %18 = quantum.insert %17[ 6], %out_qubits_99 : !quantum.reg, !quantum.bit
    %19 = quantum.insert %18[ 7], %out_qubits_100 : !quantum.reg, !quantum.bit
    quantum.dealloc %19 : !quantum.reg
    quantum.device_release
    return %11 : tensor<128x8xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}