module @circuit {
  func.func public @jit_circuit() -> tensor<128x6xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x6xi64>
    return %0 : tensor<128x6xi64>
  }
  func.func public @circuit_0() -> tensor<128x6xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 0.000000e+00 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Hadamard"() %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_0 = quantum.custom "Hadamard"() %2 : !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_1 = quantum.custom "Hadamard"() %3 : !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_2 = quantum.custom "Hadamard"() %4 : !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_3 = quantum.custom "Hadamard"() %5 : !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_4 = quantum.custom "RZ"(%cst) %6 : !quantum.bit
    %out_qubits_5 = quantum.custom "Hadamard"() %out_qubits_4 : !quantum.bit
    %out_qubits_6 = quantum.custom "RZ"(%cst) %out_qubits_5 : !quantum.bit
    %out_qubits_7:2 = quantum.custom "CZ"() %out_qubits_6, %out_qubits_3 : !quantum.bit, !quantum.bit
    %out_qubits_8 = quantum.custom "Hadamard"() %out_qubits_7#1 : !quantum.bit
    %out_qubits_9:2 = quantum.custom "CZ"() %out_qubits_8, %out_qubits_2 : !quantum.bit, !quantum.bit
    %out_qubits_10 = quantum.custom "Hadamard"() %out_qubits_9#1 : !quantum.bit
    %out_qubits_11:2 = quantum.custom "CZ"() %out_qubits_10, %out_qubits_1 : !quantum.bit, !quantum.bit
    %out_qubits_12 = quantum.custom "Hadamard"() %out_qubits_11#1 : !quantum.bit
    %out_qubits_13:2 = quantum.custom "CZ"() %out_qubits_12, %out_qubits_0 : !quantum.bit, !quantum.bit
    %out_qubits_14 = quantum.custom "Hadamard"() %out_qubits_13#1 : !quantum.bit
    %out_qubits_15:2 = quantum.custom "CZ"() %out_qubits_14, %out_qubits : !quantum.bit, !quantum.bit
    %out_qubits_16 = quantum.custom "Hadamard"() %out_qubits_15#1 : !quantum.bit
    %7 = quantum.compbasis qubits %out_qubits_16, %out_qubits_15#0, %out_qubits_13#0, %out_qubits_11#0, %out_qubits_9#0, %out_qubits_7#0 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x6xf64>
    %9 = stablehlo.convert %8 : (tensor<128x6xf64>) -> tensor<128x6xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_16 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_15#0 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_13#0 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_11#0 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_9#0 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_7#0 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x6xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}