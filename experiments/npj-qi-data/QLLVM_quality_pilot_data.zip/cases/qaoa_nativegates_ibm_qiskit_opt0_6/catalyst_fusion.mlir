module @circuit {
  func.func public @jit_circuit() -> tensor<128x6xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x6xi64>
    return %0 : tensor<128x6xi64>
  }
  func.func public @circuit_0() -> tensor<128x6xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -109.95574287564266 : f64
    %cst_0 = arith.constant 1.5707963267948954 : f64
    %cst_1 = arith.constant 6.2831853071795862 : f64
    %cst_2 = arith.constant -1.8516062760331184 : f64
    %cst_3 = arith.constant 1.2899863775566751 : f64
    %cst_4 = arith.constant 1.5701860759735276 : f64
    %cst_5 = arith.constant 4.0682776207700364 : f64
    %cst_6 = arith.constant -1.5707963267948966 : f64
    %cst_7 = arith.constant 0.64470706501555208 : f64
    %cst_8 = arith.constant -0.64472161043602227 : f64
    %cst_9 = arith.constant 1.5707963267948961 : f64
    %cst_10 = arith.constant 3.1415926535897927 : f64
    %cst_11 = arith.constant 0.64472161043602227 : f64
    %cst_12 = arith.constant -1.5707963267948961 : f64
    %cst_13 = arith.constant 1.8525773534740768 : f64
    %cst_14 = arith.constant -4.7123889803846897 : f64
    %cst_15 = arith.constant 4.7123889803846897 : f64
    %cst_16 = arith.constant 0.000000e+00 : f64
    %cst_17 = arith.constant 1.5707963267948966 : f64
    %cst_18 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %1 : !quantum.bit
    %2 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_19 = quantum.custom "Rot"(%cst_15, %cst_16, %cst_17) %2 : !quantum.bit
    %out_qubits_20:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_19 : !quantum.bit, !quantum.bit
    %out_qubits_21 = quantum.custom "Rot"(%cst_14, %cst_13, %cst_12) %out_qubits_20#1 : !quantum.bit
    %out_qubits_22:2 = quantum.custom "CZ"() %out_qubits_20#0, %out_qubits_21 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_23 = quantum.custom "Rot"(%cst_15, %cst_16, %cst_17) %3 : !quantum.bit
    %out_qubits_24:2 = quantum.custom "CZ"() %out_qubits_22#0, %out_qubits_23 : !quantum.bit, !quantum.bit
    %out_qubits_25 = quantum.custom "Rot"(%cst_14, %cst_13, %cst_12) %out_qubits_24#1 : !quantum.bit
    %out_qubits_26:2 = quantum.custom "CZ"() %out_qubits_24#0, %out_qubits_25 : !quantum.bit, !quantum.bit
    %out_qubits_27 = quantum.custom "Rot"(%cst_15, %cst_11, %cst_17) %out_qubits_26#0 : !quantum.bit
    %out_qubits_28 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_22#1 : !quantum.bit
    %4 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_29 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %4 : !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_30 = quantum.custom "Rot"(%cst_15, %cst_16, %cst_17) %5 : !quantum.bit
    %out_qubits_31:2 = quantum.custom "CZ"() %out_qubits_29, %out_qubits_30 : !quantum.bit, !quantum.bit
    %out_qubits_32 = quantum.custom "Rot"(%cst_14, %cst_13, %cst_12) %out_qubits_31#1 : !quantum.bit
    %out_qubits_33:2 = quantum.custom "CZ"() %out_qubits_31#0, %out_qubits_32 : !quantum.bit, !quantum.bit
    %out_qubits_34:2 = quantum.custom "CZ"() %out_qubits_28, %out_qubits_33#1 : !quantum.bit, !quantum.bit
    %out_qubits_35 = quantum.custom "Rot"(%cst_14, %cst_13, %cst_12) %out_qubits_34#1 : !quantum.bit
    %out_qubits_36:2 = quantum.custom "CZ"() %out_qubits_34#0, %out_qubits_35 : !quantum.bit, !quantum.bit
    %out_qubits_37 = quantum.custom "Rot"(%cst_10, %cst_9, %cst_8) %out_qubits_36#0 : !quantum.bit
    %out_qubits_38:2 = quantum.custom "CZ"() %out_qubits_27, %out_qubits_37 : !quantum.bit, !quantum.bit
    %out_qubits_39 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_6) %out_qubits_38#1 : !quantum.bit
    %out_qubits_40:2 = quantum.custom "CZ"() %out_qubits_38#0, %out_qubits_39 : !quantum.bit, !quantum.bit
    %out_qubits_41 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_40#1 : !quantum.bit
    %out_qubits_42 = quantum.custom "Rot"(%cst_5, %cst_16, %cst_4) %out_qubits_36#1 : !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_43 = quantum.custom "Rot"(%cst_15, %cst_16, %cst_17) %6 : !quantum.bit
    %out_qubits_44:2 = quantum.custom "CZ"() %out_qubits_33#0, %out_qubits_43 : !quantum.bit, !quantum.bit
    %out_qubits_45 = quantum.custom "Rot"(%cst_14, %cst_13, %cst_12) %out_qubits_44#1 : !quantum.bit
    %out_qubits_46:2 = quantum.custom "CZ"() %out_qubits_44#0, %out_qubits_45 : !quantum.bit, !quantum.bit
    %out_qubits_47 = quantum.custom "Rot"(%cst_15, %cst_11, %cst_17) %out_qubits_46#0 : !quantum.bit
    %out_qubits_48:2 = quantum.custom "CZ"() %out_qubits_47, %out_qubits_42 : !quantum.bit, !quantum.bit
    %out_qubits_49 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_6) %out_qubits_48#1 : !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits_48#0, %out_qubits_49 : !quantum.bit, !quantum.bit
    %out_qubits_51:2 = quantum.custom "CZ"() %out_qubits_41, %out_qubits_50#1 : !quantum.bit, !quantum.bit
    %out_qubits_52 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_6) %out_qubits_51#1 : !quantum.bit
    %out_qubits_53:2 = quantum.custom "CZ"() %out_qubits_51#0, %out_qubits_52 : !quantum.bit, !quantum.bit
    %out_qubits_54 = quantum.custom "Rot"(%cst_14, %cst_3, %cst_15) %out_qubits_53#0 : !quantum.bit
    %out_qubits_55 = quantum.custom "Rot"(%cst_2, %cst_17, %cst_1) %out_qubits_53#1 : !quantum.bit
    %out_qubits_56 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_26#1 : !quantum.bit
    %out_qubits_57:2 = quantum.custom "CZ"() %out_qubits_56, %out_qubits_46#1 : !quantum.bit, !quantum.bit
    %out_qubits_58 = quantum.custom "Rot"(%cst_14, %cst_13, %cst_12) %out_qubits_57#1 : !quantum.bit
    %out_qubits_59:2 = quantum.custom "CZ"() %out_qubits_57#0, %out_qubits_58 : !quantum.bit, !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_10, %cst_9, %cst_8) %out_qubits_59#0 : !quantum.bit
    %out_qubits_61:2 = quantum.custom "CZ"() %out_qubits_40#0, %out_qubits_60 : !quantum.bit, !quantum.bit
    %out_qubits_62 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_6) %out_qubits_61#1 : !quantum.bit
    %out_qubits_63:2 = quantum.custom "CZ"() %out_qubits_61#0, %out_qubits_62 : !quantum.bit, !quantum.bit
    %out_qubits_64 = quantum.custom "Rot"(%cst_0, %cst_3, %cst_15) %out_qubits_63#0 : !quantum.bit
    %out_qubits_65 = quantum.custom "Rot"(%cst_5, %cst_16, %cst_4) %out_qubits_59#1 : !quantum.bit
    %out_qubits_66:2 = quantum.custom "CZ"() %out_qubits_50#0, %out_qubits_65 : !quantum.bit, !quantum.bit
    %out_qubits_67 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_6) %out_qubits_66#1 : !quantum.bit
    %out_qubits_68:2 = quantum.custom "CZ"() %out_qubits_66#0, %out_qubits_67 : !quantum.bit, !quantum.bit
    %out_qubits_69 = quantum.custom "Rot"(%cst_0, %cst_3, %cst_15) %out_qubits_68#0 : !quantum.bit
    %out_qubits_70 = quantum.custom "Rot"(%cst_18, %cst_17, %cst_16) %out_qubits_63#1 : !quantum.bit
    %out_qubits_71:2 = quantum.custom "CZ"() %out_qubits_70, %out_qubits_68#1 : !quantum.bit, !quantum.bit
    %out_qubits_72 = quantum.custom "Rot"(%cst_14, %cst_7, %cst_6) %out_qubits_71#1 : !quantum.bit
    %out_qubits_73:2 = quantum.custom "CZ"() %out_qubits_71#0, %out_qubits_72 : !quantum.bit, !quantum.bit
    %out_qubits_74 = quantum.custom "Rot"(%cst_14, %cst_3, %cst_15) %out_qubits_73#0 : !quantum.bit
    %out_qubits_75 = quantum.custom "Rot"(%cst_2, %cst_17, %cst_1) %out_qubits_73#1 : !quantum.bit
    quantum.gphase(%cst)
    %7 = quantum.compbasis qubits %out_qubits_64, %out_qubits_69, %out_qubits_54, %out_qubits_74, %out_qubits_55, %out_qubits_75 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x6xf64>
    %9 = stablehlo.convert %8 : (tensor<128x6xf64>) -> tensor<128x6xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_64 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_69 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_54 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_74 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_55 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_75 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x6xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}