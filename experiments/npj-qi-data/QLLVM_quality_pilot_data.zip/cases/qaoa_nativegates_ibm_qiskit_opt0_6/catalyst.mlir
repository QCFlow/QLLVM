module @circuit {
  func.func public @jit_circuit() -> tensor<128x6xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x6xi64>
    return %0 : tensor<128x6xi64>
  }
  func.func public @circuit_0() -> tensor<128x6xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -11.276384236802498 : f64
    %cst_0 = arith.constant 6.2831853071795862 : f64
    %cst_1 = arith.constant -0.64472161043602227 : f64
    %cst_2 = arith.constant 0.000000e+00 : f64
    %cst_3 = arith.constant 0.64470706501555253 : f64
    %cst_4 = arith.constant 1.8525773534740766 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "RZ"(%cst_2) %1 : !quantum.bit
    %out_qubits_5 = quantum.custom "Hadamard"() %out_qubits : !quantum.bit
    %out_qubits_6 = quantum.custom "RZ"(%cst_2) %out_qubits_5 : !quantum.bit
    %2 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_7 = quantum.custom "RZ"(%cst_2) %2 : !quantum.bit
    %out_qubits_8 = quantum.custom "Hadamard"() %out_qubits_7 : !quantum.bit
    %out_qubits_9 = quantum.custom "RZ"(%cst_2) %out_qubits_8 : !quantum.bit
    %out_qubits_10 = quantum.custom "Hadamard"() %out_qubits_9 : !quantum.bit
    %out_qubits_11:2 = quantum.custom "CZ"() %out_qubits_6, %out_qubits_10 : !quantum.bit, !quantum.bit
    %out_qubits_12 = quantum.custom "Hadamard"() %out_qubits_11#1 : !quantum.bit
    %out_qubits_13 = quantum.custom "RZ"(%cst_4) %out_qubits_12 : !quantum.bit
    %out_qubits_14 = quantum.custom "Hadamard"() %out_qubits_13 : !quantum.bit
    %out_qubits_15:2 = quantum.custom "CZ"() %out_qubits_11#0, %out_qubits_14 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_16 = quantum.custom "RZ"(%cst_2) %3 : !quantum.bit
    %out_qubits_17 = quantum.custom "Hadamard"() %out_qubits_16 : !quantum.bit
    %out_qubits_18 = quantum.custom "RZ"(%cst_2) %out_qubits_17 : !quantum.bit
    %out_qubits_19 = quantum.custom "Hadamard"() %out_qubits_18 : !quantum.bit
    %out_qubits_20:2 = quantum.custom "CZ"() %out_qubits_15#0, %out_qubits_19 : !quantum.bit, !quantum.bit
    %out_qubits_21 = quantum.custom "Hadamard"() %out_qubits_20#1 : !quantum.bit
    %out_qubits_22 = quantum.custom "RZ"(%cst_4) %out_qubits_21 : !quantum.bit
    %out_qubits_23 = quantum.custom "Hadamard"() %out_qubits_22 : !quantum.bit
    %out_qubits_24:2 = quantum.custom "CZ"() %out_qubits_20#0, %out_qubits_23 : !quantum.bit, !quantum.bit
    %out_qubits_25 = quantum.custom "RZ"(%cst_2) %out_qubits_24#0 : !quantum.bit
    %out_qubits_26 = quantum.custom "Hadamard"() %out_qubits_25 : !quantum.bit
    %out_qubits_27 = quantum.custom "RZ"(%cst_1) %out_qubits_26 : !quantum.bit
    %out_qubits_28 = quantum.custom "Hadamard"() %out_qubits_27 : !quantum.bit
    %out_qubits_29 = quantum.custom "RZ"(%cst_0) %out_qubits_28 : !quantum.bit
    %out_qubits_30 = quantum.custom "Hadamard"() %out_qubits_15#1 : !quantum.bit
    %4 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_31 = quantum.custom "RZ"(%cst_2) %4 : !quantum.bit
    %out_qubits_32 = quantum.custom "Hadamard"() %out_qubits_31 : !quantum.bit
    %out_qubits_33 = quantum.custom "RZ"(%cst_2) %out_qubits_32 : !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_34 = quantum.custom "RZ"(%cst_2) %5 : !quantum.bit
    %out_qubits_35 = quantum.custom "Hadamard"() %out_qubits_34 : !quantum.bit
    %out_qubits_36 = quantum.custom "RZ"(%cst_2) %out_qubits_35 : !quantum.bit
    %out_qubits_37 = quantum.custom "Hadamard"() %out_qubits_36 : !quantum.bit
    %out_qubits_38:2 = quantum.custom "CZ"() %out_qubits_33, %out_qubits_37 : !quantum.bit, !quantum.bit
    %out_qubits_39 = quantum.custom "Hadamard"() %out_qubits_38#1 : !quantum.bit
    %out_qubits_40 = quantum.custom "RZ"(%cst_4) %out_qubits_39 : !quantum.bit
    %out_qubits_41 = quantum.custom "Hadamard"() %out_qubits_40 : !quantum.bit
    %out_qubits_42:2 = quantum.custom "CZ"() %out_qubits_38#0, %out_qubits_41 : !quantum.bit, !quantum.bit
    %out_qubits_43:2 = quantum.custom "CZ"() %out_qubits_30, %out_qubits_42#1 : !quantum.bit, !quantum.bit
    %out_qubits_44 = quantum.custom "Hadamard"() %out_qubits_43#1 : !quantum.bit
    %out_qubits_45 = quantum.custom "RZ"(%cst_4) %out_qubits_44 : !quantum.bit
    %out_qubits_46 = quantum.custom "Hadamard"() %out_qubits_45 : !quantum.bit
    %out_qubits_47:2 = quantum.custom "CZ"() %out_qubits_43#0, %out_qubits_46 : !quantum.bit, !quantum.bit
    %out_qubits_48 = quantum.custom "RZ"(%cst_2) %out_qubits_47#0 : !quantum.bit
    %out_qubits_49 = quantum.custom "Hadamard"() %out_qubits_48 : !quantum.bit
    %out_qubits_50 = quantum.custom "RZ"(%cst_1) %out_qubits_49 : !quantum.bit
    %out_qubits_51 = quantum.custom "Hadamard"() %out_qubits_50 : !quantum.bit
    %out_qubits_52 = quantum.custom "RZ"(%cst_0) %out_qubits_51 : !quantum.bit
    %out_qubits_53 = quantum.custom "Hadamard"() %out_qubits_52 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_29, %out_qubits_53 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "Hadamard"() %out_qubits_54#1 : !quantum.bit
    %out_qubits_56 = quantum.custom "RZ"(%cst_3) %out_qubits_55 : !quantum.bit
    %out_qubits_57 = quantum.custom "Hadamard"() %out_qubits_56 : !quantum.bit
    %out_qubits_58:2 = quantum.custom "CZ"() %out_qubits_54#0, %out_qubits_57 : !quantum.bit, !quantum.bit
    %out_qubits_59 = quantum.custom "Hadamard"() %out_qubits_58#1 : !quantum.bit
    %out_qubits_60 = quantum.custom "Hadamard"() %out_qubits_47#1 : !quantum.bit
    %out_qubits_61 = quantum.custom "RZ"(%cst_2) %out_qubits_60 : !quantum.bit
    %out_qubits_62 = quantum.custom "Hadamard"() %out_qubits_61 : !quantum.bit
    %out_qubits_63 = quantum.custom "RZ"(%cst_1) %out_qubits_62 : !quantum.bit
    %out_qubits_64 = quantum.custom "Hadamard"() %out_qubits_63 : !quantum.bit
    %out_qubits_65 = quantum.custom "RZ"(%cst_0) %out_qubits_64 : !quantum.bit
    %out_qubits_66 = quantum.custom "Hadamard"() %out_qubits_65 : !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_67 = quantum.custom "RZ"(%cst_2) %6 : !quantum.bit
    %out_qubits_68 = quantum.custom "Hadamard"() %out_qubits_67 : !quantum.bit
    %out_qubits_69 = quantum.custom "RZ"(%cst_2) %out_qubits_68 : !quantum.bit
    %out_qubits_70 = quantum.custom "Hadamard"() %out_qubits_69 : !quantum.bit
    %out_qubits_71:2 = quantum.custom "CZ"() %out_qubits_42#0, %out_qubits_70 : !quantum.bit, !quantum.bit
    %out_qubits_72 = quantum.custom "Hadamard"() %out_qubits_71#1 : !quantum.bit
    %out_qubits_73 = quantum.custom "RZ"(%cst_4) %out_qubits_72 : !quantum.bit
    %out_qubits_74 = quantum.custom "Hadamard"() %out_qubits_73 : !quantum.bit
    %out_qubits_75:2 = quantum.custom "CZ"() %out_qubits_71#0, %out_qubits_74 : !quantum.bit, !quantum.bit
    %out_qubits_76 = quantum.custom "RZ"(%cst_2) %out_qubits_75#0 : !quantum.bit
    %out_qubits_77 = quantum.custom "Hadamard"() %out_qubits_76 : !quantum.bit
    %out_qubits_78 = quantum.custom "RZ"(%cst_1) %out_qubits_77 : !quantum.bit
    %out_qubits_79 = quantum.custom "Hadamard"() %out_qubits_78 : !quantum.bit
    %out_qubits_80 = quantum.custom "RZ"(%cst_0) %out_qubits_79 : !quantum.bit
    %out_qubits_81:2 = quantum.custom "CZ"() %out_qubits_80, %out_qubits_66 : !quantum.bit, !quantum.bit
    %out_qubits_82 = quantum.custom "Hadamard"() %out_qubits_81#1 : !quantum.bit
    %out_qubits_83 = quantum.custom "RZ"(%cst_3) %out_qubits_82 : !quantum.bit
    %out_qubits_84 = quantum.custom "Hadamard"() %out_qubits_83 : !quantum.bit
    %out_qubits_85:2 = quantum.custom "CZ"() %out_qubits_81#0, %out_qubits_84 : !quantum.bit, !quantum.bit
    %out_qubits_86:2 = quantum.custom "CZ"() %out_qubits_59, %out_qubits_85#1 : !quantum.bit, !quantum.bit
    %out_qubits_87 = quantum.custom "Hadamard"() %out_qubits_86#1 : !quantum.bit
    %out_qubits_88 = quantum.custom "RZ"(%cst_3) %out_qubits_87 : !quantum.bit
    %out_qubits_89 = quantum.custom "Hadamard"() %out_qubits_88 : !quantum.bit
    %out_qubits_90:2 = quantum.custom "CZ"() %out_qubits_86#0, %out_qubits_89 : !quantum.bit, !quantum.bit
    %out_qubits_91 = quantum.custom "RZ"(%cst_2) %out_qubits_90#0 : !quantum.bit
    %out_qubits_92 = quantum.custom "Hadamard"() %out_qubits_91 : !quantum.bit
    %out_qubits_93 = quantum.custom "RZ"(%cst) %out_qubits_92 : !quantum.bit
    %out_qubits_94 = quantum.custom "Hadamard"() %out_qubits_93 : !quantum.bit
    %out_qubits_95 = quantum.custom "RZ"(%cst_0) %out_qubits_94 : !quantum.bit
    %out_qubits_96 = quantum.custom "Hadamard"() %out_qubits_90#1 : !quantum.bit
    %out_qubits_97 = quantum.custom "RZ"(%cst_2) %out_qubits_96 : !quantum.bit
    %out_qubits_98 = quantum.custom "Hadamard"() %out_qubits_97 : !quantum.bit
    %out_qubits_99 = quantum.custom "RZ"(%cst) %out_qubits_98 : !quantum.bit
    %out_qubits_100 = quantum.custom "Hadamard"() %out_qubits_99 : !quantum.bit
    %out_qubits_101 = quantum.custom "RZ"(%cst_0) %out_qubits_100 : !quantum.bit
    %out_qubits_102 = quantum.custom "Hadamard"() %out_qubits_24#1 : !quantum.bit
    %out_qubits_103:2 = quantum.custom "CZ"() %out_qubits_102, %out_qubits_75#1 : !quantum.bit, !quantum.bit
    %out_qubits_104 = quantum.custom "Hadamard"() %out_qubits_103#1 : !quantum.bit
    %out_qubits_105 = quantum.custom "RZ"(%cst_4) %out_qubits_104 : !quantum.bit
    %out_qubits_106 = quantum.custom "Hadamard"() %out_qubits_105 : !quantum.bit
    %out_qubits_107:2 = quantum.custom "CZ"() %out_qubits_103#0, %out_qubits_106 : !quantum.bit, !quantum.bit
    %out_qubits_108 = quantum.custom "RZ"(%cst_2) %out_qubits_107#0 : !quantum.bit
    %out_qubits_109 = quantum.custom "Hadamard"() %out_qubits_108 : !quantum.bit
    %out_qubits_110 = quantum.custom "RZ"(%cst_1) %out_qubits_109 : !quantum.bit
    %out_qubits_111 = quantum.custom "Hadamard"() %out_qubits_110 : !quantum.bit
    %out_qubits_112 = quantum.custom "RZ"(%cst_0) %out_qubits_111 : !quantum.bit
    %out_qubits_113 = quantum.custom "Hadamard"() %out_qubits_112 : !quantum.bit
    %out_qubits_114:2 = quantum.custom "CZ"() %out_qubits_58#0, %out_qubits_113 : !quantum.bit, !quantum.bit
    %out_qubits_115 = quantum.custom "Hadamard"() %out_qubits_114#1 : !quantum.bit
    %out_qubits_116 = quantum.custom "RZ"(%cst_3) %out_qubits_115 : !quantum.bit
    %out_qubits_117 = quantum.custom "Hadamard"() %out_qubits_116 : !quantum.bit
    %out_qubits_118:2 = quantum.custom "CZ"() %out_qubits_114#0, %out_qubits_117 : !quantum.bit, !quantum.bit
    %out_qubits_119 = quantum.custom "RZ"(%cst_2) %out_qubits_118#0 : !quantum.bit
    %out_qubits_120 = quantum.custom "Hadamard"() %out_qubits_119 : !quantum.bit
    %out_qubits_121 = quantum.custom "RZ"(%cst) %out_qubits_120 : !quantum.bit
    %out_qubits_122 = quantum.custom "Hadamard"() %out_qubits_121 : !quantum.bit
    %out_qubits_123 = quantum.custom "RZ"(%cst_0) %out_qubits_122 : !quantum.bit
    %out_qubits_124 = quantum.custom "Hadamard"() %out_qubits_107#1 : !quantum.bit
    %out_qubits_125 = quantum.custom "RZ"(%cst_2) %out_qubits_124 : !quantum.bit
    %out_qubits_126 = quantum.custom "Hadamard"() %out_qubits_125 : !quantum.bit
    %out_qubits_127 = quantum.custom "RZ"(%cst_1) %out_qubits_126 : !quantum.bit
    %out_qubits_128 = quantum.custom "Hadamard"() %out_qubits_127 : !quantum.bit
    %out_qubits_129 = quantum.custom "RZ"(%cst_0) %out_qubits_128 : !quantum.bit
    %out_qubits_130 = quantum.custom "Hadamard"() %out_qubits_129 : !quantum.bit
    %out_qubits_131:2 = quantum.custom "CZ"() %out_qubits_85#0, %out_qubits_130 : !quantum.bit, !quantum.bit
    %out_qubits_132 = quantum.custom "Hadamard"() %out_qubits_131#1 : !quantum.bit
    %out_qubits_133 = quantum.custom "RZ"(%cst_3) %out_qubits_132 : !quantum.bit
    %out_qubits_134 = quantum.custom "Hadamard"() %out_qubits_133 : !quantum.bit
    %out_qubits_135:2 = quantum.custom "CZ"() %out_qubits_131#0, %out_qubits_134 : !quantum.bit, !quantum.bit
    %out_qubits_136 = quantum.custom "RZ"(%cst_2) %out_qubits_135#0 : !quantum.bit
    %out_qubits_137 = quantum.custom "Hadamard"() %out_qubits_136 : !quantum.bit
    %out_qubits_138 = quantum.custom "RZ"(%cst) %out_qubits_137 : !quantum.bit
    %out_qubits_139 = quantum.custom "Hadamard"() %out_qubits_138 : !quantum.bit
    %out_qubits_140 = quantum.custom "RZ"(%cst_0) %out_qubits_139 : !quantum.bit
    %out_qubits_141 = quantum.custom "Hadamard"() %out_qubits_118#1 : !quantum.bit
    %out_qubits_142:2 = quantum.custom "CZ"() %out_qubits_141, %out_qubits_135#1 : !quantum.bit, !quantum.bit
    %out_qubits_143 = quantum.custom "Hadamard"() %out_qubits_142#1 : !quantum.bit
    %out_qubits_144 = quantum.custom "RZ"(%cst_3) %out_qubits_143 : !quantum.bit
    %out_qubits_145 = quantum.custom "Hadamard"() %out_qubits_144 : !quantum.bit
    %out_qubits_146:2 = quantum.custom "CZ"() %out_qubits_142#0, %out_qubits_145 : !quantum.bit, !quantum.bit
    %out_qubits_147 = quantum.custom "RZ"(%cst_2) %out_qubits_146#0 : !quantum.bit
    %out_qubits_148 = quantum.custom "Hadamard"() %out_qubits_147 : !quantum.bit
    %out_qubits_149 = quantum.custom "RZ"(%cst) %out_qubits_148 : !quantum.bit
    %out_qubits_150 = quantum.custom "Hadamard"() %out_qubits_149 : !quantum.bit
    %out_qubits_151 = quantum.custom "RZ"(%cst_0) %out_qubits_150 : !quantum.bit
    %out_qubits_152 = quantum.custom "Hadamard"() %out_qubits_146#1 : !quantum.bit
    %out_qubits_153 = quantum.custom "RZ"(%cst_2) %out_qubits_152 : !quantum.bit
    %out_qubits_154 = quantum.custom "Hadamard"() %out_qubits_153 : !quantum.bit
    %out_qubits_155 = quantum.custom "RZ"(%cst) %out_qubits_154 : !quantum.bit
    %out_qubits_156 = quantum.custom "Hadamard"() %out_qubits_155 : !quantum.bit
    %out_qubits_157 = quantum.custom "RZ"(%cst_0) %out_qubits_156 : !quantum.bit
    %7 = quantum.compbasis qubits %out_qubits_123, %out_qubits_140, %out_qubits_95, %out_qubits_151, %out_qubits_101, %out_qubits_157 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x6xf64>
    %9 = stablehlo.convert %8 : (tensor<128x6xf64>) -> tensor<128x6xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_123 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_140 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_95 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_151 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_101 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_157 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x6xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}