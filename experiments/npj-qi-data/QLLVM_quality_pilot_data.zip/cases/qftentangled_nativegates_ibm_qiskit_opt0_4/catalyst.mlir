module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant 0.78539816339744828 : f64
    %cst_0 = arith.constant 0.000000e+00 : f64
    %cst_1 = arith.constant -0.19634954084936207 : f64
    %cst_2 = arith.constant 0.19634954084936207 : f64
    %cst_3 = arith.constant -0.39269908169872414 : f64
    %cst_4 = arith.constant 0.39269908169872414 : f64
    %cst_5 = arith.constant -0.78539816339744828 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Hadamard"() %1 : !quantum.bit
    %2 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_6 = quantum.custom "Hadamard"() %2 : !quantum.bit
    %3 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_7 = quantum.custom "RZ"(%cst_0) %3 : !quantum.bit
    %out_qubits_8 = quantum.custom "Hadamard"() %out_qubits_7 : !quantum.bit
    %out_qubits_9 = quantum.custom "RZ"(%cst_0) %out_qubits_8 : !quantum.bit
    %out_qubits_10:2 = quantum.custom "CZ"() %out_qubits_9, %out_qubits_6 : !quantum.bit, !quantum.bit
    %out_qubits_11 = quantum.custom "Hadamard"() %out_qubits_10#1 : !quantum.bit
    %out_qubits_12:2 = quantum.custom "CZ"() %out_qubits_11, %out_qubits : !quantum.bit, !quantum.bit
    %out_qubits_13 = quantum.custom "Hadamard"() %out_qubits_12#0 : !quantum.bit
    %out_qubits_14 = quantum.custom "RZ"(%cst_0) %out_qubits_10#0 : !quantum.bit
    %out_qubits_15 = quantum.custom "Hadamard"() %out_qubits_14 : !quantum.bit
    %out_qubits_16 = quantum.custom "RZ"(%cst) %out_qubits_15 : !quantum.bit
    %out_qubits_17:2 = quantum.custom "CZ"() %out_qubits_16, %out_qubits_13 : !quantum.bit, !quantum.bit
    %out_qubits_18 = quantum.custom "Hadamard"() %out_qubits_17#1 : !quantum.bit
    %out_qubits_19 = quantum.custom "RZ"(%cst_5) %out_qubits_18 : !quantum.bit
    %out_qubits_20 = quantum.custom "Hadamard"() %out_qubits_19 : !quantum.bit
    %out_qubits_21:2 = quantum.custom "CZ"() %out_qubits_17#0, %out_qubits_20 : !quantum.bit, !quantum.bit
    %out_qubits_22 = quantum.custom "Hadamard"() %out_qubits_21#1 : !quantum.bit
    %out_qubits_23 = quantum.custom "RZ"(%cst) %out_qubits_22 : !quantum.bit
    %out_qubits_24 = quantum.custom "Hadamard"() %out_qubits_23 : !quantum.bit
    %out_qubits_25 = quantum.custom "RZ"(%cst) %out_qubits_24 : !quantum.bit
    %4 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits_26 = quantum.custom "Hadamard"() %4 : !quantum.bit
    %out_qubits_27 = quantum.custom "Hadamard"() %out_qubits_12#1 : !quantum.bit
    %out_qubits_28:2 = quantum.custom "CZ"() %out_qubits_27, %out_qubits_26 : !quantum.bit, !quantum.bit
    %out_qubits_29 = quantum.custom "Hadamard"() %out_qubits_28#0 : !quantum.bit
    %out_qubits_30 = quantum.custom "RZ"(%cst_4) %out_qubits_21#0 : !quantum.bit
    %out_qubits_31:2 = quantum.custom "CZ"() %out_qubits_30, %out_qubits_29 : !quantum.bit, !quantum.bit
    %out_qubits_32 = quantum.custom "Hadamard"() %out_qubits_31#1 : !quantum.bit
    %out_qubits_33 = quantum.custom "RZ"(%cst_3) %out_qubits_32 : !quantum.bit
    %out_qubits_34 = quantum.custom "Hadamard"() %out_qubits_33 : !quantum.bit
    %out_qubits_35:2 = quantum.custom "CZ"() %out_qubits_31#0, %out_qubits_34 : !quantum.bit, !quantum.bit
    %out_qubits_36 = quantum.custom "Hadamard"() %out_qubits_35#1 : !quantum.bit
    %out_qubits_37 = quantum.custom "RZ"(%cst_4) %out_qubits_36 : !quantum.bit
    %out_qubits_38 = quantum.custom "Hadamard"() %out_qubits_37 : !quantum.bit
    %out_qubits_39:2 = quantum.custom "CZ"() %out_qubits_25, %out_qubits_38 : !quantum.bit, !quantum.bit
    %out_qubits_40 = quantum.custom "Hadamard"() %out_qubits_39#1 : !quantum.bit
    %out_qubits_41 = quantum.custom "RZ"(%cst_5) %out_qubits_40 : !quantum.bit
    %out_qubits_42 = quantum.custom "Hadamard"() %out_qubits_41 : !quantum.bit
    %out_qubits_43:2 = quantum.custom "CZ"() %out_qubits_39#0, %out_qubits_42 : !quantum.bit, !quantum.bit
    %out_qubits_44 = quantum.custom "Hadamard"() %out_qubits_43#1 : !quantum.bit
    %out_qubits_45 = quantum.custom "RZ"(%cst) %out_qubits_44 : !quantum.bit
    %out_qubits_46 = quantum.custom "Hadamard"() %out_qubits_45 : !quantum.bit
    %out_qubits_47 = quantum.custom "RZ"(%cst) %out_qubits_46 : !quantum.bit
    %out_qubits_48 = quantum.custom "RZ"(%cst_4) %out_qubits_43#0 : !quantum.bit
    %out_qubits_49 = quantum.custom "RZ"(%cst_2) %out_qubits_35#0 : !quantum.bit
    %out_qubits_50:2 = quantum.custom "CZ"() %out_qubits_49, %out_qubits_28#1 : !quantum.bit, !quantum.bit
    %out_qubits_51 = quantum.custom "Hadamard"() %out_qubits_50#1 : !quantum.bit
    %out_qubits_52 = quantum.custom "RZ"(%cst_1) %out_qubits_51 : !quantum.bit
    %out_qubits_53 = quantum.custom "Hadamard"() %out_qubits_52 : !quantum.bit
    %out_qubits_54:2 = quantum.custom "CZ"() %out_qubits_50#0, %out_qubits_53 : !quantum.bit, !quantum.bit
    %out_qubits_55 = quantum.custom "Hadamard"() %out_qubits_54#1 : !quantum.bit
    %out_qubits_56 = quantum.custom "RZ"(%cst_2) %out_qubits_55 : !quantum.bit
    %out_qubits_57 = quantum.custom "Hadamard"() %out_qubits_56 : !quantum.bit
    %out_qubits_58:2 = quantum.custom "CZ"() %out_qubits_48, %out_qubits_57 : !quantum.bit, !quantum.bit
    %out_qubits_59 = quantum.custom "Hadamard"() %out_qubits_58#1 : !quantum.bit
    %out_qubits_60 = quantum.custom "RZ"(%cst_3) %out_qubits_59 : !quantum.bit
    %out_qubits_61 = quantum.custom "Hadamard"() %out_qubits_60 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_58#0, %out_qubits_61 : !quantum.bit, !quantum.bit
    %out_qubits_63 = quantum.custom "Hadamard"() %out_qubits_62#1 : !quantum.bit
    %out_qubits_64 = quantum.custom "RZ"(%cst_4) %out_qubits_63 : !quantum.bit
    %out_qubits_65 = quantum.custom "Hadamard"() %out_qubits_64 : !quantum.bit
    %out_qubits_66:2 = quantum.custom "CZ"() %out_qubits_47, %out_qubits_65 : !quantum.bit, !quantum.bit
    %out_qubits_67 = quantum.custom "Hadamard"() %out_qubits_66#1 : !quantum.bit
    %out_qubits_68 = quantum.custom "RZ"(%cst_5) %out_qubits_67 : !quantum.bit
    %out_qubits_69 = quantum.custom "Hadamard"() %out_qubits_68 : !quantum.bit
    %out_qubits_70:2 = quantum.custom "CZ"() %out_qubits_66#0, %out_qubits_69 : !quantum.bit, !quantum.bit
    %out_qubits_71 = quantum.custom "Hadamard"() %out_qubits_62#0 : !quantum.bit
    %out_qubits_72:2 = quantum.custom "CZ"() %out_qubits_70#0, %out_qubits_71 : !quantum.bit, !quantum.bit
    %out_qubits_73 = quantum.custom "Hadamard"() %out_qubits_72#0 : !quantum.bit
    %out_qubits_74 = quantum.custom "Hadamard"() %out_qubits_72#1 : !quantum.bit
    %out_qubits_75:2 = quantum.custom "CZ"() %out_qubits_74, %out_qubits_73 : !quantum.bit, !quantum.bit
    %out_qubits_76 = quantum.custom "Hadamard"() %out_qubits_75#1 : !quantum.bit
    %out_qubits_77 = quantum.custom "Hadamard"() %out_qubits_75#0 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_76, %out_qubits_77 : !quantum.bit, !quantum.bit
    %out_qubits_79 = quantum.custom "Hadamard"() %out_qubits_78#1 : !quantum.bit
    %out_qubits_80 = quantum.custom "Hadamard"() %out_qubits_70#1 : !quantum.bit
    %out_qubits_81 = quantum.custom "RZ"(%cst) %out_qubits_80 : !quantum.bit
    %out_qubits_82 = quantum.custom "Hadamard"() %out_qubits_81 : !quantum.bit
    %out_qubits_83 = quantum.custom "RZ"(%cst_0) %out_qubits_82 : !quantum.bit
    %out_qubits_84 = quantum.custom "Hadamard"() %out_qubits_54#0 : !quantum.bit
    %out_qubits_85:2 = quantum.custom "CZ"() %out_qubits_83, %out_qubits_84 : !quantum.bit, !quantum.bit
    %out_qubits_86 = quantum.custom "Hadamard"() %out_qubits_85#0 : !quantum.bit
    %out_qubits_87 = quantum.custom "Hadamard"() %out_qubits_85#1 : !quantum.bit
    %out_qubits_88:2 = quantum.custom "CZ"() %out_qubits_87, %out_qubits_86 : !quantum.bit, !quantum.bit
    %out_qubits_89 = quantum.custom "Hadamard"() %out_qubits_88#1 : !quantum.bit
    %out_qubits_90 = quantum.custom "Hadamard"() %out_qubits_88#0 : !quantum.bit
    %out_qubits_91:2 = quantum.custom "CZ"() %out_qubits_89, %out_qubits_90 : !quantum.bit, !quantum.bit
    %out_qubits_92 = quantum.custom "Hadamard"() %out_qubits_91#1 : !quantum.bit
    %5 = quantum.compbasis qubits %out_qubits_91#0, %out_qubits_78#0, %out_qubits_79, %out_qubits_92 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_91#0 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_78#0 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_79 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_92 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}