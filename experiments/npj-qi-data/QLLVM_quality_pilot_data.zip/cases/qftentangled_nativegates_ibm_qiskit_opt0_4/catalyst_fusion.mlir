module @circuit {
  func.func public @jit_circuit() -> tensor<128x4xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x4xi64>
    return %0 : tensor<128x4xi64>
  }
  func.func public @circuit_0() -> tensor<128x4xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -3.1415926535897931 : f64
    %cst_0 = arith.constant -70.685834705770375 : f64
    %cst_1 = arith.constant 4.5160394395353274 : f64
    %cst_2 = arith.constant 3.9269908169872414 : f64
    %cst_3 = arith.constant 4.3196898986859651 : f64
    %cst_4 = arith.constant 1.570796326794897 : f64
    %cst_5 = arith.constant 0.19634954084936121 : f64
    %cst_6 = arith.constant -1.5707963267948966 : f64
    %cst_7 = arith.constant 0.3926990816987232 : f64
    %cst_8 = arith.constant 0.39269908169872436 : f64
    %cst_9 = arith.constant -1.5707963267948963 : f64
    %cst_10 = arith.constant 0.78539816339744783 : f64
    %cst_11 = arith.constant -4.7123889803846897 : f64
    %cst_12 = arith.constant 0.78539816339744839 : f64
    %cst_13 = arith.constant 4.7123889803846897 : f64
    %cst_14 = arith.constant 0.000000e+00 : f64
    %cst_15 = arith.constant 1.5707963267948966 : f64
    %cst_16 = arith.constant 3.1415926535897931 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 4) : !quantum.reg
    %1 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %1 : !quantum.bit
    %2 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_17 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %2 : !quantum.bit
    %3 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_18 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %3 : !quantum.bit
    %out_qubits_19:2 = quantum.custom "CZ"() %out_qubits_18, %out_qubits_17 : !quantum.bit, !quantum.bit
    %out_qubits_20 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_19#1 : !quantum.bit
    %out_qubits_21:2 = quantum.custom "CZ"() %out_qubits_20, %out_qubits : !quantum.bit, !quantum.bit
    %out_qubits_22 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_21#0 : !quantum.bit
    %out_qubits_23 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_19#0 : !quantum.bit
    %out_qubits_24:2 = quantum.custom "CZ"() %out_qubits_23, %out_qubits_22 : !quantum.bit, !quantum.bit
    %out_qubits_25 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_15) %out_qubits_24#1 : !quantum.bit
    %out_qubits_26:2 = quantum.custom "CZ"() %out_qubits_24#0, %out_qubits_25 : !quantum.bit, !quantum.bit
    %out_qubits_27 = quantum.custom "Rot"(%cst_11, %cst_10, %cst_9) %out_qubits_26#1 : !quantum.bit
    %4 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits_28 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %4 : !quantum.bit
    %out_qubits_29 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_21#1 : !quantum.bit
    %out_qubits_30:2 = quantum.custom "CZ"() %out_qubits_29, %out_qubits_28 : !quantum.bit, !quantum.bit
    %out_qubits_31 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_30#0 : !quantum.bit
    %out_qubits_32:2 = quantum.custom "CZ"() %out_qubits_26#0, %out_qubits_31 : !quantum.bit, !quantum.bit
    %out_qubits_33 = quantum.custom "Rot"(%cst_13, %cst_8, %cst_15) %out_qubits_32#1 : !quantum.bit
    %out_qubits_34:2 = quantum.custom "CZ"() %out_qubits_32#0, %out_qubits_33 : !quantum.bit, !quantum.bit
    %out_qubits_35 = quantum.custom "Rot"(%cst_11, %cst_7, %cst_6) %out_qubits_34#1 : !quantum.bit
    %out_qubits_36:2 = quantum.custom "CZ"() %out_qubits_27, %out_qubits_35 : !quantum.bit, !quantum.bit
    %out_qubits_37 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_15) %out_qubits_36#1 : !quantum.bit
    %out_qubits_38:2 = quantum.custom "CZ"() %out_qubits_36#0, %out_qubits_37 : !quantum.bit, !quantum.bit
    %out_qubits_39:2 = quantum.custom "CZ"() %out_qubits_34#0, %out_qubits_30#1 : !quantum.bit, !quantum.bit
    %out_qubits_40 = quantum.custom "Rot"(%cst_13, %cst_5, %cst_4) %out_qubits_39#1 : !quantum.bit
    %out_qubits_41:2 = quantum.custom "CZ"() %out_qubits_39#0, %out_qubits_40 : !quantum.bit, !quantum.bit
    %out_qubits_42 = quantum.custom "Rot"(%cst_15, %cst_5, %cst_13) %out_qubits_41#1 : !quantum.bit
    %out_qubits_43:2 = quantum.custom "CZ"() %out_qubits_38#0, %out_qubits_42 : !quantum.bit, !quantum.bit
    %out_qubits_44 = quantum.custom "Rot"(%cst_13, %cst_8, %cst_15) %out_qubits_43#1 : !quantum.bit
    %out_qubits_45:2 = quantum.custom "CZ"() %out_qubits_43#0, %out_qubits_44 : !quantum.bit, !quantum.bit
    %out_qubits_46 = quantum.custom "Rot"(%cst_3, %cst_15, %cst_14) %out_qubits_45#0 : !quantum.bit
    %out_qubits_47 = quantum.custom "Rot"(%cst_11, %cst_10, %cst_9) %out_qubits_38#1 : !quantum.bit
    %out_qubits_48 = quantum.custom "Rot"(%cst_11, %cst_7, %cst_6) %out_qubits_45#1 : !quantum.bit
    %out_qubits_49:2 = quantum.custom "CZ"() %out_qubits_47, %out_qubits_48 : !quantum.bit, !quantum.bit
    %out_qubits_50 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_15) %out_qubits_49#1 : !quantum.bit
    %out_qubits_51:2 = quantum.custom "CZ"() %out_qubits_49#0, %out_qubits_50 : !quantum.bit, !quantum.bit
    %out_qubits_52:2 = quantum.custom "CZ"() %out_qubits_51#0, %out_qubits_46 : !quantum.bit, !quantum.bit
    %out_qubits_53 = quantum.custom "Rot"(%cst_2, %cst_15, %cst_14) %out_qubits_52#0 : !quantum.bit
    %out_qubits_54 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_52#1 : !quantum.bit
    %out_qubits_55:2 = quantum.custom "CZ"() %out_qubits_54, %out_qubits_53 : !quantum.bit, !quantum.bit
    %out_qubits_56 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_55#1 : !quantum.bit
    %out_qubits_57 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_55#0 : !quantum.bit
    %out_qubits_58:2 = quantum.custom "CZ"() %out_qubits_56, %out_qubits_57 : !quantum.bit, !quantum.bit
    %out_qubits_59 = quantum.custom "Hadamard"() %out_qubits_58#1 : !quantum.bit
    %out_qubits_60 = quantum.custom "Rot"(%cst_1, %cst_15, %cst_14) %out_qubits_41#0 : !quantum.bit
    %out_qubits_61 = quantum.custom "Rot"(%cst_11, %cst_10, %cst_9) %out_qubits_51#1 : !quantum.bit
    %out_qubits_62:2 = quantum.custom "CZ"() %out_qubits_61, %out_qubits_60 : !quantum.bit, !quantum.bit
    %out_qubits_63 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_62#0 : !quantum.bit
    %out_qubits_64 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_62#1 : !quantum.bit
    %out_qubits_65:2 = quantum.custom "CZ"() %out_qubits_64, %out_qubits_63 : !quantum.bit, !quantum.bit
    %out_qubits_66 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_65#1 : !quantum.bit
    %out_qubits_67 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_65#0 : !quantum.bit
    %out_qubits_68:2 = quantum.custom "CZ"() %out_qubits_66, %out_qubits_67 : !quantum.bit, !quantum.bit
    %out_qubits_69 = quantum.custom "Hadamard"() %out_qubits_68#1 : !quantum.bit
    quantum.gphase(%cst_0)
    quantum.gphase(%cst)
    %5 = quantum.compbasis qubits %out_qubits_68#0, %out_qubits_58#0, %out_qubits_59, %out_qubits_69 : !quantum.obs
    %6 = quantum.sample %5 : tensor<128x4xf64>
    %7 = stablehlo.convert %6 : (tensor<128x4xf64>) -> tensor<128x4xi64>
    %8 = quantum.insert %0[ 0], %out_qubits_68#0 : !quantum.reg, !quantum.bit
    %9 = quantum.insert %8[ 1], %out_qubits_58#0 : !quantum.reg, !quantum.bit
    %10 = quantum.insert %9[ 2], %out_qubits_59 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 3], %out_qubits_69 : !quantum.reg, !quantum.bit
    quantum.dealloc %11 : !quantum.reg
    quantum.device_release
    return %7 : tensor<128x4xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}