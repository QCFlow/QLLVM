module @circuit {
  func.func public @jit_circuit() -> tensor<128x6xi64> attributes {llvm.emit_c_interface} {
    %0 = call @circuit_0() : () -> tensor<128x6xi64>
    return %0 : tensor<128x6xi64>
  }
  func.func public @circuit_0() -> tensor<128x6xi64> attributes {diff_method = "parameter-shift", llvm.linkage = #llvm.linkage<internal>, qnode} {
    %cst = arith.constant -122.52211349000179 : f64
    %cst_0 = arith.constant 11.837122008038477 : f64
    %cst_1 = arith.constant 0.43534303317278977 : f64
    %cst_2 = arith.constant 3.1415926535897944 : f64
    %cst_3 = arith.constant 11.284360208923566 : f64
    %cst_4 = arith.constant 2.8426000178928454 : f64
    %cst_5 = arith.constant -3.1415926535897944 : f64
    %cst_6 = arith.constant 14.16636924828677 : f64
    %cst_7 = arith.constant 2.3481070988340424 : f64
    %cst_8 = arith.constant 14.775869311669789 : f64
    %cst_9 = arith.constant 0.29465826494733499 : f64
    %cst_10 = arith.constant -4.4408920985006262E-16 : f64
    %cst_11 = arith.constant 14.808527191624192 : f64
    %cst_12 = arith.constant 1.0764269733891008 : f64
    %cst_13 = arith.constant -3.1415926535897931 : f64
    %cst_14 = arith.constant 13.816394872568614 : f64
    %cst_15 = arith.constant 0.7161848677092969 : f64
    %cst_16 = arith.constant 0.34697757895499803 : f64
    %cst_17 = arith.constant 0.91112076882565751 : f64
    %cst_18 = arith.constant 1.3158692961889544 : f64
    %cst_19 = arith.constant 1.7639412205077341 : f64
    %cst_20 = arith.constant 2.5014569888136133 : f64
    %cst_21 = arith.constant 2.3227347086368741 : f64
    %cst_22 = arith.constant -0.82858357393955318 : f64
    %cst_23 = arith.constant 3.0667011445232597 : f64
    %cst_24 = arith.constant 1.5360396587471263 : f64
    %cst_25 = arith.constant -2.0045172746307292 : f64
    %cst_26 = arith.constant -2.6813613253075204 : f64
    %cst_27 = arith.constant 2.1726877290836448 : f64
    %cst_28 = arith.constant 0.71913973151642263 : f64
    %cst_29 = arith.constant -3.2011988090675811 : f64
    %cst_30 = arith.constant 1.9813375686540029 : f64
    %cst_31 = arith.constant 2.9931658779780626 : f64
    %cst_32 = arith.constant 4.7123889803846915 : f64
    %cst_33 = arith.constant 2.7761197097590848 : f64
    %cst_34 = arith.constant 1.0541559014982735 : f64
    %cst_35 = arith.constant 3.3765060662168525 : f64
    %cst_36 = arith.constant 1.4511732180707282 : f64
    %cst_37 = arith.constant -1.1082459019813848 : f64
    %cst_38 = arith.constant 1.816754086861865 : f64
    %cst_39 = arith.constant 0.81109171284582304 : f64
    %cst_40 = arith.constant -1.741997319036557 : f64
    %cst_41 = arith.constant 2.5542853911276731 : f64
    %cst_42 = arith.constant 1.9901723079714082 : f64
    %cst_43 = arith.constant -1.0218131513545701 : f64
    %cst_44 = arith.constant -0.56670293282505302 : f64
    %cst_45 = arith.constant 0.47172422621340132 : f64
    %cst_46 = arith.constant 0.62028734590677126 : f64
    %cst_47 = arith.constant -3.0668690230508249 : f64
    %cst_48 = arith.constant 1.5539017107196835 : f64
    %cst_49 = arith.constant 1.7927417216749149 : f64
    %cst_50 = arith.constant 0.000000e+00 : f64
    %cst_51 = arith.constant 3.1415926535897931 : f64
    %cst_52 = arith.constant -1.5707963267948977 : f64
    %cst_53 = arith.constant 0.0248076889803788 : f64
    %cst_54 = arith.constant 2.8152620085504649 : f64
    %cst_55 = arith.constant 1.0654948831370639 : f64
    %cst_56 = arith.constant 0.33182699024759915 : f64
    %cst_57 = arith.constant -4.2304890670610673 : f64
    %cst_58 = arith.constant -3.1502102914095635 : f64
    %cst_59 = arith.constant 1.5745023402095135 : f64
    %cst_60 = arith.constant 1.9769265976219899 : f64
    %cst_61 = arith.constant 1.585056661820744 : f64
    %cst_62 = arith.constant 2.5864916893702405 : f64
    %cst_63 = arith.constant -1.5586769923454507 : f64
    %cst_64 = arith.constant 2.3693126830932099 : f64
    %cst_65 = arith.constant 1.9415188372998071 : f64
    %cst_66 = arith.constant -1.2147277699109287 : f64
    %cst_67 = arith.constant 0.13010624007666083 : f64
    %cst_68 = arith.constant 1.5621995923300571 : f64
    %cst_69 = arith.constant -4.646782602283638 : f64
    %cst_70 = arith.constant 1.5707963267948966 : f64
    %cst_71 = arith.constant 1.4368347742816614 : f64
    %cst_72 = arith.constant -3.141592653589794 : f64
    %c128_i64 = arith.constant 128 : i64
    quantum.device shots(%c128_i64) ["/home/easyai/qllvm-r14-claims-20261101/pilot/venv/lib/python3.11/site-packages/pennylane_lightning/liblightning_qubit_catalyst.so", "LightningSimulator", "{'mcmc': False, 'num_burnin': 0, 'kernel_name': None}"]
    %0 = quantum.alloc( 6) : !quantum.reg
    %1 = quantum.extract %0[ 0] : !quantum.reg -> !quantum.bit
    %out_qubits = quantum.custom "Rot"(%cst_72, %cst_71, %cst_70) %1 : !quantum.bit
    %2 = quantum.extract %0[ 1] : !quantum.reg -> !quantum.bit
    %out_qubits_73 = quantum.custom "Rot"(%cst_69, %cst_68, %cst_67) %2 : !quantum.bit
    %out_qubits_74:2 = quantum.custom "CZ"() %out_qubits, %out_qubits_73 : !quantum.bit, !quantum.bit
    %3 = quantum.extract %0[ 2] : !quantum.reg -> !quantum.bit
    %out_qubits_75 = quantum.custom "Rot"(%cst_66, %cst_65, %cst_64) %3 : !quantum.bit
    %out_qubits_76:2 = quantum.custom "CZ"() %out_qubits_74#0, %out_qubits_75 : !quantum.bit, !quantum.bit
    %4 = quantum.extract %0[ 3] : !quantum.reg -> !quantum.bit
    %out_qubits_77 = quantum.custom "Rot"(%cst_63, %cst_62, %cst_61) %4 : !quantum.bit
    %out_qubits_78:2 = quantum.custom "CZ"() %out_qubits_76#0, %out_qubits_77 : !quantum.bit, !quantum.bit
    %5 = quantum.extract %0[ 4] : !quantum.reg -> !quantum.bit
    %out_qubits_79 = quantum.custom "Rot"(%cst_60, %cst_59, %cst_58) %5 : !quantum.bit
    %out_qubits_80:2 = quantum.custom "CZ"() %out_qubits_78#0, %out_qubits_79 : !quantum.bit, !quantum.bit
    %6 = quantum.extract %0[ 5] : !quantum.reg -> !quantum.bit
    %out_qubits_81 = quantum.custom "Rot"(%cst_57, %cst_56, %cst_55) %6 : !quantum.bit
    %out_qubits_82:2 = quantum.custom "CZ"() %out_qubits_80#0, %out_qubits_81 : !quantum.bit, !quantum.bit
    %out_qubits_83 = quantum.custom "Rot"(%cst_54, %cst_53, %cst_52) %out_qubits_82#0 : !quantum.bit
    %out_qubits_84 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_74#1 : !quantum.bit
    %out_qubits_85:2 = quantum.custom "CZ"() %out_qubits_84, %out_qubits_76#1 : !quantum.bit, !quantum.bit
    %out_qubits_86:2 = quantum.custom "CZ"() %out_qubits_85#0, %out_qubits_78#1 : !quantum.bit, !quantum.bit
    %out_qubits_87:2 = quantum.custom "CZ"() %out_qubits_86#0, %out_qubits_80#1 : !quantum.bit, !quantum.bit
    %out_qubits_88:2 = quantum.custom "CZ"() %out_qubits_87#0, %out_qubits_82#1 : !quantum.bit, !quantum.bit
    %out_qubits_89 = quantum.custom "Rot"(%cst_49, %cst_48, %cst_47) %out_qubits_88#0 : !quantum.bit
    %out_qubits_90:2 = quantum.custom "CZ"() %out_qubits_83, %out_qubits_89 : !quantum.bit, !quantum.bit
    %out_qubits_91 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_85#1 : !quantum.bit
    %out_qubits_92:2 = quantum.custom "CZ"() %out_qubits_91, %out_qubits_86#1 : !quantum.bit, !quantum.bit
    %out_qubits_93:2 = quantum.custom "CZ"() %out_qubits_92#0, %out_qubits_87#1 : !quantum.bit, !quantum.bit
    %out_qubits_94:2 = quantum.custom "CZ"() %out_qubits_93#0, %out_qubits_88#1 : !quantum.bit, !quantum.bit
    %out_qubits_95 = quantum.custom "Rot"(%cst_46, %cst_45, %cst_44) %out_qubits_94#0 : !quantum.bit
    %out_qubits_96:2 = quantum.custom "CZ"() %out_qubits_90#0, %out_qubits_95 : !quantum.bit, !quantum.bit
    %out_qubits_97 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_92#1 : !quantum.bit
    %out_qubits_98:2 = quantum.custom "CZ"() %out_qubits_97, %out_qubits_93#1 : !quantum.bit, !quantum.bit
    %out_qubits_99:2 = quantum.custom "CZ"() %out_qubits_98#0, %out_qubits_94#1 : !quantum.bit, !quantum.bit
    %out_qubits_100 = quantum.custom "Rot"(%cst_43, %cst_42, %cst_41) %out_qubits_99#0 : !quantum.bit
    %out_qubits_101:2 = quantum.custom "CZ"() %out_qubits_96#0, %out_qubits_100 : !quantum.bit, !quantum.bit
    %out_qubits_102 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_98#1 : !quantum.bit
    %out_qubits_103:2 = quantum.custom "CZ"() %out_qubits_102, %out_qubits_99#1 : !quantum.bit, !quantum.bit
    %out_qubits_104 = quantum.custom "Rot"(%cst_40, %cst_39, %cst_38) %out_qubits_103#0 : !quantum.bit
    %out_qubits_105:2 = quantum.custom "CZ"() %out_qubits_101#0, %out_qubits_104 : !quantum.bit, !quantum.bit
    %out_qubits_106 = quantum.custom "Rot"(%cst_37, %cst_36, %cst_35) %out_qubits_103#1 : !quantum.bit
    %out_qubits_107:2 = quantum.custom "CZ"() %out_qubits_105#0, %out_qubits_106 : !quantum.bit, !quantum.bit
    %out_qubits_108 = quantum.custom "Rot"(%cst_34, %cst_33, %cst_32) %out_qubits_107#0 : !quantum.bit
    %out_qubits_109 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_90#1 : !quantum.bit
    %out_qubits_110:2 = quantum.custom "CZ"() %out_qubits_109, %out_qubits_96#1 : !quantum.bit, !quantum.bit
    %out_qubits_111:2 = quantum.custom "CZ"() %out_qubits_110#0, %out_qubits_101#1 : !quantum.bit, !quantum.bit
    %out_qubits_112:2 = quantum.custom "CZ"() %out_qubits_111#0, %out_qubits_105#1 : !quantum.bit, !quantum.bit
    %out_qubits_113:2 = quantum.custom "CZ"() %out_qubits_112#0, %out_qubits_107#1 : !quantum.bit, !quantum.bit
    %out_qubits_114 = quantum.custom "Rot"(%cst_31, %cst_30, %cst_29) %out_qubits_113#0 : !quantum.bit
    %out_qubits_115:2 = quantum.custom "CZ"() %out_qubits_108, %out_qubits_114 : !quantum.bit, !quantum.bit
    %out_qubits_116 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_110#1 : !quantum.bit
    %out_qubits_117:2 = quantum.custom "CZ"() %out_qubits_116, %out_qubits_111#1 : !quantum.bit, !quantum.bit
    %out_qubits_118:2 = quantum.custom "CZ"() %out_qubits_117#0, %out_qubits_112#1 : !quantum.bit, !quantum.bit
    %out_qubits_119:2 = quantum.custom "CZ"() %out_qubits_118#0, %out_qubits_113#1 : !quantum.bit, !quantum.bit
    %out_qubits_120 = quantum.custom "Rot"(%cst_28, %cst_27, %cst_26) %out_qubits_119#0 : !quantum.bit
    %out_qubits_121:2 = quantum.custom "CZ"() %out_qubits_115#0, %out_qubits_120 : !quantum.bit, !quantum.bit
    %out_qubits_122 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_117#1 : !quantum.bit
    %out_qubits_123:2 = quantum.custom "CZ"() %out_qubits_122, %out_qubits_118#1 : !quantum.bit, !quantum.bit
    %out_qubits_124:2 = quantum.custom "CZ"() %out_qubits_123#0, %out_qubits_119#1 : !quantum.bit, !quantum.bit
    %out_qubits_125 = quantum.custom "Rot"(%cst_25, %cst_24, %cst_23) %out_qubits_124#0 : !quantum.bit
    %out_qubits_126:2 = quantum.custom "CZ"() %out_qubits_121#0, %out_qubits_125 : !quantum.bit, !quantum.bit
    %out_qubits_127 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_123#1 : !quantum.bit
    %out_qubits_128:2 = quantum.custom "CZ"() %out_qubits_127, %out_qubits_124#1 : !quantum.bit, !quantum.bit
    %out_qubits_129 = quantum.custom "Rot"(%cst_22, %cst_21, %cst_20) %out_qubits_128#0 : !quantum.bit
    %out_qubits_130:2 = quantum.custom "CZ"() %out_qubits_126#0, %out_qubits_129 : !quantum.bit, !quantum.bit
    %out_qubits_131 = quantum.custom "Rot"(%cst_19, %cst_18, %cst_17) %out_qubits_128#1 : !quantum.bit
    %out_qubits_132:2 = quantum.custom "CZ"() %out_qubits_130#0, %out_qubits_131 : !quantum.bit, !quantum.bit
    %out_qubits_133 = quantum.custom "Rot"(%cst_16, %cst_15, %cst_14) %out_qubits_132#0 : !quantum.bit
    %out_qubits_134 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_115#1 : !quantum.bit
    %out_qubits_135:2 = quantum.custom "CZ"() %out_qubits_134, %out_qubits_121#1 : !quantum.bit, !quantum.bit
    %out_qubits_136:2 = quantum.custom "CZ"() %out_qubits_135#0, %out_qubits_126#1 : !quantum.bit, !quantum.bit
    %out_qubits_137:2 = quantum.custom "CZ"() %out_qubits_136#0, %out_qubits_130#1 : !quantum.bit, !quantum.bit
    %out_qubits_138:2 = quantum.custom "CZ"() %out_qubits_137#0, %out_qubits_132#1 : !quantum.bit, !quantum.bit
    %out_qubits_139 = quantum.custom "Rot"(%cst_13, %cst_12, %cst_11) %out_qubits_138#0 : !quantum.bit
    %out_qubits_140 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_135#1 : !quantum.bit
    %out_qubits_141:2 = quantum.custom "CZ"() %out_qubits_140, %out_qubits_136#1 : !quantum.bit, !quantum.bit
    %out_qubits_142:2 = quantum.custom "CZ"() %out_qubits_141#0, %out_qubits_137#1 : !quantum.bit, !quantum.bit
    %out_qubits_143:2 = quantum.custom "CZ"() %out_qubits_142#0, %out_qubits_138#1 : !quantum.bit, !quantum.bit
    %out_qubits_144 = quantum.custom "Rot"(%cst_10, %cst_9, %cst_8) %out_qubits_143#0 : !quantum.bit
    %out_qubits_145 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_141#1 : !quantum.bit
    %out_qubits_146:2 = quantum.custom "CZ"() %out_qubits_145, %out_qubits_142#1 : !quantum.bit, !quantum.bit
    %out_qubits_147:2 = quantum.custom "CZ"() %out_qubits_146#0, %out_qubits_143#1 : !quantum.bit, !quantum.bit
    %out_qubits_148 = quantum.custom "Rot"(%cst_72, %cst_7, %cst_6) %out_qubits_147#0 : !quantum.bit
    %out_qubits_149 = quantum.custom "Rot"(%cst_51, %cst_70, %cst_50) %out_qubits_146#1 : !quantum.bit
    %out_qubits_150:2 = quantum.custom "CZ"() %out_qubits_149, %out_qubits_147#1 : !quantum.bit, !quantum.bit
    %out_qubits_151 = quantum.custom "Rot"(%cst_5, %cst_4, %cst_3) %out_qubits_150#0 : !quantum.bit
    %out_qubits_152 = quantum.custom "Rot"(%cst_2, %cst_1, %cst_0) %out_qubits_150#1 : !quantum.bit
    quantum.gphase(%cst)
    %7 = quantum.compbasis qubits %out_qubits_133, %out_qubits_139, %out_qubits_144, %out_qubits_148, %out_qubits_151, %out_qubits_152 : !quantum.obs
    %8 = quantum.sample %7 : tensor<128x6xf64>
    %9 = stablehlo.convert %8 : (tensor<128x6xf64>) -> tensor<128x6xi64>
    %10 = quantum.insert %0[ 0], %out_qubits_133 : !quantum.reg, !quantum.bit
    %11 = quantum.insert %10[ 1], %out_qubits_139 : !quantum.reg, !quantum.bit
    %12 = quantum.insert %11[ 2], %out_qubits_144 : !quantum.reg, !quantum.bit
    %13 = quantum.insert %12[ 3], %out_qubits_148 : !quantum.reg, !quantum.bit
    %14 = quantum.insert %13[ 4], %out_qubits_151 : !quantum.reg, !quantum.bit
    %15 = quantum.insert %14[ 5], %out_qubits_152 : !quantum.reg, !quantum.bit
    quantum.dealloc %15 : !quantum.reg
    quantum.device_release
    return %9 : tensor<128x6xi64>
  }
  func.func @setup() {
    quantum.init
    return
  }
  func.func @teardown() {
    quantum.finalize
    return
  }
}