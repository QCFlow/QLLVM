from pathlib import Path
import os
for n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[n]='1'
import json,numpy as np
from qiskit import QuantumCircuit,qasm2
from qiskit.quantum_info import Operator
R=Path(__file__).resolve().parents[1]
s=(R/'scripts/analyze_native.py').read_text();g={'QuantumCircuit':QuantumCircuit,'np':np};exec(s[s.index('def circuit('):s.index('manifest=')],g)
results=[]
for row in json.loads((R/'manifest.json').read_text()):
    d=R/'cases'/row['case'];definition=json.loads((d/'input.json').read_text())
    for mode in ['xacc','qcor1','qcor2','qcor_precision']:
        path=d/(mode+'_native_export.qasm')
        status=next(x for x in json.loads((R/'results/native_quality_results.json').read_text()) if x['case']==row['case'] and x['mode']==mode)['compiled_status']
        if status!='compiled_extracted':continue
        q=g['circuit'](json.loads((d/(mode+'.json')).read_text()),definition);native=qasm2.load(path)
        def mp(c):return sorted((c.find_bit(i.qubits[0]).index,c.find_bit(i.clbits[0]).index) for i in c.data if i.operation.name=='measure')
        assert mp(q)==mp(native),(row['case'],mode,mp(q),mp(native))
        a=Operator(q.remove_final_measurements(inplace=False)).data;b=Operator(native.remove_final_measurements(inplace=False)).data
        phase=np.vdot(a,b);phase=phase/abs(phase)
        error=float(np.linalg.norm(a-phase.conjugate()*b));assert error<1e-9,(row['case'],mode,error)
        results.append({'case':row['case'],'mode':mode,'export_operator_residual':error})
(R/'results/native_export_audit.json').write_text(json.dumps({'outputs':len(results),'max_residual':max(x['export_operator_residual'] for x in results),'all_passed':True,'results':results},indent=2))
print('Native export audit',len(results),'outputs; max residual',max(x['export_operator_residual'] for x in results))
