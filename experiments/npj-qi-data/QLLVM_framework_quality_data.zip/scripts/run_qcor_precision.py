from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,subprocess,os,time,hashlib
R=Path(__file__).resolve().parents[1];P=R/'stack/usr/local/aideqc/qcor'
env=dict(os.environ);env['LD_LIBRARY_PATH']=':'.join(str(x) for x in [P/'lib',P/'plugins',P/'clang-plugins',P.parent/'llvm/lib'])
env['OMP_NUM_THREADS']='1';env['OPENBLAS_NUM_THREADS']='1'
manifest=json.loads((R/'manifest.json').read_text())
source=(R/'scripts/run_native.py').read_text();exec(source[source.index('def run('):source.index('results=[]')])
results=[]
with ThreadPoolExecutor(max_workers=4) as pool:
    for f in as_completed([pool.submit(run,row,'qcor_precision') for row in manifest]):
        rec=f.result();results.append(rec);print(len(results),55,rec['case'],rec['status'],flush=True)
        (R/'results/qcor_precision_compile_results.json').write_text(json.dumps(results,indent=2))
