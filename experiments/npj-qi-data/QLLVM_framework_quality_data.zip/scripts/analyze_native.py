from pathlib import Path
import os
for n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[n]='1'
import json,traceback,statistics,hashlib
import numpy as np
from qiskit import QuantumCircuit,qasm2,transpile
from qiskit.quantum_info import Operator
from qiskit.transpiler import PassManager
from qiskit.transpiler.passes import Optimize1qGatesDecomposition
R=Path(__file__).resolve().parents[1];BASIS=['rx','ry','rz','h','cz']
helper=Path(__file__).resolve().with_name('analyze_pilot.py').read_text()
g={'np':np,'Operator':Operator,'protocol':{'basis':BASIS}}
exec(helper[helper.index('def mapping'):helper.index('results=[]')],g)
def circuit(data,definition):
    q=QuantumCircuit(definition['n'],definition['ncl'])
    names={'H':'h','X':'x','Y':'y','Z':'z','S':'s','Sdg':'sdg','T':'t','Tdg':'tdg','Rx':'rx','Ry':'ry','Rz':'rz','CZ':'cz','CNOT':'cx','Swap':'swap','U':'u','U1':'p','U2':'u2','U3':'u'}
    for name,params,wires in data['gates']:
        op=names[name]
        if op=='u2':q.u(np.pi/2,*params,*wires)
        else:getattr(q,op)(*params,*wires)
    for wire,bit in data['measurements']:q.measure(wire,bit)
    return q
manifest=json.loads((R/'manifest.json').read_text());compile_results=json.loads((R/'results/native_compile_results.json').read_text())
lookup={(x['case'],x['mode']):x for x in compile_results};out=[]
modes=['xacc','qcor1','qcor2']
if (R/'results/qcor_precision_compile_results.json').exists():
    more=json.loads((R/'results/qcor_precision_compile_results.json').read_text());lookup.update({(x['case'],x['mode']):x for x in more});modes.append('qcor_precision')
for row in manifest:
    d=R/'cases'/row['case'];dat=json.loads((d/'input.json').read_text());reference=qasm2.load(d/'input.qasm');ref=g['effects'](reference);mp=g['mapping'](reference)
    for mode in modes:
        rec={'case':row['case'],'mode':mode,'compiled_status':lookup.get((row['case'],mode),{}).get('status','missing')}
        try:
            assert rec['compiled_status']=='compiled_extracted',rec['compiled_status']
            imported=circuit(json.loads((d/(mode+'_imported.json')).read_text()),dat)
            native=circuit(json.loads((d/(mode+'.json')).read_text()),dat)
            raw=transpile(native,basis_gates=BASIS,optimization_level=0,seed_transpiler=0,coupling_map=None)
            norm=PassManager([Optimize1qGatesDecomposition(basis=BASIS)]).run(raw)
            circuits={'imported':imported,'raw':raw,'normalized':norm}
            for suffix in ['','_normalized']:
                p=d/('qllvm'+suffix+'.qasm')
                if p.exists():circuits['qllvm'+suffix]=qasm2.load(p)
            for label,q in circuits.items():
                assert g['mapping'](q)==mp,(label,g['mapping'](q),mp)
                eff=g['effects'](q);assert set(eff)==set(ref)
                err=max(float(np.linalg.norm(eff[k]-ref[k])) for k in ref)
                rec[label+'_error']=err;rec[label+'_verified']=err<1e-9
                if label!='imported':rec[label+'_gates'],rec[label+'_depth']=g['metrics'](q)
                if label in ['raw','normalized']:
                    path=d/(mode+'_'+label+'.qasm');qasm2.dump(q,path);rec[label+'_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
            for label,qn in [('raw','qllvm'),('normalized','qllvm_normalized')]:
                rec[label+'_both_verified']=rec.get('imported_verified',False) and rec.get(label+'_verified',False) and rec.get(qn+'_verified',False)
                if rec[label+'_both_verified']:
                    for m in ['gates','depth']:rec[label+'_'+m+'_reduction_pct']=100*(1-rec[qn+'_'+m]/rec[label+'_'+m])
        except Exception:rec['error']=traceback.format_exc()
        out.append(rec)
        (R/'results/native_quality_results.json').write_text(json.dumps(out,indent=2))
        print(row['case'],mode,rec.get('imported_verified'),rec.get('raw_verified'),rec.get('normalized_verified'),rec.get('raw_error'),flush=True)
summary={}
for mode in modes:
    group=[x for x in out if x['mode']==mode]
    s={'selected':len(group),'compiled':sum(x['compiled_status']=='compiled_extracted' for x in group),'verified':{n:sum(x.get(n+'_verified',False) for x in group) for n in ['imported','raw','normalized']},'max_error':{n:max(x.get(n+'_error',0) for x in group) for n in ['imported','raw','normalized']}}
    for label in ['raw','normalized']:
        pairs=[x for x in group if x.get(label+'_both_verified')];s[label]={'verified_pairs':len(pairs)}
        for metric in ['gates','depth']:
            values=[x[label+'_'+metric+'_reduction_pct'] for x in pairs];s[label][metric]={'mean_reduction_pct':statistics.mean(values) if values else None,'lower':sum(x>1e-10 for x in values),'equal':sum(abs(x)<=1e-10 for x in values),'higher':sum(x< -1e-10 for x in values)}
    s['failures']=[{'case':x['case'],'compiled_status':x['compiled_status'],'raw_error':x.get('raw_error'),'error':x.get('error')} for x in group if not x.get('raw_verified')]
    summary[mode]=s
(R/'results/native_quality_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
