from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,subprocess,os,time,hashlib,shutil
R=Path(__file__).resolve().parents[1];P=R/'stack/usr/local/aideqc/qcor'
env=dict(os.environ);env['LD_LIBRARY_PATH']=':'.join(str(x) for x in [P/'lib',P/'plugins',P/'clang-plugins',P.parent/'llvm/lib'])
env['OMP_NUM_THREADS']='1';env['OPENBLAS_NUM_THREADS']='1'
manifest=json.loads((R/'manifest.json').read_text())
first=R/'cases'/manifest[0]['case'];archive=R/'results/native_initial_preflight';archive.mkdir(exist_ok=True)
for f in first.iterdir():
    if f.name.startswith(('xacc','qcor')) and f.is_file():shutil.copy2(f,archive/f.name)
def run(row,mode):
    d=R/'cases'/row['case'];cmd=[str(R/'native_optimizer'),str(P),str(d/'input.json'),str(d/mode),mode]
    record={'case':row['case'],'mode':mode,'command':cmd,'timeout_seconds':90}
    start=time.perf_counter()
    with (d/(mode+'.log')).open('w') as log:
        try:
            result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
            record['returncode']=result.returncode
            record['status']='compiled_extracted' if result.returncode==0 and (d/(mode+'.json')).exists() else 'failed'
            if record['status']=='compiled_extracted':record['output_sha256']=hashlib.sha256((d/(mode+'.json')).read_bytes()).hexdigest()
        except subprocess.TimeoutExpired:record['status']='compiler_timeout'
    record['diagnostic_elapsed_seconds']=time.perf_counter()-start
    return record
results=[]
with ThreadPoolExecutor(max_workers=4) as pool:
    jobs=[pool.submit(run,row,mode) for row in manifest for mode in ['xacc','qcor1','qcor2']]
    for f in as_completed(jobs):
        rec=f.result();results.append(rec);print(len(results),len(jobs),rec['case'],rec['mode'],rec['status'],flush=True)
        (R/'results/native_compile_results.json').write_text(json.dumps(results,indent=2))
