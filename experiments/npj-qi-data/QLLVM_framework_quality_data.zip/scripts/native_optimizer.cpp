#include "xacc.hpp"
#include "xacc_service.hpp"
#include "InstructionIterator.hpp"
#include "qcor_ir.hpp"
#include "json.hpp"
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>

// Public exported symbols from the unmodified official QCOR libqrt.so.
namespace xacc { namespace internal_compiler {
extern int __opt_level;
extern bool __print_opt_stats;
extern std::string __user_opt_passes;
extern std::shared_ptr<xacc::Accelerator> qpu;
void execute_pass_manager(std::shared_ptr<qcor::CompositeInstruction>);
}}
using json=nlohmann::json;
double numeric(const xacc::InstructionParameter &p) {
  if(p.which()==0) return p.as<int>();
  if(p.which()==1) return p.as<double>();
  const auto s=p.toString(); std::size_t end=0; double v=std::stod(s,&end);
  if(end!=s.size()) throw std::runtime_error("Unresolved parameter "+s);
  return v;
}
json snapshot(std::shared_ptr<xacc::CompositeInstruction> program) {
  json gates=json::array(), measures=json::array();
  xacc::InstructionIterator it(program);
  while(it.hasNext()) {
    auto op=it.next(); if(op->isComposite()||!op->isEnabled())continue;
    const auto name=op->name(); const auto wires=op->bits();
    if(name=="Measure") {
      if(wires.size()!=1)throw std::runtime_error("Non-scalar measure");
      const auto params=op->getParameters();
      if(params.size()!=1)throw std::runtime_error("Missing classical destination");
      // Match XACC's documented OpenQASM exporter: an explicit classical
      // assignment uses the stored parameter; otherwise readout is wire-indexed.
      const auto names=op->getBufferNames();
      const int classical=names.size()>wires.size()?static_cast<int>(numeric(params[0])):static_cast<int>(wires[0]);
      measures.push_back(json::array({wires[0],classical}));
    } else {
      json params=json::array();for(const auto &p:op->getParameters())params.push_back(numeric(p));
      gates.push_back(json::array({name,params,wires}));
    }
  }
  return json{{"gates",gates},{"measurements",measures}};
}
int main(int argc,char**argv) {
  if(argc!=5) {std::cerr<<"prefix input.qasm output-prefix mode\n";return 2;}
  try {
    const std::string prefix=argv[1],input=argv[2],out=argv[3],mode=argv[4];
    xacc::Initialize(std::vector<std::string>{"--xacc-root-path",prefix});
    auto compiler=xacc::getCompiler("staq");
    std::ifstream file(input);std::stringstream source;source<<file.rdbuf();
    std::shared_ptr<xacc::CompositeInstruction> program;
    if(input.size()>=5 && input.substr(input.size()-5)==".json") {
      const auto data=json::parse(source.str());auto provider=xacc::getIRProvider("quantum");
      program=provider->createComposite("benchmark");
      const std::map<std::string,std::string> names={{"rx","Rx"},{"ry","Ry"},{"rz","Rz"},{"h","H"},{"cz","CZ"}};
      for(const auto &gate:data.at("gates")) {
        std::vector<std::size_t> wires=gate[2].get<std::vector<std::size_t>>();
        std::vector<xacc::InstructionParameter> params;for(const auto &p:gate[1])params.emplace_back(p.get<double>());
        auto inst=provider->createInstruction(names.at(gate[0].get<std::string>()),wires,params);
        inst->setBufferNames(std::vector<std::string>(wires.size(),"q"));program->addInstruction(inst);
      }
      for(const auto &m:data.at("measurements")) {
        auto inst=provider->createInstruction("Measure",std::vector<std::size_t>{m[0].get<std::size_t>()},std::vector<xacc::InstructionParameter>{m[1].get<int>()});
        inst->setBufferNames({"q","c"});program->addInstruction(inst);
      }
    } else program=compiler->compile(source.str())->getComposites().at(0);
    std::ofstream(out+"_imported.json")<<snapshot(program).dump(2);
    std::vector<std::string> required={"circuit-optimizer"};
    if(mode!="xacc") {
      required={"rotation-folding","single-qubit-gate-merging","circuit-optimizer"};
      if(mode=="qcor2"||mode=="qcor_precision")required.push_back("two-qubit-block-merging");
    }
    for(const auto &pass:required) {
      if(!xacc::hasService<xacc::IRTransformation>(pass))throw std::runtime_error("Missing pass "+pass);
      std::cout<<"AVAILABLE_PASS "<<pass<<"\n";
    }
    if(mode=="xacc")xacc::getIRTransformation("circuit-optimizer")->apply(program,nullptr);
    else {
      xacc::internal_compiler::qpu=xacc::getAccelerator("qpp");
      xacc::internal_compiler::__opt_level=(mode=="qcor2"||mode=="qcor_precision")?2:1;
      xacc::internal_compiler::__print_opt_stats=true;
      auto qprogram=std::make_shared<qcor::CompositeInstruction>(std::static_pointer_cast<xacc::Identifiable>(program));
      if(mode=="qcor_precision") {
        // Explicit precision-preserving control: the same supplied level-2
        // pass sequence except rotation-folding, which round-trips through
        // the package's lower-precision OpenQASM parser. Record separately.
        xacc::internal_compiler::__opt_level=0;
        xacc::internal_compiler::__user_opt_passes="single-qubit-gate-merging,circuit-optimizer,two-qubit-block-merging,single-qubit-gate-merging,circuit-optimizer";
        xacc::internal_compiler::execute_pass_manager(qprogram);
      } else xacc::internal_compiler::execute_pass_manager(qprogram);
      program=qprogram->as_xacc();
    }
    std::ofstream(out+".json")<<snapshot(program).dump(2);
    std::ofstream(out+"_native_export.qasm")<<compiler->translate(program);
    std::cout<<"FINISHED "<<mode<<" "<<program->nInstructions()<<"\n";
    xacc::Finalize();return 0;
  } catch(const std::exception &e) {std::cerr<<e.what()<<"\n";return 1;}
}
