from pathlib import Path
import shutil,json,hashlib
R=Path(__file__).resolve().parents[1]
P=Path('/home/easyai/qllvm-r14-claims-20261101/pilot')
manifest=json.loads((P/'manifest.json').read_text())
records=[]
for row in manifest:
    case=row['case'];src=P/'cases'/case;dst=R/'cases'/case;dst.mkdir(parents=True,exist_ok=True)
    record=dict(row,original_pilot_directory=str(src))
    for name in ['input.json','input.qasm','qllvm.qasm','qllvm_normalized.qasm','catalyst_fusion.qasm','catalyst_fusion_normalized.qasm']:
        f=src/name
        if f.exists():
            shutil.copy2(f,dst/name);record[name+'_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
    records.append(record)
(R/'manifest.json').write_text(json.dumps(records,indent=2))
protocol={
    'selection':'Same complete set of 55 frozen MQTBench inputs with 4, 6 or 8 qubits used for the Catalyst pilot; 22 grouped families; no selection on new compiler results',
    'inputs':'Byte-identical common-basis canonical QASM and JSON from the existing pilot; hashes retained',
    'basis':['rx','ry','rz','h','cz'],
    'topology':'All-to-all logical, no hardware mapping/routing in quality comparison',
    'measurements':'Preserve terminal measurement quantum wires and original classical-bit destinations; verify any export adaptation',
    'normalization':'Convert exported gates to the common alphabet at Qiskit1.2.4 optimization_level=0 only when required; apply the identical Optimize1qGatesDecomposition output-normalization control to all workflows, including the archived QLLVM/Catalyst outputs',
    'semantic_check':'Independent full-input terminal measurement effects, preserving classical destinations; maximum Frobenius residual <1e-9; same criterion as Catalyst pilot',
    'metrics':'Delivered gate count and ASAP logical depth excluding measurements/barriers; equal-weight mean per-circuit reduction relative to each configured baseline; raw and normalized values separate',
    'qllvm':'Archived corrected compiler -O1 -exact-rotations, 54 verified outputs and one 90-second timeout retained from 55-case pilot',
    'frameworks':['Catalyst 0.15.0 (completed archive)','CUDA-Q 0.16.0.post1 (environment preparation)','XACC (official package/source preparation)','QCOR (official package/source preparation)'],
    'claims':'Named pipeline and selected subset; shared-normalization controls not intrinsic compiler-only results; no timing/hardware/noise/general compiler superiority claim',
}
(R/'protocol.json').write_text(json.dumps(protocol,indent=2))
print('Prepared',len(records),'inputs; archived QLLVM outputs:',sum((R/'cases'/x['case']/'qllvm.qasm').exists() for x in records))
