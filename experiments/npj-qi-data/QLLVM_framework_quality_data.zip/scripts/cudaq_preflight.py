from pathlib import Path
import json,traceback,importlib.metadata
import cudaq
R=Path(__file__).resolve().parents[1];out=R/'results/cudaq_preflight';out.mkdir(exist_ok=True)
cudaq.set_target('qpp-cpu')
k=cudaq.make_kernel();q=k.qalloc(2)
k.h(q[0]);k.cx(q[0],q[1]);k.rz(0.13,q[0]);k.rz(-0.13,q[0])
k.mz(q[0]);k.mz(q[1])
(out/'kernel.mlir').write_text(str(k))
print('VERSION',importlib.metadata.version('cuda-quantum-cu12'))
print('TARGET',cudaq.get_target())
print('KERNEL',str(k))
for fmt in ['openqasm2','qir','qir-base']:
    try:
        s=cudaq.translate(k,format=fmt);(out/('bell.'+fmt)).write_text(s);print('FORMAT',fmt,s[:6000])
    except Exception:
        err=traceback.format_exc();(out/(fmt+'.error.txt')).write_text(err);print(err)
print('AVAILABLE_OPT_TOOLS',list((Path(cudaq.__file__).resolve().parent).rglob('cudaq-opt')))
