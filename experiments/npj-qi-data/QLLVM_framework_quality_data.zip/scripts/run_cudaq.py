from pathlib import Path
import json,traceback,hashlib,re,struct,time,importlib.metadata,sys
import cudaq
R=Path(__file__).resolve().parents[1]
cudaq.set_target('qpp-cpu')
def number(s):
    s=s.strip()
    if s.startswith('0x'):return struct.unpack('>d',bytes.fromhex(s[2:]))[0]
    return float(s)
def pointers(args):
    return [0 if token=='null' else int(re.search(r'i64 (\d+)',token)[1]) for token in re.findall(r'ptr\s+(null|inttoptr\s*\(i64\s+\d+\s+to\s+ptr\))',args)]
def parse_qir(ir,dat):
    f=re.search(r'define void @[^\n]+\{\n(.*?)\n\}',ir,re.S)
    assert f,'No entry function'
    gates=[];measure=[];names={};seen_measure=False
    stringvars={}
    for key,payload in re.findall(r'(@[\w.]+) = private constant .*? c"([^"]*)"',ir):
        stringvars[key]=re.sub(r'\\([0-9A-Fa-f]{2})',lambda m:chr(int(m[1],16)),payload).rstrip('\0')
    for line in f[1].splitlines():
        if '@__quantum__qis__' in line:
            m=re.search(r'call void @__quantum__qis__(\w+)__body\((.*)\)',line)
            assert m,line
            op,args=m.groups();ws=pointers(args)
            if op=='mz':
                assert len(ws)==2,line
                measure.append(tuple(ws));seen_measure=True;continue
            assert not seen_measure,'Nonterminal measurement requires another extraction contract'
            if op in ['rx','ry','rz','r1']:
                arg=re.search(r'double\s+([^,]+)',args);assert arg and len(ws)==1,line
                gates.append([{'r1':'p'}.get(op,op),[number(arg[1])],ws])
            elif op in ['h','x','y','z','s','t','s_adj','t_adj','cnot','cz','swap']:
                expected=2 if op in ['cnot','cz','swap'] else 1
                assert len(ws)==expected,line
                gates.append([{'cnot':'cx','s_adj':'sdg','t_adj':'tdg'}.get(op,op),[],ws])
            else:raise ValueError('Unsupported QIR gate: '+op)
        elif '@__quantum__rt__result_record_output' in line:
            result=pointers(line);tag=re.search(r'ptr (@[\w.]+)',line)
            assert len(result)==1 and tag,line
            names[result[0]]=stringvars[tag[1]]
        elif 'call ' in line:
            assert '@__quantum__rt__array_record_output' in line or '@__quantum__rt__tuple_record_output' in line,line
        else:assert not line.strip() or line.strip()=='ret void',line
    # Register names are explicitly set to the original classical bit indices.
    mappings=[]
    for q,r in measure:
        tag=names[r];assert re.fullmatch(r'c\d+',tag),(tag,names)
        mappings.append([q,int(tag[1:])])
    assert sorted(mappings)==sorted(dat['measurements']),(mappings,dat['measurements'])
    assert all(0<=q<dat['n'] for op,ps,ws in gates for q in ws)
    return dict(dat,gates=gates,measurements=mappings,qir_measurements=measure,qir_result_names=names)

manifest=json.loads((R/'manifest.json').read_text());results=[]
for idx,row in enumerate(manifest):
    d=R/'cases'/row['case'];data=json.loads((d/'input.json').read_text());record=dict(case=row['case'],framework='CUDA-Q',version=importlib.metadata.version('cuda-quantum-cu12'),target='qpp-cpu',export='qir-base')
    try:
        k=cudaq.make_kernel();q=k.qalloc(data['n'])
        for op,params,wires in data['gates']:
            if op in ['rx','ry','rz']:getattr(k,op)(params[0],q[wires[0]])
            elif op=='h':k.h(q[wires[0]])
            elif op=='cz':k.cz(q[wires[0]],q[wires[1]])
            else:raise ValueError(op)
        for wire,bit in data['measurements']:k.mz(q[wire],regName='c'+str(bit))
        (d/'cudaq_input.mlir').write_text(str(k))
        start=time.perf_counter();ir=cudaq.translate(k,format='qir-base');record['diagnostic_translate_seconds']=time.perf_counter()-start
        (d/'cudaq_optimized.ll').write_text(ir)
        output=parse_qir(ir,data);(d/'cudaq.json').write_text(json.dumps(output,indent=2))
        record['status']='compiled_extracted';record['output_qir_sha256']=hashlib.sha256(ir.encode()).hexdigest();record['extracted_gate_count']=len(output['gates'])
    except Exception:
        record['status']='failed';record['error']=traceback.format_exc();(d/'cudaq_error.txt').write_text(record['error'])
    results.append(record);(R/'results/cudaq_compile_results.json').write_text(json.dumps(results,indent=2))
    print(idx+1,len(manifest),row['case'],record['status'],record.get('extracted_gate_count',''),flush=True)
    if idx==0 and record['status']=='failed':
        print(record['error'],flush=True);break
