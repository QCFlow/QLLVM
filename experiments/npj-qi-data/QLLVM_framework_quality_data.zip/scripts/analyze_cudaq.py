from pathlib import Path
import os
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[name]='1'
import json,traceback,hashlib,statistics
import numpy as np
from qiskit import QuantumCircuit,qasm2,transpile
from qiskit.quantum_info import Operator
from qiskit.transpiler import PassManager
from qiskit.transpiler.passes import Optimize1qGatesDecomposition
R=Path(__file__).resolve().parents[1]
BASIS=['rx','ry','rz','h','cz']
helper=Path(__file__).resolve().with_name('analyze_pilot.py').read_text()
g={'np':np,'Operator':Operator,'protocol':{'basis':BASIS}}
exec(helper[helper.index('def mapping'):helper.index('results=[]')],g)
manifest=json.loads((R/'manifest.json').read_text());compiled=json.loads((R/'results/cudaq_compile_results.json').read_text())
assert len(manifest)==len(compiled)==55
out=[]
for row in manifest:
    d=R/'cases'/row['case'];record={'case':row['case'],'qubits':row['qubits'],'family':row['family']}
    source=qasm2.load(d/'input.qasm');ref=g['effects'](source);refmap=g['mapping'](source)
    try:
        data=json.loads((d/'cudaq.json').read_text());qc=QuantumCircuit(data['n'],data['ncl'])
        for name,params,wires in data['gates']:getattr(qc,name)(*params,*wires)
        for wire,bit in data['measurements']:qc.measure(wire,bit)
        qasm2.dump(qc,d/'cudaq_native.qasm')
        raw=transpile(qc,basis_gates=BASIS,optimization_level=0,seed_transpiler=0,coupling_map=None)
        normalized=PassManager([Optimize1qGatesDecomposition(basis=BASIS)]).run(raw)
        for name,circuit in [('cudaq',raw),('cudaq_normalized',normalized)]:
            qasm2.dump(circuit,d/(name+'.qasm'))
        for name in ['cudaq','cudaq_normalized','qllvm','qllvm_normalized']:
            path=d/(name+'.qasm')
            if not path.exists():
                record[name+'_status']='archived_compile_timeout';continue
            circuit=qasm2.load(path)
            assert g['mapping'](circuit)==refmap,(name,g['mapping'](circuit),refmap)
            effects=g['effects'](circuit);assert set(effects)==set(ref)
            error=max(float(np.linalg.norm(effects[k]-ref[k])) for k in ref)
            record[name+'_error']=error;record[name+'_verified']=error<1e-9
            record[name+'_gates'],record[name+'_depth']=g['metrics'](circuit)
            record[name+'_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        for label,cn,qn in [('raw','cudaq','qllvm'),('normalized','cudaq_normalized','qllvm_normalized')]:
            verified=record.get(cn+'_verified',False) and record.get(qn+'_verified',False)
            record[label+'_both_verified']=verified
            if verified:
                for metric in ['gates','depth']:record[label+'_'+metric+'_reduction_pct']=100*(1-record[qn+'_'+metric]/record[cn+'_'+metric])
    except Exception:record['error']=traceback.format_exc()
    out.append(record);(R/'results/cudaq_quality_results.json').write_text(json.dumps(out,indent=2))
    print(row['case'],record.get('cudaq_verified'),record.get('cudaq_normalized_verified'),record.get('normalized_gates_reduction_pct'),flush=True)
summary={'selected':55,'cudaq_compiled':sum(x['status']=='compiled_extracted' for x in compiled),'framework':'CUDA-Q 0.16.0.post1, qpp-cpu, optimized qir-base export','semantic_tolerance':1e-9,'verified':{n:sum(x.get(n+'_verified',False) for x in out) for n in ['cudaq','cudaq_normalized','qllvm','qllvm_normalized']},'comparisons':{}}
for label in ['raw','normalized']:
    rows=[x for x in out if x.get(label+'_both_verified')]
    summary['comparisons'][label]={'pairs':len(rows)}
    for metric in ['gates','depth']:
        values=[x[label+'_'+metric+'_reduction_pct'] for x in rows]
        summary['comparisons'][label][metric]={'mean_reduction_pct':statistics.mean(values) if values else None,'lower':sum(x>1e-10 for x in values),'equal':sum(abs(x)<=1e-10 for x in values),'higher':sum(x< -1e-10 for x in values)}
summary['max_error']={n:max((x.get(n+'_error',0) for x in out),default=0) for n in ['cudaq','cudaq_normalized','qllvm','qllvm_normalized']}
summary['unresolved']=[x for x in out if not x.get('normalized_both_verified')]
(R/'results/cudaq_quality_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
