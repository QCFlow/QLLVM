; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"

@cstr.633000 = private constant [3 x i8] c"c0\00"
@cstr.633100 = private constant [3 x i8] c"c1\00"
@cstr.633200 = private constant [3 x i8] c"c2\00"
@cstr.633300 = private constant [3 x i8] c"c3\00"
@cstr.633400 = private constant [3 x i8] c"c4\00"
@cstr.61727261793C6931207820353E00 = private constant [14 x i8] c"array<i1 x 5>\00"

define void @__nvqpp__mlirgen__PythonKernelBuilderInstance..0x7f1603dd3fe0() #0 {
  call void @__quantum__qis__h__body(ptr null)
  call void @__quantum__qis__rx__body(double 0x400921FB54442D18, ptr null)
  call void @__quantum__qis__h__body(ptr inttoptr (i64 1 to ptr))
  call void @__quantum__qis__rx__body(double 0x400921FB54442D18, ptr inttoptr (i64 1 to ptr))
  call void @__quantum__qis__h__body(ptr inttoptr (i64 2 to ptr))
  call void @__quantum__qis__h__body(ptr inttoptr (i64 3 to ptr))
  call void @__quantum__qis__rx__body(double 0x400921FB54442D18, ptr inttoptr (i64 3 to ptr))
  call void @__quantum__qis__h__body(ptr inttoptr (i64 4 to ptr))
  call void @__quantum__qis__rx__body(double 0x400921FB54442D18, ptr inttoptr (i64 5 to ptr))
  call void @__quantum__qis__cz__body(ptr null, ptr inttoptr (i64 5 to ptr))
  call void @__quantum__qis__rx__body(double 0x400921FB54442D18, ptr null)
  call void @__quantum__qis__h__body(ptr null)
  call void @__quantum__qis__cz__body(ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 5 to ptr))
  call void @__quantum__qis__rx__body(double 0x400921FB54442D18, ptr inttoptr (i64 1 to ptr))
  call void @__quantum__qis__h__body(ptr inttoptr (i64 1 to ptr))
  call void @__quantum__qis__cz__body(ptr inttoptr (i64 2 to ptr), ptr inttoptr (i64 5 to ptr))
  call void @__quantum__qis__h__body(ptr inttoptr (i64 2 to ptr))
  call void @__quantum__qis__cz__body(ptr inttoptr (i64 3 to ptr), ptr inttoptr (i64 5 to ptr))
  call void @__quantum__qis__rx__body(double 0x400921FB54442D18, ptr inttoptr (i64 3 to ptr))
  call void @__quantum__qis__h__body(ptr inttoptr (i64 3 to ptr))
  call void @__quantum__qis__cz__body(ptr inttoptr (i64 4 to ptr), ptr inttoptr (i64 5 to ptr))
  call void @__quantum__qis__h__body(ptr inttoptr (i64 4 to ptr))
  call void @__quantum__qis__h__body(ptr inttoptr (i64 5 to ptr))
  call void @__quantum__qis__mz__body(ptr null, ptr null)
  call void @__quantum__qis__mz__body(ptr inttoptr (i64 1 to ptr), ptr inttoptr (i64 1 to ptr))
  call void @__quantum__qis__mz__body(ptr inttoptr (i64 2 to ptr), ptr inttoptr (i64 2 to ptr))
  call void @__quantum__qis__mz__body(ptr inttoptr (i64 3 to ptr), ptr inttoptr (i64 3 to ptr))
  call void @__quantum__qis__mz__body(ptr inttoptr (i64 4 to ptr), ptr inttoptr (i64 4 to ptr))
  call void @__quantum__rt__array_record_output(i64 5, ptr @cstr.61727261793C6931207820353E00)
  call void @__quantum__rt__result_record_output(ptr null, ptr @cstr.633000)
  call void @__quantum__rt__result_record_output(ptr inttoptr (i64 1 to ptr), ptr @cstr.633100)
  call void @__quantum__rt__result_record_output(ptr inttoptr (i64 2 to ptr), ptr @cstr.633200)
  call void @__quantum__rt__result_record_output(ptr inttoptr (i64 3 to ptr), ptr @cstr.633300)
  call void @__quantum__rt__result_record_output(ptr inttoptr (i64 4 to ptr), ptr @cstr.633400)
  ret void
}

declare void @__quantum__qis__h__body(ptr)

declare void @__quantum__qis__mz__body(ptr, ptr) #1

declare void @__quantum__qis__rx__body(double, ptr)

declare void @__quantum__rt__result_record_output(ptr, ptr)

declare void @__quantum__qis__cz__body(ptr, ptr)

declare void @__quantum__rt__array_record_output(i64, ptr)

attributes #0 = { "entry_point" "output_labeling_schema"="schema_id" "output_names"="[[[0,[0,\22c0\22]],[1,[1,\22c1\22]],[2,[2,\22c2\22]],[3,[3,\22c3\22]],[4,[4,\22c4\22]]]]" "qir_profiles"="base_profile" "requiredQubits"="6" "requiredResults"="5" }
attributes #1 = { "irreversible" }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
