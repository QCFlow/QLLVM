module attributes {quake.mangled_name_map = {__nvqpp__mlirgen__PythonKernelBuilderInstance..0x7f1603dd3fe0 = "PythonKernelBuilderInstance..0x7f1603dd3fe0.PyKernelFakeEntryPoint"}} {
  func.func @__nvqpp__mlirgen__PythonKernelBuilderInstance..0x7f1603dd3fe0() attributes {"cudaq-entrypoint", "cudaq-kernel"} {
    %cst = arith.constant 3.1415926535897931 : f64
    %cst_0 = arith.constant -1.5707963267948966 : f64
    %cst_1 = arith.constant 1.5707963267948966 : f64
    %0 = quake.alloca !quake.veq<6>
    %1 = quake.extract_ref %0[0] : (!quake.veq<6>) -> !quake.ref
    quake.rz (%cst_1) %1 : (f64, !quake.ref) -> ()
    quake.rz (%cst_0) %1 : (f64, !quake.ref) -> ()
    quake.h %1 : (!quake.ref) -> ()
    quake.rz (%cst_0) %1 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %1 : (f64, !quake.ref) -> ()
    quake.rx (%cst) %1 : (f64, !quake.ref) -> ()
    %2 = quake.extract_ref %0[1] : (!quake.veq<6>) -> !quake.ref
    quake.rz (%cst_1) %2 : (f64, !quake.ref) -> ()
    quake.rz (%cst_0) %2 : (f64, !quake.ref) -> ()
    quake.h %2 : (!quake.ref) -> ()
    quake.rz (%cst_0) %2 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %2 : (f64, !quake.ref) -> ()
    quake.rx (%cst) %2 : (f64, !quake.ref) -> ()
    %3 = quake.extract_ref %0[2] : (!quake.veq<6>) -> !quake.ref
    quake.rz (%cst_1) %3 : (f64, !quake.ref) -> ()
    quake.rz (%cst_0) %3 : (f64, !quake.ref) -> ()
    quake.h %3 : (!quake.ref) -> ()
    quake.rz (%cst_0) %3 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %3 : (f64, !quake.ref) -> ()
    %4 = quake.extract_ref %0[3] : (!quake.veq<6>) -> !quake.ref
    quake.rz (%cst_1) %4 : (f64, !quake.ref) -> ()
    quake.rz (%cst_0) %4 : (f64, !quake.ref) -> ()
    quake.h %4 : (!quake.ref) -> ()
    quake.rz (%cst_0) %4 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %4 : (f64, !quake.ref) -> ()
    quake.rx (%cst) %4 : (f64, !quake.ref) -> ()
    %5 = quake.extract_ref %0[4] : (!quake.veq<6>) -> !quake.ref
    quake.rz (%cst_1) %5 : (f64, !quake.ref) -> ()
    quake.rz (%cst_0) %5 : (f64, !quake.ref) -> ()
    quake.h %5 : (!quake.ref) -> ()
    quake.rz (%cst_0) %5 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %5 : (f64, !quake.ref) -> ()
    %6 = quake.extract_ref %0[5] : (!quake.veq<6>) -> !quake.ref
    quake.rx (%cst) %6 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %6 : (f64, !quake.ref) -> ()
    quake.rz (%cst_0) %6 : (f64, !quake.ref) -> ()
    quake.h %6 : (!quake.ref) -> ()
    quake.rz (%cst_0) %6 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %6 : (f64, !quake.ref) -> ()
    quake.h %6 : (!quake.ref) -> ()
    quake.z [%1] %6 : (!quake.ref, !quake.ref) -> ()
    quake.rx (%cst) %1 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %1 : (f64, !quake.ref) -> ()
    quake.rz (%cst_0) %1 : (f64, !quake.ref) -> ()
    quake.h %1 : (!quake.ref) -> ()
    quake.rz (%cst_0) %1 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %1 : (f64, !quake.ref) -> ()
    quake.h %6 : (!quake.ref) -> ()
    quake.h %6 : (!quake.ref) -> ()
    quake.z [%2] %6 : (!quake.ref, !quake.ref) -> ()
    quake.rx (%cst) %2 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %2 : (f64, !quake.ref) -> ()
    quake.rz (%cst_0) %2 : (f64, !quake.ref) -> ()
    quake.h %2 : (!quake.ref) -> ()
    quake.rz (%cst_0) %2 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %2 : (f64, !quake.ref) -> ()
    quake.h %6 : (!quake.ref) -> ()
    quake.h %6 : (!quake.ref) -> ()
    quake.z [%3] %6 : (!quake.ref, !quake.ref) -> ()
    quake.rz (%cst_1) %3 : (f64, !quake.ref) -> ()
    quake.rz (%cst_0) %3 : (f64, !quake.ref) -> ()
    quake.h %3 : (!quake.ref) -> ()
    quake.rz (%cst_0) %3 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %3 : (f64, !quake.ref) -> ()
    quake.h %6 : (!quake.ref) -> ()
    quake.h %6 : (!quake.ref) -> ()
    quake.z [%4] %6 : (!quake.ref, !quake.ref) -> ()
    quake.rx (%cst) %4 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %4 : (f64, !quake.ref) -> ()
    quake.rz (%cst_0) %4 : (f64, !quake.ref) -> ()
    quake.h %4 : (!quake.ref) -> ()
    quake.rz (%cst_0) %4 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %4 : (f64, !quake.ref) -> ()
    quake.h %6 : (!quake.ref) -> ()
    quake.h %6 : (!quake.ref) -> ()
    quake.z [%5] %6 : (!quake.ref, !quake.ref) -> ()
    quake.rz (%cst_1) %5 : (f64, !quake.ref) -> ()
    quake.rz (%cst_0) %5 : (f64, !quake.ref) -> ()
    quake.h %5 : (!quake.ref) -> ()
    quake.rz (%cst_0) %5 : (f64, !quake.ref) -> ()
    quake.rz (%cst_1) %5 : (f64, !quake.ref) -> ()
    quake.h %6 : (!quake.ref) -> ()
    %measOut = quake.mz %1 name "c0" : (!quake.ref) -> !cc.measure_handle
    %measOut_2 = quake.mz %2 name "c1" : (!quake.ref) -> !cc.measure_handle
    %measOut_3 = quake.mz %3 name "c2" : (!quake.ref) -> !cc.measure_handle
    %measOut_4 = quake.mz %4 name "c3" : (!quake.ref) -> !cc.measure_handle
    %measOut_5 = quake.mz %5 name "c4" : (!quake.ref) -> !cc.measure_handle
    return
  }
}
