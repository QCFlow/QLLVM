R2-3 public-workload evaluation, 2026-11-03

classifier/: complete five-pair QStone classifier campaign, including generated artifacts.
precompiled/: archived measurements and validation for manuscript Table IV (unchanged).
scripts/: campaign, analysis and prior adaptation helper; inspect absolute installation/source paths before use.
sources/: pinned source files and manifests. Refer to the cited upstream repositories for licensing and full dependencies.
summary.json and paired_timings.csv: classifier aggregate and per-pair statistics.

The classifier pilot is excluded from the archive's measured campaign and all reported statistics.
The classifier timer includes dynamic compilation and must not be presented as pure executable runtime.
The comparator is the specified serial split recipe, not parallel Make/Ninja.
