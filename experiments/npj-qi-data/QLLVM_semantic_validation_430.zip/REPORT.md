# AE O1 未确定案例复核报告

本次使用项目虚拟环境完成 AE 16–26 qubit 的 11 个原始 O1 产物复核。结论为：**419 个归档数值验证通过结果，加上 11 个新增全输入终端测量效应证书，共 430 个数值观察等价验证结果**。

新增证书采用原协议已有的 `1e-9` 测量效应算子范数标准，覆盖任意输入态及每个完整经典测量结果。没有把 QCEC 的超时或 unknown 改成 QCEC 通过，没有声称符号精确相等，也没有声称 430 个都通过了 QCEC 的 `1e-12` 检查。证书生成时未修改论文和编译器；原始电路未重新生成、未改角度、未改容差。此句描述证书生成阶段的历史状态。当前提交稿已在 II.B.2 和 III.C.3 写入证书方法、范围与误差界，并在回复 R1-5 和 Appendix F 保留详细证据。

## 原记录与资源复查

- 原清单是 `A16_exact_quality/dispositions.csv`，430 个独立标识；419 个通过，11 个 AE 案例超时。
- 全部 860 个原始/输出 QASM 的 SHA256 与归档清单相符；419 个原验证结果文件全部存在。使用重试结果的案例也检查重试电路与同一组哈希一致。
- 原 QCEC 内部数值容差为 `2.2737367544323206e-13`，功能判定阈值为 `1e-12`。两者不可混同。
- 16 和 26 qubit 使用原容差、原角度、lookahead DD、24 GiB 地址空间、600/630 秒软/硬限时仍超时。16 qubit 的 one-to-one DD、8 GiB、120/150 秒也超时，完整参数和结果在 `strict_results/`。
- 旧 `check_ae.py` 的 `1e-12` 内部容差、角度取模，以及更宽容差试跑均未用于本次 430 项合并。

## 独立方法和适用边界

验证目标是每个经典结果 y 的效应矩阵差：

`max_y || U† P_y U - V† P_y V ||₂ < 1e-9`。

因此任意输入密度矩阵在每个结果上的概率差也小于 `1e-9`。这是逐结果的全输入标准，不是对所有结果概率差求和的总变差标准，不是对量子残余输出的通道标准，也不是随机采样。

`certify_ae.py` 只接受已核实的结构：全宽终端测量、相同经典位映射、一个目标位与每个控制位各发生两次 CZ、控制位在其 CZ 对内没有其他门、控制位之间的 CZ 位于 star 部分之后。支持 H/Rx/Ry/Rz/CZ；不满足结构即拒绝。目标位没有后续耦合，因此其最后局部门可以与控制位尾部交换位置。控制位在首个 star 交互前的局部门可以提前，在最后 star 交互后的局部门可以延后。这些交换只涉及不相交的量子位，不依赖编译器实现。

### 1. 星形受控部分

每两个目标位 CZ 之间的所有单比特门用 70 位和 100 位小矩阵区间运算计算。为每个矩阵选择 `exp(iφ) O(θ,p)`，其中 `O(θ,p)=R(θ) Z^p` 是精确定义的实正交矩阵，`R(θ)=[[cosθ,-sinθ],[sinθ,cosθ]]`。矩阵与该代表的 Frobenius 残差严格计入总误差；**没有丢弃这些小残差或把它们当成零**。

固定任意控制位串 x，CZ 在目标位上变为 `Z^x`。按 `Z R(θ)=R(-θ) Z`，整个目标位运算仍为 `R(Θ(x)) Z^p`，其中 Θ 是 Walsh 符号函数的线性组合。脚本符号跟踪每个系数的掩码，覆盖全部控制位串，不枚举或抽样输入。每个控制位恰有两个 CZ，因此最终 p 不依赖 x。

两个电路最终常数 p 的差异由输出端 Z 对齐，它不改变目标位测量。每个 Walsh 系数减去整数倍 π，只改变一个与控制位串无关的全局符号；该整数及余量保存在证书中。这是在比较函数中去除全局相位，**没有改写任何输入 QASM 旋转参数**。

若对齐后的系数差为 Δ_j，则任意 x 下 `|Θ_b(x)-Θ_a(x)| ≤ Σ_j |Δ_j|`。实旋转矩阵差的算子范数不超过这个角度差。再加上两侧所有投影残差，就得到整个受控部分的算子范数上界。用区间三角函数处理千万量级原始角度，不调用低精度的手工取模。

### 2. 控制位尾部

两侧尾部 CZ 顺序和位置逐项完全一致。维护每条线上一个精确定义的对角酉矩阵 D。局部块 A、B 更新为 `B D A†`，与下一个对角酉矩阵 D' 的差以区间 Frobenius 范数计入误差。对角酉矩阵与 CZ 对易，因此可以跨过共同 CZ；利用酉变换不增加范数和逐段三角不等式，所有局部残差之和控制整个尾部的差。最终 D 是计算基对角矩阵，不改变终端测量。

### 3. 全电路与测量效应界

令 ε 是前置块、星形部分和尾部三个上界之和，则存在输出对角酉矩阵 D，使 `||V-DU||₂ ≤ ε`。所有残差均以 Frobenius 范数上界局部算子范数，因此总界保守。

这个 ε **直接**上界每个测量效应差，不需要放宽标准：令 `W=V(DU)†`，则测量效应差与 `W†P_yW-P_y` 酉相似，其范数等于 `||[P_y,W]||₂`。因为 `||P_y-I/2||₂=1/2`，

`[P_y,W]=(P_y-I/2)(W-I)-(W-I)(P_y-I/2)`，

从而 `||[P_y,W]||₂ ≤ ||W-I||₂ ≤ ε`。D 与测量投影对易。此论证对任意输入态和所有结果成立。

输入角度采用原 Qiskit 解析器产生的 binary64 数值，转换为精确二进制有理数后进入区间运算；这是原数值验证的语义。没有宣称把 QASM 十进制或 π 字面量当作无限精度实数后符号精确相等。区间运算是独立实现的数值证据，不是经证明助手验证的编译器一般正确性证明。

## 逐例结果

下表为了显示方便向上取整；机器证书保存更多位。

| qubit | 全输入逐结果效应算子范数上界 |
|---:|---:|
| 16 | 2.239 × 10⁻¹² |
| 17 | 3.495 × 10⁻¹² |
| 18 | 8.578 × 10⁻¹² |
| 19 | 1.379 × 10⁻¹¹ |
| 20 | 2.321 × 10⁻¹¹ |
| 21 | 4.217 × 10⁻¹¹ |
| 22 | 9.636 × 10⁻¹¹ |
| 23 | 2.017 × 10⁻¹⁰ |
| 24 | 3.533 × 10⁻¹⁰ |
| 25 | 6.566 × 10⁻¹⁰ |
| 26 | 7.038 × 10⁻¹⁰ |

全部小于既定 `1e-9`。70 位和 100 位区间运算结论一致。最大案例的余量约为 `2.96e-10`。

## 校准与可追溯性

`validation/validation.json` 包含 28 项校准：7 个原始小规模 AE 案例与完整稠密效应比较；16 个固定种子的结构化小电路，包括零扰动、阈值内扰动和明确超阈值扰动；控制位输出对角相位等价对照；目标位非实正交相位的保守不确定对照；交换经典位、删除 CZ、测量后操作等拒绝检查。全部校准通过。稠密对照采用完整矩阵，未使用采样；binary64 对照自身仅留 `5e-13` 的数值检查余量，不用于放宽证书接受标准。

验证器是有意不完备的：例如某些目标位复相位完全不影响测量，但超出这个实正交模型时可能得到 `bound_inconclusive`，不会被错误判为反例或通过。

`evidence_430/dispositions_430.csv` 是本次唯一合并结果清单，保留 `historical_status`，区分归档验证与新增证书。其 `archive/` 包含全部 430 对冻结 QASM 和对应编译/验证证据；无需寻找原机器的旧绝对路径来核对这些文件。每个新增证书记录输入输出 SHA256、验证器 SHA256、软件版本、局部界、最终界及耗时。

## 重跑

项目解释器：

```text
/home/easyai/文档备份/QLLVM/QLLVM-202610/返修/experiments/IIIC_opt/verification_campaign/venv/bin/python
```

在此目录下，用该解释器执行（输出目录必须尚不存在）：

```bash
python -B certify_ae.py --archive-root evidence_430/archive --precision 100 --dest certificates_reproduced
python -B validate_certificate.py --dest validation_reproduced
```

`certify_ae.py` 的可移植重跑使用随包归档的 QASM。`validate_certificate.py` 当前默认使用原实验目录中的小规模 AE 对照，迁移机器时可将其导入的 BASE 指向 `evidence_430/archive`。依赖：Qiskit 1.2.4、mpmath 1.3.0；原 QCEC 重试另需 mqt.qcec 3.10.0、mqt.core 3.10.1。

## 已落实的论文说明（措辞以当前正文为准）

“All 430 archived O1 outputs satisfy the numerical observational-equivalence checks under the stated verification contracts. Of these, 419 retain their archived verification results; the remaining 11 amplitude-estimation circuits (16–26 qubits) are certified by an independent structure-aware, interval-arithmetic bound on every terminal measurement effect for all input states. The largest effect operator-norm bound is 7.04×10⁻¹⁰, below the existing 10⁻⁹ criterion. The original QCEC timeouts are retained; these results do not imply symbolic exact equality or 430 successful QCEC checks.”

这解决的是“419 已验证＋11 未确定”的数值观察等价覆盖缺口。当前正文已披露新增验证方法、适用范围和既有阈值；回复 R1-5 与 Appendix F 提供哈希及证书入口，并保留原超时记录。下面的 QCEC 参考和上述数值证据仍属于原验证记录。

## QCEC 语义参考

- 原安装版本源码：<https://raw.githubusercontent.com/munich-quantum-toolkit/qcec/v3.10.0/src/checker/dd/DDAlternatingChecker.cpp>，partial 模式允许终端对角相位，因此返回标签不能被无条件解读为完整酉矩阵仅差全局相位。
- 配置说明：<https://mqt.readthedocs.io/projects/qcec/en/v3.4.0/api/mqt/qcec/pyqcec/index.html>，区分内部数值容差、功能阈值和尽力而为的软超时。实际参数以随包保存的 3.10.0 配置为准。
