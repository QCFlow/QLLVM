"""Audit all frozen hashes and assemble a portable, non-destructive evidence set."""
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parent
BASE=Path('/home/easyai/文档备份/QLLVM/QLLVM-202610/返修/experiments/recovery_campaign')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def write(p,value):
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def main():
    out=HERE/'evidence_430'
    out.mkdir(exist_ok=False)
    archive=out/'archive'
    rows=list(csv.DictReader((BASE/'A16_exact_quality/dispositions.csv').open()))
    assert len(rows)==len({r['case'] for r in rows})==430
    validation=json.loads((HERE/'validation/validation.json').read_text())
    assert validation['all_pass']
    current_sha=sha(HERE/'certify_ae.py')
    final=[];precision=[]

    def copy(relative):
        target=archive/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(BASE/relative,target)
        return str(target.relative_to(out))

    for name in ['A16_exact_quality/dispositions.csv','A16_exact_quality/summary.json','A16_exact_quality/results.csv',
                 'A13_full_retry_exact/configuration.json','A13_full_retry_exact/calibrations.json','A13_full_retry_exact/results.csv']:
        copy(name)
    for r in rows:
        stem=Path('A16_exact_quality/native/work')/r['case']
        d=BASE/stem
        for name,key in [('original.qasm','source_sha256'),('output.qasm','output_sha256')]:
            assert sha(d/name)==r[key], (r['case'],name)
            copy(stem/name)
        for name in ['final_record.json','budget.json','command.json']:
            copy(stem/name)
        rec={**r,'historical_status':r['status'],'archive_directory':str(Path('archive')/stem),
             'source_hash_matches':True,'output_hash_matches':True}
        if r['status']=='observational_equivalent_numeric':
            evidence=Path('A13_full_retry_exact/work')/r['case'] if r['retry_status']=='observational_equivalent_numeric' else stem
            if evidence!=stem:
                for name,key in [('original.qasm','source_sha256'),('output.qasm','output_sha256')]:
                    assert sha(BASE/evidence/name)==r[key], ('retry mismatch',r['case'],name)
            v=json.loads((BASE/evidence/'verification.json').read_text())
            assert v['status']=='observational_equivalent_numeric'
            assert v.get('qcec_equivalence') not in ['not_equivalent','probably_not_equivalent']
            rec.update(method='retained_archived_verification',evidence=copy(evidence/'verification.json'),
                       evidence_sha256=sha(BASE/evidence/'verification.json'),effect_operator_norm_upper='')
            for name in ['qcec_details.json','final_record.json']:
                if (BASE/evidence/name).exists():copy(evidence/name)
        else:
            c70=json.loads((HERE/'certificates_70'/(r['case']+'.json')).read_text())
            c100=json.loads((HERE/'certificates_100'/(r['case']+'.json')).read_text())
            for c in [c70,c100]:
                assert c['source_sha256']==r['source_sha256'] and c['output_sha256']==r['output_sha256']
                assert c['verifier_sha256']==current_sha
                assert c['status']=='observational_equivalent_numeric'
                assert Decimal(c['effect_operator_norm_upper'])<Decimal('1e-9')
            difference=abs(Decimal(c70['effect_operator_norm_upper'])-Decimal(c100['effect_operator_norm_upper']))
            assert difference<Decimal('1e-35')
            precision.append({'case':r['case'],'bound_70':c70['effect_operator_norm_upper'],
                              'bound_100':c100['effect_operator_norm_upper'],'absolute_difference':str(difference)})
            certpath=HERE/'certificates_100'/(r['case']+'.json')
            rec.update(status='observational_equivalent_numeric',method='interval_all_input_terminal_povm_certificate',
                       evidence='../certificates_100/'+r['case']+'.json',evidence_sha256=sha(certpath),
                       effect_operator_norm_upper=c100['effect_operator_norm_upper'])
        final.append(rec)
    with (out/'dispositions_430.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(final[0]));writer.writeheader();writer.writerows(final)
    write(out/'precision_crosscheck.json',{'all_pass':True,'results':precision})
    summary={
        'cases':430,'retained_archived_passes':419,'new_interval_certificates':11,
        'final_numerical_observational_equivalence_matches':430,'unresolved':0,
        'all_860_source_output_hashes_match':True,'all_419_original_evidence_records_present':True,
        'retried_evidence_matches_same_qasm':True,'original_qasm_modified':False,
        'compiler_modified':False,'manuscript_modified':False,'verifier_sha256':current_sha,
        'calibration_checks':validation['checks'],'calibration_all_pass':True,
        'precision_crosscheck_decimal_digits':[70,100],
        'new_certificate_criterion':'max_y effect operator norm < 1e-9, all input states',
        'maximum_new_effect_norm_upper':max((r['effect_operator_norm_upper'] for r in final if r['effect_operator_norm_upper']),key=Decimal),
        'qcec_original_internal_tolerance':2.2737367544323206e-13,'qcec_original_trace_threshold':1e-12,
        'qcec_all_430_pass_claim':False,
        'interpretation':'419 archived numeric matches plus 11 new independent all-input terminal-POVM certificates under the existing 1e-9 effect criterion. Not exact symbolic equality, not 430 QCEC successes.',
    }
    write(out/'summary.json',summary)
    original_manifest=sha(BASE/'A16_exact_quality/dispositions.csv')
    write(out/'provenance.json',{'original_dispositions_sha256':original_manifest,
          'scripts':{name:sha(HERE/name) for name in ['certify_ae.py','validate_certificate.py','strict_recheck.py','consolidate.py']}})
    print(json.dumps(summary,ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
