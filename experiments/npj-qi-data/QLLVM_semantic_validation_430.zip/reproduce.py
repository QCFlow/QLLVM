"""Re-run all 11 certificates from the bundled frozen archive."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
subprocess.run([sys.executable, '-B', str(root/'certify_ae.py'), '--archive-root', str(root/'evidence_430/archive'), '--precision', '100', '--dest', str(root/'certificates_reproduced')], check=True)
