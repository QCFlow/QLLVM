"""Recheck frozen AE outputs without altering angles or historical tolerances."""
import argparse
import csv
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

BASE = Path('/home/easyai/文档备份/QLLVM/QLLVM-202610/返修/experiments/recovery_campaign')
HERE = Path(__file__).resolve().parent
PASS = {'equivalent', 'equivalent_up_to_global_phase'}


def write(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def child(args):
    resource.setrlimit(resource.RLIMIT_AS, (args.memory_gib * 1024**3,) * 2)
    from qiskit import qasm2
    from mqt.core import load
    from mqt.qcec.pyqcec import ApplicationScheme, Configuration, EquivalenceCheckingManager
    d = BASE / 'A16_exact_quality/native/work' / f'ae_nativegates_ibm_qiskit_opt0_{args.qubits}_O1'
    a, b = [qasm2.load(d / name) for name in ['original.qasm', 'output.qasm']]
    assert a.num_qubits == b.num_qubits and a.num_clbits == b.num_clbits
    def interface(q):
        seen = False
        measurements = []
        for inst in q.data:
            if inst.operation.name == 'measure':
                seen = True
                measurements.append((q.find_bit(inst.qubits[0]).index, q.find_bit(inst.clbits[0]).index))
            elif inst.operation.name != 'barrier':
                assert not seen, 'Non-terminal measurement'
                assert inst.operation.name != 'reset' and not getattr(inst.operation, 'condition', None)
        return measurements
    assert interface(a) == interface(b)
    config = Configuration()
    config.execution.parallel = False
    config.execution.nthreads = 1
    config.execution.timeout = args.timeout
    config.execution.numerical_tolerance = 2.2737367544323206e-13
    config.execution.run_simulation_checker = False
    config.execution.run_zx_checker = args.method == 'zx'
    config.execution.run_construction_checker = False
    config.execution.run_alternating_checker = args.method != 'zx'
    config.functionality.trace_threshold = 1e-12
    config.functionality.check_partial_equivalence = True
    config.functionality.check_approximate_equivalence = False
    for field in ['elide_permutations', 'reconstruct_swaps', 'remove_diagonal_gates_before_measure', 'reorder_operations', 'transform_dynamic_circuit']:
        setattr(config.optimizations, field, False)
    config.optimizations.fuse_single_qubit_gates = True
    config.application.alternating_scheme = getattr(ApplicationScheme, args.method if args.method != 'zx' else 'lookahead')
    write(args.dest / 'configuration.json', json.loads(str(config)))
    write(args.dest / 'inputs.json', {
        'case': d.name, 'directory': str(d), 'original_sha256': sha(d/'original.qasm'),
        'output_sha256': sha(d/'output.qasm'), 'terminal_measurement_map': interface(a),
        'angle_normalized': False, 'versions': {name: importlib.metadata.version(name) for name in ['mqt.qcec', 'mqt.core', 'qiskit', 'numpy']},
        'python': sys.executable, 'script_sha256': sha(Path(__file__)),
    })
    started = time.perf_counter()
    manager = EquivalenceCheckingManager(load(a), load(b), config)
    manager.run()
    result = manager.results.json()
    if isinstance(result, str):
        result = json.loads(result)
    write(args.dest / 'verification.json', result)
    write(args.dest / 'metrics.json', {'elapsed_s': time.perf_counter()-started, 'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})


def main(args):
    args.dest.mkdir(parents=True, exist_ok=False)
    cmd = [sys.executable, '-B', str(Path(__file__).resolve()), '--child', '--qubits', str(args.qubits), '--timeout', str(args.timeout), '--memory-gib', str(args.memory_gib), '--method', args.method, '--dest', str(args.dest)]
    write(args.dest / 'command.json', cmd)
    started = time.perf_counter()
    env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    with (args.dest/'stdout.txt').open('w') as out, (args.dest/'stderr.txt').open('w') as err:
        try:
            p = subprocess.run(cmd, env=env, stdout=out, stderr=err, timeout=args.timeout+30)
            code, status = p.returncode, 'checker_failed'
        except subprocess.TimeoutExpired:
            code, status = None, 'checker_timeout'
    v = args.dest / 'verification.json'
    label = json.loads(v.read_text()).get('equivalence') if v.exists() else None
    if code == 0:
        status = 'observational_equivalent_numeric' if label in PASS else 'counterexample' if label == 'not_equivalent' else 'inconclusive'
    record = {'case': f'ae_nativegates_ibm_qiskit_opt0_{args.qubits}_O1', 'status': status, 'equivalence': label, 'exit_code': code, 'elapsed_s': time.perf_counter()-started, 'memory_limit_gib': args.memory_gib, 'timeout_s': args.timeout, 'hard_timeout_s': args.timeout+30, 'method': args.method}
    write(args.dest / 'record.json', record)
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--child', action='store_true')
    parser.add_argument('--qubits', type=int, required=True)
    parser.add_argument('--timeout', type=float, default=600)
    parser.add_argument('--memory-gib', type=int, default=24)
    parser.add_argument('--method', default='lookahead')
    parser.add_argument('--dest', type=Path, required=True)
    args = parser.parse_args()
    child(args) if args.child else main(args)
