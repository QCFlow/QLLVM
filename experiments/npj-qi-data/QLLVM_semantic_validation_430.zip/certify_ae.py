"""All-input terminal-POVM bounds for the frozen AE star/CZ structure.

Uses interval arithmetic on small matrices, never state sampling. See REPORT.md
for the decomposition and telescoping bound. QASM parameters have the binary64
values parsed by the archived Qiskit checker; no angle normalization is applied.
"""
import argparse
import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path
import resource
import sys
import time

import mpmath as mp
from qiskit import qasm2

BASE = Path(__file__).resolve().parent/'evidence_430/archive'
THRESHOLD = '1e-9'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def fmt(x):
    return mp.nstr(x, 45)


def boundfmt(x):
    # Round nonnegative certificate bounds outward for JSON serialization.
    if not x:
        return '0'
    power = int(mp.floor(mp.log10(x)))-39
    quantum = mp.mpf(10)**power
    return mp.nstr((mp.ceil(x/quantum)+1)*quantum, 45)


def upper(x):
    return mp.mpf(x.b)


def midpoint(z):
    return mp.mpc(mp.mpf(z.real.mid), mp.mpf(z.imag.mid))


def frob(matrix):
    return mp.iv.sqrt(sum(abs(x)**2 for x in matrix))


def adjoint(matrix):
    # mpmath 1.3.0's complex-interval conjugate calls the scalar mpf negator.
    # Explicit interval real/imaginary parts avoid that upstream defect.
    return mp.iv.matrix([[mp.iv.mpc(matrix[j, i].real, -matrix[j, i].imag)
                          for j in range(2)] for i in range(2)])


def gate(name, params):
    if name == 'h':
        return mp.iv.matrix([[1, 1], [1, -1]]) / mp.iv.sqrt(2)
    assert name in ('rx', 'ry', 'rz'), name
    # Exact binary64 rational, as used by the original parser, enclosed by iv.
    numerator, denominator = float(params[0]).as_integer_ratio()
    t = mp.iv.mpf(numerator) / denominator / 2
    c, s = mp.iv.cos(t), mp.iv.sin(t)
    if name == 'rx':
        return mp.iv.matrix([[c, -1j*s], [-1j*s, c]])
    if name == 'ry':
        return mp.iv.matrix([[c, -s], [s, c]])
    return mp.iv.matrix([[mp.iv.exp(-1j*t), 0], [0, mp.iv.exp(1j*t)]])


def read_ops(circuit):
    ops, measured = [], []
    seen_measure = False
    for inst in circuit.data:
        name = inst.operation.name
        qs = tuple(circuit.find_bit(q).index for q in inst.qubits)
        assert not getattr(inst.operation, 'condition', None)
        if name == 'barrier':
            continue
        if name == 'measure':
            seen_measure = True
            measured.append((qs[0], circuit.find_bit(inst.clbits[0]).index))
            continue
        assert not seen_measure, 'Mid-circuit operation is unsupported'
        assert name in ('h', 'rx', 'ry', 'rz', 'cz'), name
        ops.append((name, qs, tuple(inst.operation.params)))
    n = circuit.num_qubits
    assert circuit.num_clbits == n
    assert sorted(q for q, _ in measured) == list(range(n))
    assert sorted(c for _, c in measured) == list(range(n))
    return ops, measured


def decompose(circuit):
    ops, measurements = read_ops(circuit)
    target = circuit.num_qubits - 1
    occurrences = {k: [] for k in range(target)}
    for j, (name, qs, _) in enumerate(ops):
        if name == 'cz' and target in qs:
            occurrences[next(q for q in qs if q != target)].append(j)
    assert all(len(indices) == 2 for indices in occurrences.values())
    last_star = max(j for indices in occurrences.values() for j in indices)
    pre = [mp.iv.eye(2) for _ in range(target)]
    tail, star = [], []
    for j, (name, qs, params) in enumerate(ops):
        if target in qs:
            star.append((name, qs, params))
        elif name == 'cz':
            assert j > last_star, 'Non-star entanglement interleaved with star'
            tail.append((name, qs, params))
        else:
            q = qs[0]
            if j < occurrences[q][0]:
                pre[q] = gate(name, params) * pre[q]
            else:
                assert j > occurrences[q][-1], 'Control gate inside CZ pair'
                tail.append((name, qs, params))
    # Gates on each control before its first star interaction commute with all
    # earlier star interactions. Its later gates commute with later star pairs.
    return pre, star, tail, measurements


def orthogonal_projection(matrix):
    """Choose an exact real orthogonal matrix and bound the discarded residual."""
    mid = mp.matrix(2, 2)
    for i in range(2):
        for j in range(2):
            mid[i, j] = midpoint(matrix[i, j])
    pivot = max(list(mid), key=abs)
    phase_angle = fmt(mp.arg(pivot))
    normalized = mid / mp.exp(1j*mp.mpf(phase_angle))
    theta = fmt(mp.atan2(normalized[1, 0].real, normalized[0, 0].real))
    parity = int(mp.det(normalized).real < 0)
    t = mp.iv.mpf(theta)
    c, s = mp.iv.cos(t), mp.iv.sin(t)
    orthogonal = mp.iv.matrix([[c, -s*(-1)**parity], [s, c*(-1)**parity]])
    residual = frob(matrix - mp.iv.exp(1j*mp.iv.mpf(phase_angle))*orthogonal)
    return theta, parity, residual, phase_angle


def star_model(ops, target):
    matrix = mp.iv.eye(2)
    transformed, projections, skeleton = [], [], []
    error = mp.iv.mpf(0)

    def flush():
        nonlocal matrix, error
        theta, parity, residual, phase = orthogonal_projection(matrix)
        transformed.append(('rotation', theta, parity))
        projections.append({'angle': theta, 'parity': parity, 'global_phase': phase,
                            'frobenius_residual_upper': boundfmt(upper(residual))})
        error += residual
        matrix = mp.iv.eye(2)

    for name, qs, params in ops:
        if name == 'cz':
            flush()
            control = next(q for q in qs if q != target)
            skeleton.append(control)
            transformed.append(('conditional_z', control))
        else:
            matrix = gate(name, params) * matrix
    flush()
    coefficients = {0: mp.iv.mpf(0)}
    parity = 0
    for op in transformed:
        if op[0] == 'rotation':
            _, theta, p = op
            coefficients = {mask: (-1)**p*value for mask, value in coefficients.items()}
            coefficients[0] = coefficients.get(0, mp.iv.mpf(0)) + mp.iv.mpf(theta)
            parity ^= p
        else:
            bit = op[1]
            coefficients = {mask ^ (1 << bit): value for mask, value in coefficients.items()}
            parity ^= 1 << (bit + 1)
    assert parity in (0, 1), 'A control has an odd number of conditional Z gates'
    return coefficients, parity, error, projections, skeleton


def tail_steps(ops, n):
    matrices = [mp.iv.eye(2) for _ in range(n)]
    steps = []
    for name, qs, params in ops:
        if name == 'cz':
            qs = tuple(sorted(qs))
            steps.append((qs, {q: matrices[q] for q in qs}))
            for q in qs:
                matrices[q] = mp.iv.eye(2)
        else:
            q = qs[0]
            matrices[q] = gate(name, params) * matrices[q]
    steps.append((tuple(range(n)), dict(enumerate(matrices))))
    return steps


def certificate(a, b):
    assert a.num_qubits == b.num_qubits
    n = a.num_qubits
    pa, sa, ta, ma = decompose(a)
    pb, sb, tb, mb = decompose(b)
    assert ma == mb, 'Changed classical destinations'
    pre_error = mp.iv.mpf(0)
    pre_records = []
    for q, (aa, bb) in enumerate(zip(pa, pb)):
        overlap = sum(midpoint(bb[i, j])*mp.conj(midpoint(aa[i, j])) for i in range(2) for j in range(2))
        angle = fmt(mp.arg(overlap))
        residual = frob(bb-mp.iv.exp(1j*mp.iv.mpf(angle))*aa)
        pre_error += residual
        pre_records.append({'qubit': q, 'phase': angle, 'bound': boundfmt(upper(residual))})
    ca, parity_a, ea, projections_a, skela = star_model(sa, n-1)
    cb, parity_b, eb, projections_b, skelb = star_model(sb, n-1)
    assert skela == skelb
    # Left output Z aligns parity. Modulo pi in each Walsh coefficient only
    # changes a global sign: exp(+/- i*pi*k) is independent of control bits.
    sign = (-1)**(parity_a ^ parity_b)
    delta_bound = mp.iv.mpf(0)
    delta_records = []
    for mask in sorted(set(ca) | set(cb)):
        value = cb.get(mask, mp.iv.mpf(0)) - sign*ca.get(mask, mp.iv.mpf(0))
        turns = int(mp.nint(mp.mpf(value.mid)/mp.pi))
        value -= turns*mp.iv.pi
        delta_bound += abs(value)
        delta_records.append({'walsh_mask': mask, 'pi_multiples': turns,
                              'abs_difference_upper': boundfmt(upper(abs(value)))})
    star_error = ea + eb + delta_bound
    aa, bb = tail_steps(ta, n-1), tail_steps(tb, n-1)
    assert [qs for qs, _ in aa] == [qs for qs, _ in bb], 'Different CZ skeleton'
    gauges = [mp.iv.eye(2) for _ in range(n-1)]
    tail_error = mp.iv.mpf(0)
    tail_records = []
    for step, ((qs, am), (_, bm)) in enumerate(zip(aa, bb)):
        for q in qs:
            residual_matrix = bm[q]*gauges[q]*adjoint(am[q])
            angles = [fmt(mp.arg(midpoint(residual_matrix[k, k]))) for k in range(2)]
            diagonal = mp.iv.matrix([[mp.iv.exp(1j*mp.iv.mpf(angles[0])), 0],
                                     [0, mp.iv.exp(1j*mp.iv.mpf(angles[1]))]])
            residual = frob(residual_matrix-diagonal)
            tail_error += residual
            gauges[q] = diagonal
            tail_records.append({'step': step, 'qubit': q, 'diagonal_angles': angles,
                                 'frobenius_residual_upper': boundfmt(upper(residual))})
    total = pre_error + star_error + tail_error
    bound = upper(total)
    return {
        'qubits': n, 'status': 'observational_equivalent_numeric' if bound < mp.mpf(THRESHOLD) else 'bound_inconclusive',
        'criterion': 'max_y ||U^dagger P_y U - V^dagger P_y V||_2 < 1e-9',
        'effect_operator_norm_upper': boundfmt(bound), 'threshold': THRESHOLD,
        'pre_operator_norm_upper': boundfmt(upper(pre_error)),
        'star_operator_norm_upper': boundfmt(upper(star_error)),
        'tail_operator_norm_upper': boundfmt(upper(tail_error)),
        'star_projection_residual_upper': boundfmt(upper(ea+eb)),
        'star_angle_bound': boundfmt(upper(delta_bound)),
        'output_target_z_parity': parity_a ^ parity_b,
        'star_control_order': skela, 'terminal_measurement_map': ma,
        'pre_certificates': pre_records, 'star_original_projections': projections_a,
        'star_compiled_projections': projections_b, 'star_angle_coefficients': delta_records,
        'tail_certificates': tail_records,
        'arithmetic': 'mpmath interval arithmetic, exact binary64 parsed angles',
        'interval_decimal_precision': mp.iv.dps, 'angle_normalized': False,
        'all_input_states': True, 'all_classical_outcomes': True, 'sampling_used': False,
    }


def main(args):
    global BASE
    BASE = args.archive_root
    mp.mp.dps = args.precision+30
    mp.iv.dps = args.precision
    args.dest.mkdir(parents=True, exist_ok=False)
    manifest = list(csv.DictReader((BASE/'A16_exact_quality/dispositions.csv').open()))
    selected = [r for r in manifest if r['status'] != 'observational_equivalent_numeric']
    assert {r['case'] for r in selected} == {f'ae_nativegates_ibm_qiskit_opt0_{n}_O1' for n in range(16,27)}
    results = []
    for row in selected:
        started = time.perf_counter()
        folder = BASE/'A16_exact_quality/native/work'/row['case']
        assert sha(folder/'original.qasm') == row['source_sha256']
        assert sha(folder/'output.qasm') == row['output_sha256']
        a, b = [qasm2.load(folder/name) for name in ['original.qasm', 'output.qasm']]
        cert = certificate(a, b)
        cert.update(case=row['case'], source_sha256=row['source_sha256'], output_sha256=row['output_sha256'],
                    source_directory=str(folder), elapsed_s=time.perf_counter()-started,
                    peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                    verifier_sha256=sha(Path(__file__)), python=sys.executable,
                    versions={name:importlib.metadata.version(name) for name in ['qiskit','mpmath']})
        write(args.dest/(row['case']+'.json'), cert)
        summary = {k:cert[k] for k in ['case','qubits','status','effect_operator_norm_upper','pre_operator_norm_upper','star_operator_norm_upper','tail_operator_norm_upper','elapsed_s','source_sha256','output_sha256']}
        results.append(summary)
        print(json.dumps(summary), flush=True)
    write(args.dest/'summary.json', {'cases':len(results), 'passed':sum(r['status']=='observational_equivalent_numeric' for r in results), 'results':results})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--dest', type=Path, required=True)
    parser.add_argument('--precision', type=int, default=70)
    parser.add_argument('--archive-root', type=Path, default=BASE)
    main(parser.parse_args())
