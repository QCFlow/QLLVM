"""Dense independent checks, sensitivity controls, and scope rejection tests."""
import argparse
import json
from pathlib import Path
import random

import mpmath as mp
import numpy as np
from qiskit import QuantumCircuit, qasm2
from qiskit.quantum_info import Operator

from certify_ae import BASE, certificate, write


def dense_effect_error(a, b):
    u = Operator(a.remove_final_measurements(inplace=False)).data
    v = Operator(b.remove_final_measurements(inplace=False)).data
    # For normalized row vectors x,y, ||xx* - yy*||_2 = sin(angle(x,y)).
    # Evaluate through phase-aligned row distance to avoid cancellation in
    # sqrt(1-|<x,y>|^2) when circuits are almost identical.
    errors = []
    for x, y in zip(u, v):
        x = x/np.linalg.norm(x)
        y = y/np.linalg.norm(y)
        overlap = np.vdot(x, y)
        phase = overlap/abs(overlap) if abs(overlap) else 1
        distance = np.linalg.norm(y-phase*x)
        errors.append(float(distance*np.sqrt(max(0, 1-distance**2/4))))
    return max(errors)


def main(dest, archive_root):
    mp.mp.dps = 100
    mp.iv.dps = 70
    records = []

    def check(name, a, b, expected_pass=None):
        result = certificate(a, b)
        bound = float(result['effect_operator_norm_upper'])
        dense = dense_effect_error(a, b)
        # Dense reference is binary64; allow 5e-13 for that reference's noise.
        valid = dense <= bound+5e-13
        if expected_pass is not None:
            valid &= (result['status']=='observational_equivalent_numeric') == expected_pass
        records.append({'name':name, 'dense_effect_error':dense, 'certificate_bound':bound,
                        'certificate_status':result['status'], 'calibration_pass':bool(valid)})
        assert valid, records[-1]

    for n in range(2,9):
        folder = archive_root/'A16_exact_quality/native/work'/f'ae_nativegates_ibm_qiskit_opt0_{n}_O1'
        a,b = [qasm2.load(folder/name) for name in ['original.qasm','output.qasm']]
        check(f'archived_ae{n}', a,b,True)

    rng = random.Random(20261109)
    base = None
    for k in range(16):
        n = 2+k%4
        a = QuantumCircuit(n,n)
        for q in range(n-1):
            a.ry(rng.uniform(-3,3),q)
        a.ry(rng.uniform(-3,3),n-1)
        if k%2:
            a.h(n-1)
        for q in range(n-1):
            a.cz(q,n-1)
            a.ry(rng.uniform(-3,3),n-1)
            a.cz(q,n-1)
            a.ry(rng.uniform(-3,3),n-1)
        for q in range(n-2):
            a.cz(q,q+1)
            a.rx(rng.uniform(-3,3),q+1)
        a.ry(rng.uniform(-3,3),n-1)
        b=a.copy()
        perturbation = [0,1e-10,1e-5,0.1][k%4]
        b.ry(perturbation,n-1)
        a.measure(range(n),range(n));b.measure(range(n),range(n))
        check(f'seeded_star_{k}_delta{perturbation}',a,b,perturbation<1e-9)
        base=a

    b=base.copy()
    b.data=[i for i in b.data if i.operation.name!='measure']
    for q in range(b.num_qubits-1):
        b.rz(0.73+q,q)
    b.measure(range(b.num_qubits),range(b.num_qubits))
    check('control_output_diagonal_phases_are_observationally_invisible',base,b,True)
    b=base.copy()
    b.data=[i for i in b.data if i.operation.name!='measure']
    b.rz(0.73,b.num_qubits-1)
    b.measure(range(b.num_qubits),range(b.num_qubits))
    # This specialized real-orthogonal target model is deliberately incomplete.
    # An arbitrary target phase can be equivalent yet have an inconclusive bound.
    check('complex_target_phase_conservatively_inconclusive',base,b,False)

    def reject(name,b):
        rejected=False
        try:
            certificate(base,b)
        except (AssertionError,ValueError):
            rejected=True
        records.append({'name':name,'calibration_pass':rejected,'unsupported_structure_rejected':rejected})
        assert rejected

    b=base.copy()
    b.data=[i for i in b.data if i.operation.name!='measure']
    n=b.num_qubits
    b.measure(range(n),[1,0,*range(2,n)])
    reject('swapped_classical_destinations',b)
    b=base.copy()
    index=next(i for i,x in enumerate(b.data) if x.operation.name=='cz')
    del b.data[index]
    reject('deleted_cz',b)
    b=base.copy()
    b.x(0)
    reject('operation_after_measurement',b)
    dest.mkdir(parents=True,exist_ok=False)
    write(dest/'validation.json',{'checks':len(records),'all_pass':all(r['calibration_pass'] for r in records),'records':records})
    print(json.dumps({'checks':len(records),'all_pass':True}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--dest',type=Path,required=True)
    p.add_argument('--archive-root', type=Path, default=BASE)
    args=p.parse_args()
    main(args.dest, args.archive_root)
